/*
================================================================================
  Planview2026PlatinumStageVerification
================================================================================

  PURPOSE:
      Standalone verification of Flow_Type_Step1 derivation and Stage remapping
      logic (MAP_wbs28_stage table). Reads Initiatives raw input directly from
      the input Excel via Python — no dependency on the main pipeline having run.

  INPUTS (loaded by Python before calling this SP):
      [{@InputSchema}].[{@Stem}_Initiatives]   — raw Initiatives loaded from Excel

  PARAMETERS:
      @InputSchema   nvarchar(128)   schema where Python loaded the raw input
      @Stem          nvarchar(200)   table name stem

  RETURNS (1 result set):
      One row per Initiative (L0/SL1 excluded) with columns:
          Strategy_Seq_ID
          Demand_Type_Old
          BC_Field
          Demand_SubType
          Stage_Original
          Flow_Type_Step1
          Stage_Remapped

  DEPLOYMENT: Run once in SSMS — no parameters needed at deployment time.
================================================================================
*/

CREATE OR ALTER PROCEDURE dbo.Planview2026PlatinumStageVerification
    @InputSchema   nvarchar(128),
    @Stem          nvarchar(200)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @tbl_init  nvarchar(500),
        @tbl_work  nvarchar(500),
        @sql       nvarchar(MAX);

    SET @tbl_init = QUOTENAME(@InputSchema) + '.' + QUOTENAME(@Stem + '_Initiatives');
    SET @tbl_work = QUOTENAME(@InputSchema) + '.' + QUOTENAME(@Stem + '_Initiatives_StageVerify');

    -- ── Clone raw input into a working copy ──────────────────────────────────
    SET @sql = N'IF OBJECT_ID(''' + REPLACE(@tbl_work,'''','''''') + N''') IS NOT NULL DROP TABLE ' + @tbl_work;
    EXEC sp_executesql @sql;

    SET @sql = N'SELECT * INTO ' + @tbl_work + N' FROM ' + @tbl_init;
    EXEC sp_executesql @sql;

    -- ── Remove L0 and SL1 rows (not in migration scope) ─────────────────────
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work) AND name = 'Stage')
    BEGIN
        SET @sql = N'DELETE FROM ' + @tbl_work + N'
                     WHERE LTRIM(RTRIM(ISNULL([Stage], ''''))) IN (''A: L0'', ''B: SL1'');';
        EXEC sp_executesql @sql;
    END

    -- ── Resolve BC field expression ──────────────────────────────────────────
    -- _sql_col() strips '?' on load so check without '?' first.
    DECLARE @bc_expr nvarchar(500);
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
               AND name = 'Is this request vital to business continuity')
        SET @bc_expr = N'LTRIM(RTRIM(ISNULL([Is this request vital to business continuity], '''')))';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
               AND name = 'Is this request vital to business continuity?')
        SET @bc_expr = N'LTRIM(RTRIM(ISNULL([Is this request vital to business continuity?], '''')))';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
                    AND name = 'Is this non-discretionary demand vital to business continuity')
        SET @bc_expr = N'LTRIM(RTRIM(ISNULL([Is this non-discretionary demand vital to business continuity], '''')))';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
                    AND name = 'Is this non-discretionary demand vital to business continuity?')
        SET @bc_expr = N'LTRIM(RTRIM(ISNULL([Is this non-discretionary demand vital to business continuity?], '''')))';
    ELSE
        SET @bc_expr = N'''''';

    -- ── Resolve Demand SubType expression ────────────────────────────────────
    -- Treat the string value 'None' as blank (same as null) in comparisons.
    DECLARE @dst_expr nvarchar(500);
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
               AND name = 'Demand SubType')
        SET @dst_expr = N'CASE LTRIM(RTRIM(ISNULL([Demand SubType],''''))) WHEN ''None'' THEN '''' ELSE LTRIM(RTRIM(ISNULL([Demand SubType],''''))) END';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work)
                    AND name = 'Demand_SubType')
        SET @dst_expr = N'CASE LTRIM(RTRIM(ISNULL([Demand_SubType],''''))) WHEN ''None'' THEN '''' ELSE LTRIM(RTRIM(ISNULL([Demand_SubType],''''))) END';
    ELSE
        SET @dst_expr = N'''''';

    -- ── Resolve Strategy Seq ID column ───────────────────────────────────────
    DECLARE @seq_col nvarchar(256);
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work) AND name = 'Strategy Seq ID')
        SET @seq_col = N'[Strategy Seq ID]';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work) AND name = 'Seq ID')
        SET @seq_col = N'[Seq ID]';
    ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(@tbl_work) AND name = 'Work ID')
        SET @seq_col = N'[Work ID]';
    ELSE
        SET @seq_col = N'CAST([Run_ID] AS nvarchar(50))';

    -- ── Add Flow_Type_Step1 and Stage_Remapped columns ───────────────────────
    SET @sql = N'ALTER TABLE ' + @tbl_work + N'
                 ADD [Flow_Type_Step1] nvarchar(200) NULL,
                     [Stage_Remapped]  nvarchar(50)  NULL;';
    EXEC sp_executesql @sql;

    -- ── Compute Flow_Type_Step1 ──────────────────────────────────────────────
    -- Per Flow Type Logic sheet Rule sequence 1:
    --   Business Only               → NULL  (all BC/SubType combos, rows 3-6)
    --   Business w/ Tech + BC=Yes   → Non-Discretionary - Business Continuity (rows 7-8)
    --   Business w/ Tech + BC=No + Legal/PP/Reg → Non-Discretionary - Run the Business (row 9)
    --   Business w/ Tech + BC=No + other/null   → TBD - See additional logic  (row 10)
    --   Local Enhancement           → Discretionary - Transformational Investment (rows 11-14)
    --   Lifecycle Management        → Non-Discretionary - Run the Business     (rows 15-18)
    --   All other Demand Types      → NULL
    SET @sql = N'
    UPDATE ' + @tbl_work + N'
    SET [Flow_Type_Step1] = CASE

        -- Business Only — always NULL (rows 3-6)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business Only'', ''Business Only Initiative'')
            THEN NULL

        -- Business w/ Tech + BC = Yes (rows 7-8)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND UPPER(' + @bc_expr + N') = ''YES''
            THEN ''Non-Discretionary - Business Continuity''

        -- Business w/ Tech + BC = No/null + Legal/PP/Reg subtype (row 9)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND UPPER(' + @bc_expr + N') <> ''YES''
         AND ' + @dst_expr + N'
             IN (''Legal'', ''Protect Purple'', ''Infosec (Protect Purple)'', ''Regulatory'')
            THEN ''Non-Discretionary - Run the Business''

        -- Business w/ Tech + BC = No/null + None/null subtype (row 10)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND UPPER(' + @bc_expr + N') <> ''YES''
            THEN ''TBD - See additional logic''

        -- Local Enhancement — always Disc Trans Inv (rows 11-14)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Local Enhancement'', ''Local Enhancement Epic'')
            THEN ''Discretionary - Transformational Investment''

        -- Lifecycle Management — always Non-Disc Run Business (rows 15-18)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Lifecycle Management'', ''Lifecycle Management Epic'')
            THEN ''Non-Discretionary - Run the Business''

        -- All other Demand Types → NULL
        ELSE NULL
    END;
    ';
    EXEC sp_executesql @sql;

    -- ── Compute Stage_Remapped per MAP_wbs28_stage table ─────────────────────
    -- Uses old Demand Type (as-is from input) + Flow_Type_Step1 just derived.
    -- Business Only uses <ANY> flow type — handled by its own block.
    -- NULL Flow_Type_Step1 (Business Only / unknown) → ELSE [Stage] passthrough
    --   except Business Only which has explicit stage rules.
    SET @sql = N'
    UPDATE ' + @tbl_work + N'
    SET [Stage_Remapped] = CASE

        -- ── Business w/ Tech + Non-Discretionary - Business Continuity ───────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND [Flow_Type_Step1] = ''Non-Discretionary - Business Continuity''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''G: L3''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Business w/ Tech + Non-Discretionary - Run the Business ──────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND [Flow_Type_Step1] = ''Non-Discretionary - Run the Business''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''C: L1''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Business w/ Tech + Discretionary - Transformational Investment ────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND [Flow_Type_Step1] = ''Discretionary - Transformational Investment''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''E: L2''
                WHEN ''D: SL2'' THEN ''E: L2''
                WHEN ''E: L2''  THEN ''E: L2''
                WHEN ''F: SL3'' THEN ''E: L2''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Business w/ Tech + Discretionary - Other ─────────────────────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND [Flow_Type_Step1] = ''Discretionary - Other''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''C: L1''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Business w/ Tech + TBD → ERROR (no stage rule defined) ───────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business w/ Tech'', ''Business w/ Tech Initiative'')
         AND ISNULL([Flow_Type_Step1],'''') LIKE ''%TBD%''
            THEN ''ERROR - RESOLVE FLOW TYPE ISSUES''

        -- ── Local Enhancement + Non-Discretionary - Run the Business ─────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Local Enhancement'', ''Local Enhancement Epic'')
         AND [Flow_Type_Step1] = ''Non-Discretionary - Run the Business''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''G: L3''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Local Enhancement + Discretionary - Other ─────────────────────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Local Enhancement'', ''Local Enhancement Epic'')
         AND [Flow_Type_Step1] = ''Discretionary - Other''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''G: L3''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Local Enhancement + Discretionary - Trans Inv → ERROR ────────────
        -- (wbs28 table rows 77-85: no rule defined for this combination)
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Local Enhancement'', ''Local Enhancement Epic'')
         AND [Flow_Type_Step1] = ''Discretionary - Transformational Investment''
            THEN ''ERROR - Missing logic for LE/LM''

        -- ── Local Enhancement + any other Flow Type → ERROR ───────────────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Local Enhancement'', ''Local Enhancement Epic'')
            THEN ''ERROR - Missing logic for LE/LM''

        -- ── Lifecycle Management + Non-Discretionary - Run the Business ───────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Lifecycle Management'', ''Lifecycle Management Epic'')
         AND [Flow_Type_Step1] = ''Non-Discretionary - Run the Business''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''G: L3''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Lifecycle Management + Discretionary - Other ──────────────────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Lifecycle Management'', ''Lifecycle Management Epic'')
         AND [Flow_Type_Step1] = ''Discretionary - Other''
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''G: L3''
                WHEN ''D: SL2'' THEN ''G: L3''
                WHEN ''E: L2''  THEN ''G: L3''
                WHEN ''F: SL3'' THEN ''G: L3''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Lifecycle Management + any other Flow Type → ERROR ────────────────
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Lifecycle Management'', ''Lifecycle Management Epic'')
            THEN ''ERROR - Missing logic for LE/LM''

        -- ── Business Only + <ANY> Flow Type ──────────────────────────────────
        -- Flow_Type_Step1 is NULL for Business Only — stage rules are independent
        WHEN LTRIM(RTRIM(ISNULL([Demand Type],'''')))
             IN (''Business Only'', ''Business Only Initiative'')
            THEN CASE LTRIM(RTRIM(ISNULL([Stage],'''')))
                WHEN ''C: L1''  THEN ''C: L1''
                WHEN ''D: SL2'' THEN ''C: L1''
                WHEN ''E: L2''  THEN ''E: L2''
                WHEN ''F: SL3'' THEN ''E: L2''
                WHEN ''G: L3''  THEN ''G: L3''
                WHEN ''H: SL4'' THEN ''G: L3''
                WHEN ''I: L4''  THEN ''I: L4''
                WHEN ''J: SL5'' THEN ''I: L4''
                WHEN ''K: L5''  THEN ''I: L4''
                ELSE [Stage]
            END

        -- ── Catch-all: unrecognised Demand Type or ERROR flow type ────────────
        ELSE ''ERROR - RESOLVE FLOW TYPE ISSUES''
    END
    WHERE LTRIM(RTRIM(ISNULL([Stage], ''''))) <> '''';
    ';
    EXEC sp_executesql @sql;

    -- ── Return verification result set ───────────────────────────────────────
    -- All original columns are returned as-is.
    -- Flow_Type_Step1 and Stage_Remapped are the two added verification columns.
    -- Stage column still holds the original Stage value (working copy was not updated).
    SET @sql = N'
    SELECT *
    FROM ' + @tbl_work + N'
    ORDER BY
        ISNULL(LTRIM(RTRIM([Demand Type])), ''''),
        ISNULL([Flow_Type_Step1], ''''),
        ISNULL(LTRIM(RTRIM([Stage])), '''');
    ';
    EXEC sp_executesql @sql;

    -- ── Cleanup ──────────────────────────────────────────────────────────────
    SET @sql = N'IF OBJECT_ID(''' + REPLACE(@tbl_work,'''','''''') + N''') IS NOT NULL DROP TABLE ' + @tbl_work;
    EXEC sp_executesql @sql;

END
GO
