"""
Planview2026PlatinumStageVerification.py
========================================
Standalone verification tool for Flow_Type_Step1 derivation and Stage
remapping logic. Reads Initiatives from the input Excel, loads to SQL,
calls the verification stored procedure, and writes a verification Excel.

Uses the same config file as the main pipeline.
"""

import pandas as pd
import pyodbc
import json
import argparse
import sys
import io
import re
import logging
from pathlib import Path
from datetime import datetime


# ── Config globals ─────────────────────────────────────────────
INPUT_FILE        = ""
INPUT_SHEET_INITS = ""
OUTPUT_FOLDER     = ""
SQL_SERVER        = ""
SQL_DATABASE      = ""
_logger           = None
SEPARATOR         = "=" * 60


# ── Logging ───────────────────────────────────────────────────
def init_logger(ts, out_folder):
    global _logger
    Path(out_folder).mkdir(parents=True, exist_ok=True)
    log_file = Path(out_folder) / f"stage_verify_run_{ts}.log"
    _logger = logging.getLogger("stage_verify")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s  %(message)s",
                                       datefmt="%Y-%m-%d %H:%M:%S"))
    _logger.addHandler(fh)
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(ch)
    return log_file

def log(msg, indent=0):
    line = "  " * indent + msg
    _logger.info(line) if _logger else print(line)

def log_step(n, msg):
    _logger.info(f"\n[{n}] {msg}") if _logger else print(f"\n[{n}] {msg}")


# ── Config loader ─────────────────────────────────────────────
def load_config(config_path=None):
    global INPUT_FILE, INPUT_SHEET_INITS, OUTPUT_FOLDER
    global SQL_SERVER, SQL_DATABASE

    if config_path is None:
        config_path = Path(__file__).parent / "Planview2026PlatinumConsolidated_Updated_config.json"
    config_path = Path(config_path)
    if not config_path.exists():
        print(f"ERROR: Config not found: {config_path}"); sys.exit(1)
    try:
        with open(config_path, encoding="utf-8") as f:
            cfg = json.load(f)
    except json.JSONDecodeError as e:
        print(f"ERROR: Bad JSON: {e}"); sys.exit(1)

    INPUT_FILE    = cfg["input_file"]
    OUTPUT_FOLDER = cfg["output_folder"]
    SQL_SERVER    = cfg.get("sql", {}).get("server", "")
    SQL_DATABASE  = cfg.get("sql", {}).get("database", "")
    # sheet_initiatives is the Strategies sheet — this is the correct sheet
    # for the verification script as it contains the BC field (WR60).
    INPUT_SHEET_INITS = cfg.get("sheet_initiatives", "Data Extract_Stratagies_05.15")


# ── Read 3-row header input file ─────────────────────────────
def read_3row_header(path, sheet_name):
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[sheet_name]
    data = []
    for row in ws.iter_rows(values_only=True):
        data.append(['' if v is None else str(v).strip() for v in row])
    wb.close()

    raw = pd.DataFrame(data)
    row3_names = [str(raw.iloc[2, c]).strip() for c in range(raw.shape[1])]

    seen = {}
    final_cols = []
    for name in row3_names:
        if not name or name == 'nan':
            name = f"_col_{len(final_cols)}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 0
        final_cols.append(name)

    df_data = raw.iloc[3:].copy()
    df_data.columns = final_cols

    filter_col = next((c for c in final_cols if not c.startswith('_col')), final_cols[0])
    df_data = df_data[df_data[filter_col].str.strip() != ''].reset_index(drop=True)

    unnamed = [c for c in df_data.columns if c.startswith('_col')]
    if unnamed:
        df_data = df_data.drop(columns=unnamed)

    return df_data


# ── SQL helpers ───────────────────────────────────────────────
def _sql_col(name):
    clean = (str(name)
             .replace(']', '').replace('[', '')
             .replace(',', '_').replace('/', '_')
             .replace('\\', '_').replace(':', '_')
             .replace('?', '').replace('(', '').replace(')', '')
             .strip())
    return clean[:120]

def connect_sql():
    log_step("2/4", "Connecting to SQL Server...")
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};"
            f"Trusted_Connection=yes;Connection Timeout=30;"
        )
        conn.autocommit = True
        log(f"Server : {SQL_SERVER} / {SQL_DATABASE}", 1)
        log("Status : Connected", 1)
        return conn
    except pyodbc.Error as e:
        log(f"ERROR: Could not connect to SQL Server: {e}", 1)
        sys.exit(1)


# ── Load Initiatives to SQL ───────────────────────────────────
def load_initiatives_to_sql(conn, df, schema, table, ts):
    cursor = conn.cursor()
    cursor.execute(f"""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name='{schema}')
            EXEC('CREATE SCHEMA [{schema}]')
    """)
    cursor.execute(f"""
        IF OBJECT_ID('[{schema}].[{table}]') IS NOT NULL
            DROP TABLE [{schema}].[{table}]
    """)

    safe_cols = []
    seen = {}
    for c in [_sql_col(c) for c in df.columns]:
        if c in seen:
            seen[c] += 1
            c = f"{c}_{seen[c]}"
        else:
            seen[c] = 0
        safe_cols.append(c)

    df = df.copy()
    df.columns = safe_cols

    col_defs = ", ".join([f"[{c}] nvarchar(MAX)" for c in df.columns])
    cursor.execute(f"""
        CREATE TABLE [{schema}].[{table}] (
            [Run_ID]         nvarchar(50)  DEFAULT '{ts}',
            [Load_Timestamp] datetime      DEFAULT GETDATE(),
            {col_defs}
        )
    """)

    col_names    = ", ".join([f"[{c}]" for c in df.columns])
    placeholders = ", ".join(["?" for _ in df.columns])
    ins = (
        f"INSERT INTO [{schema}].[{table}] "
        f"([Run_ID],[Load_Timestamp],{col_names}) "
        f"VALUES ('{ts}',GETDATE(),{placeholders})"
    )

    df_c = df.fillna('')
    for col in df_c.columns:
        if df_c[col].dtype == object:
            df_c[col] = (df_c[col]
                .str.replace("\n", " ", regex=False)
                .str.replace("\r", " ", regex=False)
                .str.replace("|",  " ", regex=False)
                .str.replace('"', "'", regex=False)
                .str.strip())

    rows = [tuple(r) for r in df_c.itertuples(index=False, name=None)]
    conn.autocommit = False
    try:
        for i in range(0, len(rows), 500):
            cursor.executemany(ins, rows[i:i+500])
        conn.commit()
    except Exception as e:
        conn.rollback(); raise
    finally:
        conn.autocommit = True

    log(f"[{schema}].[{table}] — {len(rows):,} rows loaded", 1)


# ── Call verification stored procedure ───────────────────────
def run_verification_sp(conn, schema, stem):
    log_step("3/4", "Running Stage verification stored procedure...")
    cursor = conn.cursor()
    cursor.execute(
        "EXEC dbo.Planview2026PlatinumStageVerification @InputSchema=?, @Stem=?",
        schema, stem
    )
    cols = [col[0] for col in cursor.description]
    rows = cursor.fetchall()
    df = pd.DataFrame.from_records([tuple(r) for r in rows], columns=cols)
    # Drop internal load columns
    df = df.drop(columns=[c for c in ['Run_ID', 'Load_Timestamp'] if c in df.columns])
    log(f"Verification rows returned : {len(df):,}", 1)
    return df


# ── Write verification Excel ──────────────────────────────────
def write_verification_excel(df, ts, out_folder):
    log_step("4/4", "Writing verification Excel...")

    from openpyxl.styles import PatternFill, Font, Alignment

    output_file = Path(out_folder) / f"Stage_Verification_{ts}.xlsx"
    Path(out_folder).mkdir(parents=True, exist_ok=True)

    # Colour coding for key verification columns only
    RED   = PatternFill("solid", start_color="FF9999", fgColor="FF9999")   # ERROR
    AMBER = PatternFill("solid", start_color="FFE699", fgColor="FFE699")   # TBD
    GREEN = PatternFill("solid", start_color="C6EFCE", fgColor="C6EFCE")   # Stage changed
    GREY  = PatternFill("solid", start_color="D9D9D9", fgColor="D9D9D9")   # null flow type
    BLUE  = PatternFill("solid", start_color="BDD7EE", fgColor="BDD7EE")   # header of key cols

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine='openpyxl') as writer:

        # ── Reorder columns: Flow_Type_Step1 and Stage_Remapped next to Stage ──
        if 'Stage' in df.columns and 'Flow_Type_Step1' in df.columns and 'Stage_Remapped' in df.columns:
            cols = list(df.columns)
            # Remove the two verification cols from wherever they are
            for c in ['Flow_Type_Step1', 'Stage_Remapped']:
                cols.remove(c)
            # Insert them immediately after Stage
            stage_idx = cols.index('Stage')
            cols.insert(stage_idx + 1, 'Flow_Type_Step1')
            cols.insert(stage_idx + 2, 'Stage_Remapped')
            df = df[cols]

        # ── Main verification sheet — all columns ─────────────────────────────
        df.to_excel(writer, sheet_name="Stage_Verification", index=False)
        ws = writer.sheets["Stage_Verification"]

        # Header formatting — dark blue for all, lighter blue for key verify cols
        header_fill     = PatternFill("solid", start_color="1F4E79", fgColor="1F4E79")
        header_fill_key = PatternFill("solid", start_color="2E75B6", fgColor="2E75B6")
        header_font     = Font(color="FFFFFF", bold=True)
        key_cols        = {'Stage', 'Flow_Type_Step1', 'Stage_Remapped'}

        col_map = {}
        for cell in ws[1]:
            col_map[cell.value] = cell.column
            is_key = cell.value in key_cols
            cell.fill = header_fill_key if is_key else header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")

        ft_col = col_map.get("Flow_Type_Step1")
        sr_col = col_map.get("Stage_Remapped")
        st_col = col_map.get("Stage")

        # Row colouring — applied only to the three key columns per row
        for row_idx in range(2, ws.max_row + 1):
            ft_val = ws.cell(row=row_idx, column=ft_col).value if ft_col else ""
            sr_val = ws.cell(row=row_idx, column=sr_col).value if sr_col else ""
            st_val = ws.cell(row=row_idx, column=st_col).value if st_col else ""

            ft_str = str(ft_val) if ft_val else ""
            sr_str = str(sr_val) if sr_val else ""
            st_str = str(st_val) if st_val else ""

            if "ERROR" in sr_str:
                fill = RED
            elif "TBD" in ft_str:
                fill = AMBER
            elif not ft_val:
                fill = GREY
            elif sr_str and sr_str != st_str:
                fill = GREEN
            else:
                fill = None

            if fill and ft_col:
                ws.cell(row=row_idx, column=ft_col).fill = fill
            if fill and sr_col:
                ws.cell(row=row_idx, column=sr_col).fill = fill
            if fill and st_col:
                ws.cell(row=row_idx, column=st_col).fill = fill

        # Column widths
        for col_cells in ws.columns:
            mx = max((len(str(c.value)) for c in col_cells if c.value), default=10)
            ws.column_dimensions[col_cells[0].column_letter].width = min(mx + 4, 60)

        # ── Summary sheet ─────────────────────────────────────────────────────
        total      = len(df)
        error_rows = df['Stage_Remapped'].str.contains('ERROR', na=False).sum() if 'Stage_Remapped' in df.columns else 0
        tbd_rows   = df['Flow_Type_Step1'].str.contains('TBD', na=False).sum()  if 'Flow_Type_Step1' in df.columns else 0
        null_ft    = df['Flow_Type_Step1'].isna().sum()                          if 'Flow_Type_Step1' in df.columns else 0
        changed    = (
            (df['Stage_Remapped'] != df['Stage']) &
            ~df['Stage_Remapped'].str.contains('ERROR', na=False) &
            df['Stage_Remapped'].notna()
        ).sum() if 'Stage_Remapped' in df.columns and 'Stage' in df.columns else 0

        ft_counts = df['Flow_Type_Step1'].fillna('(null)').value_counts().to_dict() if 'Flow_Type_Step1' in df.columns else {}
        sr_counts = df['Stage_Remapped'].fillna('(blank)').value_counts().to_dict() if 'Stage_Remapped' in df.columns else {}

        summary_rows = [
            ["STAGE VERIFICATION SUMMARY", ""],
            ["Run Timestamp",    ts],
            ["Input File",       INPUT_FILE],
            ["Input Sheet",      INPUT_SHEET_INITS],
            ["", ""],
            ["TOTALS", ""],
            ["Total Initiatives (excl L0/SL1)", total],
            ["", ""],
            ["COLOUR KEY (applied to Stage / Flow_Type_Step1 / Stage_Remapped columns)", ""],
            ["Green  — Stage successfully remapped to a new value",    changed],
            ["Grey   — Business Only (Flow_Type_Step1 = null)",        null_ft],
            ["Amber  — TBD (BwT no BC and no special SubType)",        tbd_rows],
            ["Red    — ERROR (no rule matched or missing logic)",       error_rows],
            ["", ""],
            ["FLOW_TYPE_STEP1 BREAKDOWN", ""],
        ]
        for k, v in sorted(ft_counts.items()):
            summary_rows.append([f"  {k}", v])

        summary_rows += [["", ""], ["STAGE_REMAPPED BREAKDOWN", ""]]
        for k, v in sorted(sr_counts.items()):
            summary_rows.append([f"  {k}", v])

        df_sum = pd.DataFrame(summary_rows, columns=["Item", "Value"])
        df_sum.to_excel(writer, sheet_name="Summary", index=False)
        ws_s = writer.sheets["Summary"]
        ws_s.column_dimensions['A'].width = 60
        ws_s.column_dimensions['B'].width = 40
        bold = Font(bold=True)
        for row in ws_s.iter_rows():
            val = str(row[0].value) if row[0].value else ""
            if val.isupper() or val.startswith("COLOUR"):
                for cell in row:
                    cell.font = bold

    with open(output_file, 'wb') as f:
        f.write(buf.getvalue())

    log(f"Output : {output_file}", 1)
    return output_file


# ── Main ──────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Planview Stage + Flow_Type_Step1 Verification Tool")
    parser.add_argument("--config", default=None,
                        help="Path to config JSON (default: same folder as script)")
    args = parser.parse_args()
    load_config(args.config)

    start = datetime.now()
    ts    = start.strftime("%Y%m%d_%H%M%S")
    log_file = init_logger(ts, OUTPUT_FOLDER)

    log(SEPARATOR)
    log("  Planview Stage & Flow_Type_Step1 Verification")
    log(f"  Input  : {INPUT_FILE}")
    log(f"  Sheet  : {INPUT_SHEET_INITS}")
    log(f"  Output : {OUTPUT_FOLDER}")
    log(f"  Started: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    log(SEPARATOR)

    # ── Step 1: Read Initiatives from Excel ───────────────────
    log_step("1/4", "Reading Initiatives from Excel (3-row header)...")
    ip = Path(INPUT_FILE)
    df_inits = read_3row_header(ip, INPUT_SHEET_INITS)
    log(f"Initiatives : {len(df_inits):,} rows | {len(df_inits.columns)} cols", 1)

    # ── Step 2: Connect + load to SQL ────────────────────────
    conn = connect_sql()
    schema = f"verify_{ts}"
    stem   = re.sub(r'[^A-Za-z0-9_]', '_', ip.stem).strip('_')
    table  = f"{stem}_Initiatives"
    load_initiatives_to_sql(conn, df_inits, schema, table, ts)

    # ── Step 3: Run verification SP ──────────────────────────
    df_result = run_verification_sp(conn, schema, stem)

    # ── Log quick summary to console ─────────────────────────
    if 'Flow_Type_Step1' in df_result.columns:
        log("Flow_Type_Step1 value counts:", 1)
        for val, cnt in df_result['Flow_Type_Step1'].fillna('(null)').value_counts().items():
            log(f"  {str(val):<55}: {cnt:>6}", 2)

    if 'Stage_Remapped' in df_result.columns:
        log("Stage_Remapped value counts:", 1)
        for val, cnt in df_result['Stage_Remapped'].fillna('(blank)').value_counts().items():
            log(f"  {str(val):<20}: {cnt:>6}", 2)

    if 'Stage_Remapped' in df_result.columns:
        error_count = df_result['Stage_Remapped'].str.contains('ERROR', na=False).sum()
        if error_count:
            log(f"WARNING: {error_count} rows have ERROR in Stage_Remapped — review output", 1)

    # ── Step 4: Write Excel ───────────────────────────────────
    out_path = write_verification_excel(df_result, ts, OUTPUT_FOLDER)

    # ── Cleanup verify schema from SQL ───────────────────────
    try:
        cursor = conn.cursor()
        # Drop the table (SP already cleaned up its working copy)
        cursor.execute(f"""
            IF OBJECT_ID('[{schema}].[{table}]') IS NOT NULL
                DROP TABLE [{schema}].[{table}]
        """)
        log("SQL verify schema cleaned up", 1)
    except Exception:
        pass

    conn.close()

    elapsed = round((datetime.now() - start).total_seconds(), 1)
    log(f"\n{SEPARATOR}")
    log("  VERIFICATION COMPLETE")
    log(f"  Output : {out_path}")
    log(f"  Log    : {log_file}")
    log(f"  Runtime: {elapsed}s")
    log(SEPARATOR)


if __name__ == "__main__":
    main()
