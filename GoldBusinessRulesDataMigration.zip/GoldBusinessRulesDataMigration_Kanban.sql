-- ============================================================
-- Stored Procedure : GoldBusinessRulesDataMigration_Kanban
-- Database         : PlanviewMigration
-- Description      : Runs the Kanban Epic classification
--                    transformation against a dynamically named
--                    input table and returns ONE combined result
--                    set. Python splits the result into four
--                    subsets (Final, StopWork, Review, Excluded)
--                    exactly as before.
--
-- Parameters:
--   @input_schema  nvarchar(200)  e.g. 'input_20250510_143022'
--   @input_table   nvarchar(200)  e.g. 'Portfolio_Kanban_Analysis___Work_ALL'
--
-- Called from      : GoldBusinessRulesDataMigration_kanban.py  run_transform()
-- ============================================================

USE [PlanviewMigration];
GO

IF OBJECT_ID('dbo.usp_Transform_Kanban', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_Transform_Kanban;
GO

CREATE or ALTER PROCEDURE dbo.GoldBusinessRulesDataMigration_Kanban
    @input_schema  nvarchar(200),
    @input_table   nvarchar(200)
AS
BEGIN
    SET NOCOUNT ON;

    -- ----------------------------------------------------------
    -- Build the transformation query as dynamic SQL.
    -- ----------------------------------------------------------

    DECLARE @sql nvarchar(MAX);

    SET @sql = N'
WITH classified AS (
    SELECT
        [Work ID #]                    AS [INITIATIVE_LEGACY_ID],
        [Name]                         AS [Initiative_Name],
        [Work Type]                    AS [Demand_Type],
        [Work Status]                  AS [Work_Status_Raw],
        [T-Shirt Size]                 AS [T_Shirt_Size],
        [Home Domain/Portfolio]        AS [Portfolio],
        [Associated Initiative Seq ID] AS [Parent_Initiative_ID],
        [Associated Initiative]        AS [Parent_Initiative_Name],
        [AP Top Lane],
        [Schedule Start],
        [Schedule Finish],

        -- Work Status normalisation
        CASE [Work Status]
            WHEN ''Approved''          THEN ''Approved''
            WHEN ''Not Started''       THEN ''Not Started''
            WHEN ''In Progress''       THEN ''In Progress''
            WHEN ''On Hold''           THEN ''On Hold''
            WHEN ''Cancelled''         THEN ''Cancelled''
            WHEN ''Closed''            THEN ''Closed''
            WHEN ''Completed''         THEN ''Completed''
            WHEN ''Assumed Completed'' THEN ''Assumed Completed''
            WHEN ''Rejected''          THEN ''Rejected''
            ELSE [Work Status]
        END AS [Work_Status],

        -- Migration Track — priority order matters
        CASE
            -- BR_STATUS_001
            -- Exclude: Cancelled, Closed, Completed, Assumed Completed, Rejected
            WHEN [Work Status] IN
                 (''Cancelled'',''Closed'',''Completed'',''Assumed Completed'',''Rejected'')
                THEN ''EXCLUDED-Status''

            -- BR_TE_LCM_005
            -- LCM Epics -> Non-Discretionary Run the Business
            WHEN [Work Type] = ''Lifecycle Management Epic''
                THEN ''Tech-Enabled -- LCM''

            -- BR_TE_LE_001
            -- LE Epics with T-shirt L or XL -> Strategic Investment (Finance HOLD)
            WHEN [Work Type] = ''Local Enhancement Epic''
                 AND [T-Shirt Size] IN (''4: L'',''5: XL'')
                THEN ''Tech-Enabled -- LE L/XL''

            -- BR_TE_LE_003
            -- LE Epics with T-shirt S/M/XS -> Discretionary Other
            WHEN [Work Type] = ''Local Enhancement Epic''
                 AND [T-Shirt Size] IN (''1: XS'',''2: S'',''3: M'')
                THEN ''Tech-Enabled -- LE S/M/XS''

            -- BR_BLANK_001
            -- LE Epics with blank T-shirt -> Discretionary Other (default)
            WHEN [Work Type] = ''Local Enhancement Epic''
                 AND ([T-Shirt Size] IS NULL OR [T-Shirt Size] = '''')
                THEN ''Tech-Enabled -- LE Blank''

            -- BR_TE_LE_002
            -- BwT Epics with T-shirt L or XL -> Stop Work pending Finance
            WHEN [Work Type] = ''Biz w/ Tech Epic''
                 AND [T-Shirt Size] IN (''4: L'',''5: XL'')
                THEN ''Tech-Enabled -- BwT L/XL''

            -- BR_TE_001/003: BwT S/M/XS or Blank -> Review Required
            -- (ESI Flag + NRB not in source file; uncomment once ESPM provides them)
            --
            -- WHEN [Work Type] = ''Biz w/ Tech Epic''
            --      AND [ESI_Flag] = ''Y''
            --      AND [T-Shirt Size] IN (''4: L'',''5: XL'')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) >= 10
            --     THEN ''Tech-Enabled -- Strategic Investment''
            --
            -- WHEN [Work Type] = ''Biz w/ Tech Epic''
            --      AND [T-Shirt Size] IN (''4: L'',''5: XL'')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) < 10
            --     THEN ''Tech-Enabled -- Stop Work (Pending Finance)''
            --
            -- WHEN [Work Type] = ''Biz w/ Tech Epic''
            --      AND [ESI_Flag] = ''Y''
            --      AND [T-Shirt Size] IN (''1: XS'',''2: S'',''3: M'')
            --     THEN ''Tech-Enabled -- Discretionary Other''
            --
            -- BR_TE_004: Business Continuity direct map
            -- WHEN [BC_Flag] = ''Y''
            --     THEN ''Tech-Enabled -- Business Continuity''

            WHEN [Work Type] = ''Biz w/ Tech Epic''
                THEN ''REVIEW REQUIRED''

            ELSE ''REVIEW REQUIRED''
        END AS [Migration_Track]

    FROM [' + @input_schema + N'].[' + @input_table + N']
),
final AS (
    SELECT
        [INITIATIVE_LEGACY_ID],
        [Initiative_Name],
        [Demand_Type],
        [Work_Status],
        [T_Shirt_Size],
        [Portfolio],
        [Parent_Initiative_ID],
        [Parent_Initiative_Name],
        [AP Top Lane],
        [Schedule Start],
        [Schedule Finish],

        -- Demand Sub-Type
        CASE [Migration_Track]
            WHEN ''Tech-Enabled -- LCM''
                THEN ''Non-Discretionary - Run the Business''
            WHEN ''Tech-Enabled -- LE L/XL''
                THEN ''Discretionary - Strategic Investment (Finance HOLD)''
            WHEN ''Tech-Enabled -- LE S/M/XS''
                THEN ''Discretionary - Other''
            WHEN ''Tech-Enabled -- LE Blank''
                THEN ''Discretionary - Other''
            WHEN ''Tech-Enabled -- BwT L/XL''
                THEN ''Discretionary - Strategic Inv. (Stop Work - Pending Finance)''
            WHEN ''EXCLUDED-Status''
                THEN ''N/A - Excluded''
            ELSE ''REVIEW REQUIRED - ESI Flag / NRB Missing''
        END AS [Demand_Sub_Type],

        -- Migration Source
        CASE [Migration_Track]
            WHEN ''EXCLUDED-Status'' THEN ''N/A - Excluded''
            ELSE ''Current Prod -> New Prod''
        END AS [Migration_Source],

        [Migration_Track],

        -- Output Segment
        CASE [Migration_Track]
            WHEN ''Tech-Enabled -- LCM''        THEN ''LCM-NonDisc-RunTheBusiness''
            WHEN ''Tech-Enabled -- LE L/XL''    THEN ''LE-Disc-StrategicInvestment-HOLD''
            WHEN ''Tech-Enabled -- LE S/M/XS''  THEN ''LE-Disc-Other''
            WHEN ''Tech-Enabled -- LE Blank''    THEN ''LE-Disc-Other''
            WHEN ''Tech-Enabled -- BwT L/XL''   THEN ''TE-BwT-StopWork-HOLD''
            WHEN ''EXCLUDED-Status''             THEN ''Excluded-Status''
            ELSE ''REVIEW-ESI-NRB-Missing''
        END AS [Output_Segment]

    FROM classified
)
SELECT * FROM final
ORDER BY [Migration_Track], [INITIATIVE_LEGACY_ID];
';

    EXEC sp_executesql @sql;

END;
GO
