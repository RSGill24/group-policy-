-- ============================================================
-- Stored Procedure : GoldBusinessRulesDataMigration_PortMgr
-- Database         : PlanviewMigration
-- Description      : Runs the Portfolio Manager classification
--                    transformation against a dynamically named
--                    input table and returns ONE combined result
--                    set. Python splits the result into four
--                    subsets (Final, StopWork, Review, Excluded)
--                    exactly as before.
--
-- Parameters:
--   @input_schema  nvarchar(200)  e.g. 'input_20250510_143022'
--   @input_table   nvarchar(200)  e.g. 'Portfolio_Manager__New_List__3_'
--
-- Called from      : GoldBusinessRulesDataMigration_portmgr.py  run_transform()
-- ============================================================

USE [PlanviewMigration];
GO

IF OBJECT_ID('dbo.usp_Transform_PortMgr', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_Transform_PortMgr;
GO

CREATE or ALTER PROCEDURE dbo.GoldBusinessRulesDataMigration_PortMgr
    @input_schema  nvarchar(200),
    @input_table   nvarchar(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql nvarchar(MAX);

    -- IMPORTANT: No inline -- comments inside the @sql string below.
    -- SQL Server treats them as real line comments and truncates the string
    -- literal at that point, causing "Incorrect syntax near ','" errors.
    -- All comments are kept outside the string (see header above).

    SET @sql = N'
WITH classified AS (
    SELECT
        [Strategy Seq. ID]           AS [INITIATIVE_LEGACY_ID],
        [Name]                       AS [Initiative_Name],
        [Initiative Type]            AS [Demand_Type],
        [Lifecycle Status]           AS [Work_Status_Raw],
        [Stage],
        [Domain]                     AS [Portfolio],
        [Pod],
        [Work Actual/Schedule Start],
        [Work Actual/Schedule Finish],

        CASE [Lifecycle Status]
            WHEN ''Active''               THEN ''Active''
            WHEN ''Cancelled''            THEN ''Cancelled''
            WHEN ''Completed''            THEN ''Completed''
            WHEN ''On Hold''              THEN ''On Hold''
            WHEN ''Rejected''             THEN ''Rejected''
            WHEN ''Cancellation Request'' THEN ''Cancellation Request''
            ELSE [Lifecycle Status]
        END AS [Work_Status],

        CASE
            WHEN [Lifecycle Status] IN
                 (''Cancelled'',''Completed'',''On Hold'',''Rejected'',''Cancellation Request'')
                THEN ''EXCLUDED-Status''

            WHEN [Initiative Type] = ''Business Only Initiative''
                THEN ''Tech-Enabled -- Business Only''

            WHEN [Initiative Type] = ''Business w/ Tech Initiative''
                THEN ''REVIEW REQUIRED''

            ELSE ''REVIEW REQUIRED''
        END AS [Migration_Track]

    FROM [' + @input_schema + N'].[' + @input_table + N']
),
final AS (
    SELECT
        [INITIATIVE_LEGACY_ID],
        [Initiative_Name],
        [Demand_Type],
        [Work_Status],
        [Stage],
        [Portfolio],
        [Pod],
        [Work Actual/Schedule Start],
        [Work Actual/Schedule Finish],

        CASE [Migration_Track]
            WHEN ''Tech-Enabled -- Business Only''
                THEN ''Business Demand Management''
            WHEN ''EXCLUDED-Status''
                THEN ''N/A - Excluded''
            ELSE ''REVIEW REQUIRED - ESI Flag / NRB Missing''
        END AS [Demand_Sub_Type],

        CASE [Migration_Track]
            WHEN ''Tech-Enabled -- Business Only'' THEN ''Current Prod / ESPM (TBC)''
            WHEN ''EXCLUDED-Status''               THEN ''N/A - Excluded''
            ELSE ''Current Prod -> New Prod''
        END AS [Migration_Source],

        [Migration_Track],

        CASE [Migration_Track]
            WHEN ''Tech-Enabled -- Business Only'' THEN ''TE-BusinessDemandMgmt''
            WHEN ''EXCLUDED-Status''               THEN ''Excluded-Status''
            ELSE ''REVIEW-ESI-NRB-Missing''
        END AS [Output_Segment]

    FROM classified
)
SELECT * FROM final
ORDER BY [Migration_Track], [INITIATIVE_LEGACY_ID];
';

    EXEC sp_executesql @sql;

END;
GO
