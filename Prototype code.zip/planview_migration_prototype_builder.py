"""
planview_migration_prototype_builder.py
========================================
Config : planview_migration_prototype_config.json (same folder as script)
Run    : py planview_migration_prototype_builder.py
Override: py planview_migration_prototype_builder.py --config path/to/config.json
"""

import pandas as pd
import json
import argparse
import sys
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── Colours ───────────────────────────────────────────────────
NAV  = "1F3864"; BLUE = "2E5FA3"; WHITE = "FFFFFF"
GD   = "375623"; GL   = "E2EFDA"
RD   = "C00000"; RL   = "FFE7E7"
AD   = "833C00"; AL   = "FAEEDA"
PD   = "3D1D8C"; PL   = "E9E3F5"
GRD  = "595959"; GRL  = "F2F2F2"
LBLUE= "DEEAF1"

# ── Business rule constants ────────────────────────────────────
# Source: Planview 2026 Platinum Consolidated Configuration and
#         Data Migration Requirements — Business_Rules sheet
FY25_EXPIRED_ESI = {
    "Network Optimization (FY25 ESI)",
    "Digital Intelligence (FY25 ESI)",
    "Europe - Operations (FY25 ESI)",
    "Digital Exchange (FY25 ESI)",
}
ALLOWED_STATUSES   = {"Active"}
EPIC_EXCL_STATUSES = {"Cancelled", "Rejected", "Completed/Closed"}
NRB_THRESHOLD_M    = 10

SEG = {
    "init_bc":        "TE-NonDisc-BusinessContinuity",
    "init_stopwork":  "TE-Disc-StopWork-HOLD",
    "init_strat_inv": "TE-Disc-TransformationalInvestment",
    "init_disc_other":"TE-Disc-Other",
    "init_bo":        "TE-BusinessDemandMgmt",
    "init_pc":        "PC-StrategicProgram-PilotSandbox",
    "init_pending":   "PENDING-Stage-Lifecycle-Undefined",
    "init_excluded":  "EXCLUDED-Status",
    "lcm":            "LCM-NonDisc-RunTheBusiness",
    "le_strat":       "LE-Disc-TransformationalInvestment",
    "le_stopwork":    "LE-Disc-StopWork-HOLD",
    "le_disc":        "LE-Disc-Other",
    "epic_pending":   "PENDING-Stage-Lifecycle-Undefined",
    "epic_excluded":  "EXCLUDED-Status",
}

FLOW = {
    "init_bc":        "Non-Discretionary \u2013 Business Continuity",
    "init_stopwork":  "STOP WORK Discretionary \u2013 Transformational Investment",
    "init_strat_inv": "Discretionary \u2013 Transformational Investment",
    "init_disc_other":"Discretionary \u2013 Other",
    "init_bo":        "Business Demand Management",
    "init_pc":        "Strategic Program (Business + Tech) \u2014 Pilot Sandbox",
    "lcm":            "Non-Discretionary - Run the Business",
    "le_strat":       "Discretionary \u2013 Transformational Investment",
    "le_stopwork":    "STOP WORK Discretionary \u2013 Transformational Investment",
    "le_disc":        "Discretionary \u2013 Other",
}

MIG_SRC = {
    "init_bc":        "FDXPROD \u2192 New Prod",
    "init_stopwork":  "FDXPROD \u2192 New Prod (HOLD \u2014 Finance/Triage sign-off required)",
    "init_strat_inv": "FDXPROD \u2192 New Prod",
    "init_disc_other":"FDXPROD \u2192 New Prod",
    "init_bo":        "FDXPROD / ESPM Spreadsheets \u2192 New Prod",
    "init_pc":        "FDXSANDBOXA \u2192 New Prod (ESPM owns)",
    "lcm":            "FDXPROD \u2192 New Prod",
    "le_strat":       "FDXPROD \u2192 New Prod",
    "le_stopwork":    "FDXPROD \u2192 New Prod (HOLD \u2014 Finance/Triage sign-off required)",
    "le_disc":        "FDXPROD \u2192 New Prod",
}


# ── openpyxl helpers ──────────────────────────────────────────
def fill(h): return PatternFill("solid", fgColor=h)

def bdr():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

def sc(ws, row, col, value, bold=False, color="000000", size=10,
       bg=None, ha="left", va="center", wrap=True, italic=False):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, color=color, size=size, italic=italic, name="Arial")
    c.alignment = Alignment(horizontal=ha, vertical=va, wrap_text=wrap)
    if bg: c.fill = fill(bg)
    c.border = bdr()
    return c

def title_block(ws, row, text, subtitle, cols=8):
    ws.merge_cells(f"A{row}:{get_column_letter(cols)}{row}")
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(bold=True, color=WHITE, size=13, name="Arial")
    c.fill = fill(NAV)
    c.alignment = Alignment(horizontal="center", vertical="center")
    c.border = bdr()
    ws.row_dimensions[row].height = 28
    ws.merge_cells(f"A{row+1}:{get_column_letter(cols)}{row+1}")
    c2 = ws.cell(row=row+1, column=1, value=subtitle)
    c2.font = Font(color=WHITE, size=9, italic=True, name="Arial")
    c2.fill = fill(NAV)
    c2.alignment = Alignment(horizontal="center", vertical="center")
    c2.border = bdr()
    ws.row_dimensions[row+1].height = 14
    return row + 3

def hdr_row(ws, row, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = Font(bold=True, color=WHITE, size=10, name="Arial")
        c.fill = fill(BLUE)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = bdr()
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[row].height = 20
    return row + 1

def sec_row(ws, row, text, cols):
    ws.merge_cells(f"A{row}:{get_column_letter(cols)}{row}")
    c = ws.cell(row=row, column=1, value=f"  {text}")
    c.font = Font(bold=True, color=WHITE, size=10, name="Arial")
    c.fill = fill(BLUE)
    c.alignment = Alignment(horizontal="left", vertical="center")
    c.border = bdr()
    ws.row_dimensions[row].height = 18
    return row + 1

def dr(ws, row, vals, bgs, tcs=None, h=50):
    for i, (v, bg) in enumerate(zip(vals, bgs), 1):
        tc = tcs[i-1] if tcs and i <= len(tcs) else "000000"
        sc(ws, row, i, v, bg=bg, color=tc, size=9)
    ws.row_dimensions[row].height = h
    return row + 1


# ── Classification ─────────────────────────────────────────────
def to_float(v):
    try: return float(str(v).replace(',','').replace('$','').strip())
    except: return None

def stage_lc(stage_raw):
    s = stage_raw.upper()
    if 'L1' in s and 'SL' not in s:  return "Initial Request Information",                              False
    if 'L2' in s and 'SL' not in s:  return "Architecture Alignment",                                   False
    if 'L3' in s and 'SL' not in s:  return "Demand Bundle Decomp and Conceptual Architecture",          False
    if 'L4' in s and 'SL' not in s:  return "Evaluate Outcome Achievement",                             False
    if 'SL2' in s: return "PENDING \u2014 SL2 lifecycle step not yet defined in rules file", True
    if 'SL3' in s: return "PENDING \u2014 SL3 lifecycle step not yet defined in rules file", True
    if 'SL4' in s: return "PENDING \u2014 SL4 lifecycle step not yet defined in rules file", True
    if 'L5' in s:  return "PENDING \u2014 L5 lifecycle step not yet defined in rules file",  True
    if 'SL5' in s: return "PENDING \u2014 SL5 lifecycle step not yet defined in rules file", True
    return "PENDING \u2014 Stage not recognised", True

def classify_init(row, nrb_field):
    lxl = {'4: L','5: XL'}; sm = {'1: XS','2: S','3: M'}
    init_type = str(row.get('Initiative Type','')).strip()
    ts        = str(row.get('T-Shirt Size','')).strip()
    stage     = str(row.get('Stage','')).strip()
    esi       = str(row.get('Enterprise Strategic Initiative (ESI)','')).strip()
    pc        = str(row.get('Purple Chip','')).strip()
    bc        = str(row.get('Is this request vital to business continuity?','')).strip()
    nrb       = to_float(row.get(nrb_field,''))
    status    = str(row.get('Lifecycle Status','')).strip()
    lc_step, pending = stage_lc(stage)
    esi_act = (esi != '' and esi != '0-None' and
               esi not in FY25_EXPIRED_ESI and pc != 'Purple Chip')

    if status and status not in ALLOWED_STATUSES:
        return SEG['init_excluded'], "EXCLUDED", lc_step, 'BR_STATUS_001', 'NOT MIGRATED'
    if init_type == 'Business Only Initiative':
        return SEG['init_bo'], FLOW['init_bo'], lc_step, 'BR_TE_006', MIG_SRC['init_bo']
    if bc == 'Yes':
        return SEG['init_bc'], FLOW['init_bc'], lc_step, 'BR_TE_004', MIG_SRC['init_bc']
    if pending:
        return SEG['init_pending'], f'PENDING \u2014 {lc_step}', lc_step, 'PENDING-Stage', 'PENDING'
    if pc == 'Purple Chip':
        return SEG['init_pc'], FLOW['init_pc'], lc_step, 'BR_PC_001', MIG_SRC['init_pc']
    if init_type != 'Business w/ Tech Initiative':
        return SEG['init_pending'], 'REVIEW \u2014 Unknown type', lc_step, 'REVIEW', 'REVIEW'
    if ts in lxl:
        if nrb is not None:
            if nrb < NRB_THRESHOLD_M:
                return SEG['init_stopwork'], FLOW['init_stopwork'], lc_step, 'BR_TE_002', MIG_SRC['init_stopwork']
            elif esi_act:
                return SEG['init_strat_inv'], FLOW['init_strat_inv'], lc_step, 'BR_TE_001', MIG_SRC['init_strat_inv']
            else:
                return SEG['init_stopwork'], FLOW['init_stopwork'], lc_step, 'BR_TE_002', MIG_SRC['init_stopwork']
        else:
            return SEG['init_disc_other'], FLOW['init_disc_other'], lc_step, 'BR_TE_003 (NRB blank \u2192 Disc Other)', MIG_SRC['init_disc_other']
    if ts in sm or ts == '':
        return SEG['init_disc_other'], FLOW['init_disc_other'], lc_step, 'BR_TE_003', MIG_SRC['init_disc_other']
    return SEG['init_pending'], 'REVIEW', lc_step, 'REVIEW', 'REVIEW'

def classify_epic(row):
    lxl = {'4: L','5: XL'}; sm = {'1: XS','2: S','3: M'}
    MED = "3: Medium = $1M < Value < $10M"
    wt    = str(row.get('Work Type','')).strip()
    ts    = str(row.get('T-Shirt Size','')).strip()
    stage = str(row.get('Stage','')).strip()
    vr    = str(row.get('Estimated Annualized Value Range','')).strip()
    ws    = str(row.get('Work Status','')).strip()
    lc_step, pending = stage_lc(stage)

    if ws in EPIC_EXCL_STATUSES:
        return SEG['epic_excluded'], "EXCLUDED", lc_step, 'BR_STATUS_001', 'NOT MIGRATED'
    if pending:
        return SEG['epic_pending'], f'PENDING \u2014 {lc_step}', lc_step, 'PENDING-Stage', 'PENDING'
    if wt == 'Lifecycle Management Epic':
        return SEG['lcm'], FLOW['lcm'], lc_step, 'BR_TE_LCM_001', MIG_SRC['lcm']
    if wt == 'Local Enhancement Epic':
        if ts in lxl:
            if vr == MED:
                return SEG['le_stopwork'], FLOW['le_stopwork'], lc_step, 'BR_TE_LE_003 (value range proxy)', MIG_SRC['le_stopwork']
            return SEG['le_strat'], FLOW['le_strat'], lc_step, 'BR_TE_LE_001', MIG_SRC['le_strat']
        rule = 'BR_TE_LE_005' if ts in sm else 'BR_BLANK_001'
        return SEG['le_disc'], FLOW['le_disc'], lc_step, rule, MIG_SRC['le_disc']
    return SEG['epic_pending'], 'REVIEW', lc_step, 'REVIEW', 'REVIEW'


# ── Tab builders ──────────────────────────────────────────────

def build_readme(wb, input_path, rules_path, run_ts, df_in, df_ep):
    ws = wb.create_sheet("README")
    r = title_block(ws, 1,
        "Planview Migration Prototype",
        f"Input: {Path(input_path).name}   |   Rules: {Path(rules_path).name}   |   Generated: {run_ts}",
        cols=4)

    for i, w in enumerate([28, 55, 20, 18], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    rows = [
        ("PURPOSE","","",""),
        ("What this file shows",
         "Every Initiative and Epic from the input file classified against the business rules "
         "defined in the rules file. Shows the target migration path, lifecycle step, output "
         "segment, and rule applied for each record.",
         "",""),
        ("","","",""),
        ("SOURCE FILES","","",""),
        ("Input file",    Path(input_path).name, "Initiatives", f"{len(df_in):,} records"),
        ("",              "",                     "Epics",       f"{len(df_ep):,} records"),
        ("Rules file",    Path(rules_path).name,  "Sheets used",
         "Business_Rules | Lifecycle_Step_Index | Prod Fields | VALUES_DropDowns_Mappings_2026"),
        ("","","",""),
        ("TABS IN THIS WORKBOOK","","",""),
        ("README",              "This sheet \u2014 purpose and guide",                            "",""),
        ("Source_Attribution",  "Which rule was sourced from which sheet of the rules file",      "",""),
        ("Business_Rules",      "Rules applied in classification \u2014 conditions and output",   "",""),
        ("Lifecycle_Steps",     "Tech-Enabled lifecycle steps used for stage mapping",            "",""),
        ("Scenario_Rules",      "Migration path decision table \u2014 priority order and logic",  "",""),
        ("Validation_Rules",    "Field derivation, assumptions, and classification logic",        "",""),
        ("SQL_Logic",           "Transformation SQL matching the classification logic",           "",""),
        ("Initiatives_Final",   "Initiatives ready to migrate",                                   "",""),
        ("Initiatives_Hold",    "Initiatives on hold \u2014 Stop Work + Purple Chip",             "",""),
        ("Initiatives_Review",  "Initiatives pending lifecycle step definition",                  "",""),
        ("Epics_Final",         "Epics ready to migrate",                                         "",""),
        ("Epics_Hold",          "Epics on hold \u2014 NRB Value Range Conflict",                  "",""),
        ("Epics_Review",        "Epics pending lifecycle step definition",                         "",""),
        ("Summary",             "Record counts and open items requiring customer decisions",       "",""),
    ]

    r = hdr_row(ws, r, ["Item","Detail","Sub-item","Count / Value"], [28,55,20,18])
    for row_data in rows:
        label, detail, sub, count = row_data
        if not label and not detail:
            ws.row_dimensions[r].height = 8; r += 1; continue
        if detail == "" and label in ("PURPOSE","SOURCE FILES","TABS IN THIS WORKBOOK"):
            r = sec_row(ws, r, label, 4); continue
        is_hdr = label in ("Input file","Rules file")
        bg = GL if is_hdr else "FFFFFF"
        sc(ws, r, 1, label,  bold=is_hdr, bg=bg, size=9)
        sc(ws, r, 2, detail, bg=bg, size=9)
        sc(ws, r, 3, sub,    bg=bg, size=9, color=GRD, italic=True)
        sc(ws, r, 4, count,  bg=bg, size=9, color=GRD)
        ws.row_dimensions[r].height = 30
        r += 1


def build_source_attribution(wb, rules_path):
    ws = wb.create_sheet("Source_Attribution")
    r = title_block(ws, 1,
        "Source Attribution",
        f"Every rule and logic element traced to its source sheet in: {Path(rules_path).name}",
        cols=4)

    for i, w in enumerate([22, 35, 35, 22], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = hdr_row(ws, r, ["Prototype Tab", "What It Contains",
                         "Source Sheet in Rules File", "Rule IDs"], [22,35,35,22])

    rows = [
        ("Business_Rules",
         "Classification rules: conditions, output segment, target flow",
         "Business_Rules sheet",
         "BR_STATUS_001, BR_TE_001\u2013006, BR_PC_001, BR_TE_LE_001/003/005, BR_TE_LCM_001, BR_BLANK_001",
         GL, GD),
        ("Lifecycle_Steps",
         "Target lifecycle step per stage (Column 1 approach)",
         "Lifecycle_Step_Index sheet \u2014 Tech Enabled track",
         "L1: Initial Request Info | L2: Architecture Alignment | L3: Demand Bundle Decomp | L4: Evaluate Outcome Achievement",
         GL, GD),
        ("Scenario_Rules",
         "Migration path decision table with priority order",
         "Business_Rules sheet (Conditions parsed column)",
         "BR_TE_004 \u2192 BR_PC_001 \u2192 BR_TE_002 \u2192 BR_TE_001 \u2192 BR_TE_003",
         "FFFFFF", "000000"),
        ("Validation_Rules",
         "Status exclusion, ESI definition, stage mapping, assumptions",
         "Business_Rules sheet + VALUES_DropDowns_Mappings_2026 + Lifecycle_Step_Index",
         "BR_STATUS_001, BR_TE_001 parsed conditions, Lifecycle_Step_Index",
         "FFFFFF", "000000"),
        ("SQL_Logic",
         "Transformation SQL implementing the classification logic",
         "Business_Rules sheet (classification conditions converted to SQL)",
         "All applied rules",
         "FFFFFF", "000000"),
        ("Initiatives_Final / Hold / Review",
         "Real Initiative records from input file classified by business rules",
         "Input file: L1-L4 Planview Inits Data Pull sheet",
         "Classification output",
         GL, GD),
        ("Epics_Final / Hold / Review",
         "Real Epic records from input file classified by business rules",
         "Input file: Local and LCM sheet",
         "Classification output",
         GL, GD),
        ("Drop columns applied",
         "21 Adjusted/Non-GAAP calculated fields removed from output",
         "Prod Fields sheet \u2014 Migrate? = N-Calc",
         "All Adj Non-GAAP / Adjusted Net fields",
         RL, RD),
        ("Field renames applied",
         "None \u2014 rules file defines no field rename mapping. Source field names carried as-is.",
         "Prod Fields + new instance fields sheets (no rename spec found)",
         "N/A",
         AL, AD),
    ]

    for tab, content, source, rules, bg, tc in rows:
        sc(ws, r, 1, tab,     bold=True, bg=bg, color=tc, size=9)
        sc(ws, r, 2, content, bg=bg, size=9)
        sc(ws, r, 3, source,  bg=bg, size=9, italic=True, color=GRD)
        sc(ws, r, 4, rules,   bg=bg, size=9, color=GRD)
        ws.row_dimensions[r].height = 45
        r += 1


def build_business_rules(wb, rules_path):
    ws = wb.create_sheet("Business_Rules")
    r = title_block(ws, 1,
        "Business Rules Applied \u2014 Classification Logic",
        f"Source: {Path(rules_path).name} \u2192 Business_Rules sheet | Only rules applied in classification shown",
        cols=6)

    hdrs = ["Rule ID", "Applies To", "Condition", "Output Segment", "Target Flow", "Notes"]
    widths = [16, 14, 52, 28, 36, 30]
    r = hdr_row(ws, r, hdrs, widths)

    rules_data = [
        ("SEC", "STATUS EXCLUSION \u2014 BR_STATUS_001"),
        ("BR_STATUS_001", "Initiative",
         "Lifecycle Status NOT IN {'Active'}\nAll other statuses excluded from migration",
         SEG['init_excluded'], "NOT MIGRATED",
         "Current input file is 100% Active \u2014 no records excluded. Logic coded for future files.", RL, RD),
        ("BR_STATUS_001", "Epic",
         "Work Status IN {'Cancelled','Rejected','Completed/Closed'}\nNote: Approved / Not Started / In Progress are valid active Epic statuses",
         SEG['epic_excluded'], "NOT MIGRATED",
         "Current input file has no excluded Epics.", RL, RD),

        ("SEC", "INITIATIVE RULES \u2014 Priority order (top to bottom)"),
        ("BR_TE_006", "Initiative\nBusiness Only",
         "Initiative Type = 'Business Only Initiative'\nRuns first \u2014 before all BwT rules",
         SEG['init_bo'], FLOW['init_bo'],
         "1 record in input file.", GL, GD),
        ("BR_TE_004", "Initiative\nBwT",
         "Is this request vital to business continuity? = 'Yes'\nRuns FIRST among BwT rules\nCovers all stages including L4, L5, SL2\u2013SL5",
         SEG['init_bc'], FLOW['init_bc'],
         "88 records. Fires before pending stage check so L4/SL BC records are correctly captured.", GL, GD),
        ("PENDING", "Initiative\nBwT",
         "Stage IN {SL2, SL3, SL4, L5, SL5} AND BC \u2260 Yes\nL4 is NOT pending \u2014 lifecycle step now defined in rules file as: Evaluate Outcome Achievement",
         SEG['init_pending'], "PENDING \u2014 Lifecycle step not defined in rules file",
         "17 records: SL2(7) + SL3(9) + SL4(6). L4 resolved \u2014 Evaluate Outcome Achievement.", AL, AD),
        ("BR_PC_001", "Initiative\nBwT",
         "Purple Chip = 'Purple Chip'\nNon-BC, non-pending BwT Initiatives only\nSource: FDXSANDBOXA \u2192 New Prod",
         SEG['init_pc'], FLOW['init_pc'],
         "407 records flagged. Not auto-migrated. ESPM owns Pilot Sandbox path.", PL, PD),
        ("BR_TE_002", "Initiative\nBwT",
         "Initiative Type = Business w/Tech\nAND T-shirt IN {L, XL}\nAND NRB < $10M\nNRB field: L1 Net Recurring Benefits ($, annualized)-P&L/Hard\n[NRB field pending Finance confirmation \u2014 open item in rules file]",
         SEG['init_stopwork'], FLOW['init_stopwork'],
         "54 records in Hold. 37 have NRB=$0 \u2014 may be missing data.", RL, RD),
        ("BR_TE_001", "Initiative\nBwT",
         "Initiative Type = Business w/Tech\nAND T-shirt IN {L, XL} AND NRB \u2265 $10M\nAND ESI is active (not Purple Chip, not FY25 expired, not blank/0-None)\nConfirmed in rules file BR_TE_001 parsed conditions",
         SEG['init_strat_inv'], FLOW['init_strat_inv'],
         "13 records.", GL, GD),
        ("BR_TE_003\nBR_BLANK_001", "Initiative\nBwT",
         "Initiative Type = Business w/Tech\nAND T-shirt IN {XS, S, M} or blank\nM explicitly confirmed included in rules file\nAlso: blank NRB on L/XL defaults to Disc Other",
         SEG['init_disc_other'], FLOW['init_disc_other'],
         "383 records. Catch-all for Disc Other including blank T-shirt.", GL, GD),

        ("SEC", "LE EPIC RULES \u2014 applied after status and pending stage check"),
        ("BR_TE_LE_001", "Epic\nLE",
         "Work Type = Local Enhancement Epic\nAND T-shirt IN {L, XL}\nAND Estimated Annualized Value Range \u2260 Medium",
         SEG['le_strat'], FLOW['le_strat'],
         "127 records. Execution Type = Demand Bundle Epic at PPL+2.", GL, GD),
        ("BR_TE_LE_003", "Epic\nLE",
         "Work Type = Local Enhancement Epic\nAND T-shirt IN {L, XL}\nAND Estimated Annualized Value Range = Medium ($1M\u2013$10M)\n[Proxy: exact NRB not available in Epic sheet]",
         SEG['le_stopwork'], FLOW['le_stopwork'],
         "6 records. NRB Value Range Conflict \u2014 all 6 pre-classified by customer as Disc Transformational Inv.", RL, RD),
        ("BR_TE_LE_005\nBR_BLANK_001", "Epic\nLE",
         "Work Type = Local Enhancement Epic\nAND T-shirt IN {XS, S, M} or blank\nM confirmed included in rules file",
         SEG['le_disc'], FLOW['le_disc'],
         "2,768 records. Includes 432 blank T-shirt records.", GL, GD),

        ("SEC", "LCM EPIC RULES"),
        ("BR_TE_LCM_001", "Epic\nLCM",
         "Work Type = Lifecycle Management Epic\nDirect map \u2014 no additional conditions\nPending stage check fires FIRST to catch SL3/SL4 LCM Epics",
         SEG['lcm'], FLOW['lcm'],
         "743 records. 66 LCM Epics at SL3/SL4 in Review/Pending.", GL, GD),

        ("SEC", "STAGE \u2192 LIFECYCLE STEP MAPPING (Lifecycle_Step_Index \u2014 Tech Enabled track)"),
        ("L1", "Init / Epic",
         "Stage LIKE '%L1%' AND NOT LIKE '%SL%'",
         "", "Initial Request Information",
         "Source: Tech Enabled L1 tab \u2014 Lifecycle_Step_Index.", GL, GD),
        ("L2", "Init / Epic",
         "Stage LIKE '%L2%' AND NOT LIKE '%SL%'",
         "", "Architecture Alignment",
         "Source: Tech Enabled L2 tab.", GL, GD),
        ("L3", "Init / Epic",
         "Stage LIKE '%L3%' AND NOT LIKE '%SL%'",
         "", "Demand Bundle Decomp and Conceptual Architecture",
         "Source: Tech Enabled L3 tab.", GL, GD),
        ("L4", "Init / Epic",
         "Stage LIKE '%L4%' AND NOT LIKE '%SL%'",
         "", "Evaluate Outcome Achievement",
         "Source: Tech Enabled L4 tab. NEWLY DEFINED in rules file. Previously undefined.", GL, GD),
        ("SL2/SL3/SL4", "Init / Epic",
         "Stage LIKE '%SL2%' OR '%SL3%' OR '%SL4%'",
         SEG['init_pending'], "PENDING \u2014 Not defined in rules file",
         "0 rows for SL stages in Lifecycle_Step_Index. 352 records pending.", AL, AD),
    ]

    for entry in rules_data:
        if entry[0] == "SEC":
            r = sec_row(ws, r, entry[1], 6); continue
        rid, entity, cond, seg, flow, notes, bg, tc = entry
        sc(ws, r, 1, rid,    bold=True, bg=bg, color=tc, size=9, ha="center")
        sc(ws, r, 2, entity, bg=bg, color=tc, size=9, ha="center", bold=True)
        sc(ws, r, 3, cond,   bg=bg, size=9)
        sc(ws, r, 4, seg,    bold=True, bg=bg, color=tc, size=9)
        sc(ws, r, 5, flow,   bg=bg, size=9, italic=True)
        sc(ws, r, 6, notes,  bg=bg, size=9, color=GRD, italic=True)
        ws.row_dimensions[r].height = 65
        r += 1


def build_lifecycle_steps(wb, rules_path):
    ws = wb.create_sheet("Lifecycle_Steps")
    r = title_block(ws, 1,
        "Lifecycle Steps \u2014 Tech Enabled Track",
        f"Source: {Path(rules_path).name} \u2192 Lifecycle_Step_Index sheet | Tech Enabled track only | Column 1 (first step per stage) used for migration mapping",
        cols=5)

    hdrs = ["Stage", "Op Model Step", "Lifecycle Step Name", "Target Entity", "Used in Classification"]
    widths = [10, 35, 45, 22, 22]
    r = hdr_row(ws, r, hdrs, widths)

    df_lc = pd.read_excel(rules_path, sheet_name='Lifecycle_Step_Index', dtype=str, header=0).fillna('')
    te = df_lc[df_lc['Source File'].str.contains('Tech Enabled', na=False)]

    stage_bg  = {"L1": GL, "L2": LBLUE, "L3": PL, "L4": AL}
    col1_steps = {"L1": "Initial Request Information",
                  "L2": "Architecture Alignment",
                  "L3": "Demand Bundle Decomp and Conceptual Architecture",
                  "L4": "Evaluate Outcome Achievement"}

    for _, row in te.iterrows():
        stage  = str(row.get('Lifecycle Stage','')).strip()
        op     = str(row.get('Op Model Step','')).strip()
        step   = str(row.get('Lifecycle Step Name','')).strip()
        entity = str(row.get('Target Entity','')).strip()
        if not step and not op: continue

        bg = stage_bg.get(stage, GRL)
        if stage in col1_steps and step == col1_steps[stage]:
            used = "\u2605 COLUMN 1 \u2014 Used in migration mapping"
            tc = GD
            if stage == 'L4':
                used = "\u2605 COLUMN 1 \u2014 NEWLY DEFINED in rules file"
                tc = AD
        else:
            used = "Reference step"
            tc = GRD

        vals = [stage, op, step, entity, used]
        bgs  = [bg] * 5
        tcs  = ["000000","000000","000000","000000", tc]
        dr(ws, r, vals, bgs, tcs, h=30)
        r += 1


def build_scenario_rules(wb, rules_path):
    ws = wb.create_sheet("Scenario_Rules")
    r = title_block(ws, 1,
        "Scenario Rules \u2014 Migration Path Decision Table",
        f"Source: {Path(rules_path).name} \u2192 Business_Rules sheet | Priority order applied top to bottom",
        cols=6)

    hdrs = ["Priority", "Condition", "Output Segment", "Target Flow", "Migration Action", "Rule Reference"]
    widths = [10, 52, 28, 36, 30, 18]
    r = hdr_row(ws, r, hdrs, widths)

    sections = [
        ("STATUS EXCLUSION \u2014 applies before all classification rules", [
            ("E1",
             "Lifecycle Status NOT IN {'Active'} (Initiative)\nWork Status IN {'Cancelled','Rejected','Completed/Closed'} (Epic)",
             "EXCLUDED-Status", "NOT MIGRATED",
             "Record excluded. Do not migrate.", "BR_STATUS_001", RL, RD),
        ]),
        ("INITIATIVE RULES \u2014 Business Only fires first, then BC, then pending check, then BwT rules", [
            ("I1",
             "Initiative Type = 'Business Only Initiative'",
             SEG['init_bo'], FLOW['init_bo'],
             "Migrate FDXPROD / ESPM \u2192 New Prod", "BR_TE_006", GL, GD),
            ("I2",
             "Is this request vital to business continuity? = 'Yes'\nFires before pending stage check\nRules file: covers L1, L2, L3, L4, L5, SL2\u2013SL5",
             SEG['init_bc'], FLOW['init_bc'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_004", GL, GD),
            ("I3",
             "Stage IN {SL2, SL3, SL4, L5, SL5} AND BC \u2260 Yes\nNote: L4 is NOT pending \u2014 Evaluate Outcome Achievement defined in Lifecycle_Step_Index",
             SEG['init_pending'], "PENDING",
             "Hold in Review. Awaiting lifecycle step definition for SL/L5 stages in rules file.", "PENDING-Stage", AL, AD),
            ("I4",
             "Purple Chip = 'Purple Chip'\n(non-BC, non-pending BwT only)\nSource: FDXSANDBOXA \u2192 New Prod",
             SEG['init_pc'], FLOW['init_pc'],
             "Flag for Pilot Sandbox path. Not auto-migrated. ESPM owns.", "BR_PC_001", PL, PD),
            ("I5",
             "Initiative Type = Business w/Tech\nAND T-shirt IN {L, XL} AND NRB < $10M\n[NRB field: L1 Net Recurring Benefits P&L/Hard \u2014 pending Finance confirmation]",
             SEG['init_stopwork'], FLOW['init_stopwork'],
             "HOLD \u2014 Finance/Triage sign-off required before migration.", "BR_TE_002", RL, RD),
            ("I6",
             "Initiative Type = Business w/Tech AND ESI active\nAND T-shirt IN {L, XL} AND NRB \u2265 $10M\nESI active confirmed: not Purple Chip, not FY25 expired, not blank/0-None",
             SEG['init_strat_inv'], FLOW['init_strat_inv'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_001", GL, GD),
            ("I7",
             "Initiative Type = Business w/Tech\nAND T-shirt IN {XS, S, M} or blank\nM confirmed included in rules file\nAlso: blank NRB on L/XL \u2192 Disc Other",
             SEG['init_disc_other'], FLOW['init_disc_other'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_003 / BR_BLANK_001", GL, GD),
        ]),
        ("LE EPIC RULES \u2014 status and pending stage check fire first", [
            ("LE1",
             "Work Type = Local Enhancement Epic\nT-shirt IN {L, XL} AND Value Range \u2260 Medium",
             SEG['le_strat'], FLOW['le_strat'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_LE_001", GL, GD),
            ("LE2",
             "Work Type = Local Enhancement Epic\nT-shirt IN {L, XL} AND Value Range = Medium ($1M\u2013$10M)\n[Proxy for NRB < $10M \u2014 exact NRB not available in Epic sheet]",
             SEG['le_stopwork'], FLOW['le_stopwork'],
             "HOLD \u2014 Confirm exact NRB with Finance", "BR_TE_LE_003 (proxy)", RL, RD),
            ("LE3",
             "Work Type = Local Enhancement Epic\nT-shirt IN {XS, S, M} or blank (M confirmed included)",
             SEG['le_disc'], FLOW['le_disc'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_LE_005 / BR_BLANK_001", GL, GD),
        ]),
        ("LCM EPIC RULES \u2014 pending stage check fires first", [
            ("LCM1",
             "Work Type = Lifecycle Management Epic\nDirect map \u2014 no conditions\nPending check fires first: SL3/SL4 LCM Epics go to Review",
             SEG['lcm'], FLOW['lcm'],
             "Migrate FDXPROD \u2192 New Prod", "BR_TE_LCM_001", GL, GD),
        ]),
        ("PENDING STAGE \u2014 applies to BOTH LCM and LE Epics before work type rules", [
            ("EP1",
             "Stage IN {SL3, SL4}\nNote: L4 Epics are NOT pending \u2014 Evaluate Outcome Achievement defined in rules file",
             SEG['epic_pending'], "PENDING",
             "Hold in Review. SL3(240) + SL4(95) = 335 records.", "PENDING-Stage", AL, AD),
        ]),
    ]

    for sec_title, rules in sections:
        r = sec_row(ws, r, sec_title, 6)
        for pri, cond, seg, flow, action, ref, bg, tc in rules:
            sc(ws, r, 1, pri,    bold=True, bg=bg, color=tc, size=9, ha="center")
            sc(ws, r, 2, cond,   bg=bg, size=9)
            sc(ws, r, 3, seg,    bold=True, bg=bg, color=tc, size=9)
            sc(ws, r, 4, flow,   bg=bg, size=9, italic=True)
            sc(ws, r, 5, action, bg=bg, size=9)
            sc(ws, r, 6, ref,    bg=bg, size=9, color=GRD, italic=True, ha="center")
            ws.row_dimensions[r].height = 60
            r += 1


def build_validation_rules(wb, rules_path):
    ws = wb.create_sheet("Validation_Rules")
    r = title_block(ws, 1,
        "Validation Rules \u2014 Field Derivation and Assumptions",
        f"Source: {Path(rules_path).name} | Business_Rules sheet | Lifecycle_Step_Index | VALUES_DropDowns_Mappings_2026",
        cols=5)

    hdrs = ["Rule", "Source Field(s)", "Condition / Logic", "Result", "Source Reference"]
    widths = [12, 28, 48, 30, 30]
    r = hdr_row(ws, r, hdrs, widths)

    vr_sections = [
        ("STATUS PRE-FILTER \u2014 BR_STATUS_001", [
            ("S1", "Lifecycle Status (Initiative)",
             "Lifecycle Status NOT IN {'Active'}",
             "EXCLUDED \u2014 do not migrate",
             "Rules file: VALUES_DropDowns_Mappings_2026 confirms status values", RL, RD),
            ("S2", "Work Status (Epic)",
             "Work Status IN {'Cancelled','Rejected','Completed/Closed'}\nNote: Approved / Not Started / In Progress are valid active Epic statuses \u2014 not excluded",
             "EXCLUDED \u2014 do not migrate",
             "Rules file: VALUES_DropDowns_Mappings_2026 confirms Epic status values", RL, RD),
        ]),
        ("ASSUMPTIONS \u2014 confirmed defaults applied in classification", [
            ("A1", "Is this request vital to business continuity?",
             "Field is blank for 428 of 960 Initiative records",
             "Blank = No \u2014 treated as not BC",
             "Assumption \u2014 awaiting formal customer confirmation", AL, AD),
            ("A2", "L1 Net Recurring Benefits ($, annualized)-P&L/Hard",
             "NRB field is blank for some L/XL BwT Initiatives",
             "Blank NRB = Discretionary Other (not Stop Work)",
             "Assumption \u2014 awaiting formal customer confirmation", AL, AD),
            ("A3", "NRB field selection",
             "Rules file BR_TE_002 notes still ask: 'What field are we using for NRB?'\nCurrent assumption: L1 Net Recurring Benefits P&L/Hard (918/960 populated)",
             "Using L1 NRB Hard as NRB field\n[OPEN ITEM \u2014 Finance to confirm]",
             "Rules file: BR_TE_002 Notes column \u2014 unresolved", RL, RD),
        ]),
        ("ESI ACTIVE DEFINITION \u2014 confirmed in rules file BR_TE_001 parsed conditions", [
            ("E1", "Enterprise Strategic Initiative (ESI)",
             "ESI active = NOT Purple Chip AND NOT FY25 expired AND NOT blank/0-None\nFY25 expired ESIs: Network Optimization, Digital Intelligence, Europe Operations, Digital Experience",
             "Confirmed by rules file: 'ESI NOT CONTAINS Purple Chip AND ESI = Expired (FY25) OR NULL'",
             "Rules file: Business_Rules sheet \u2014 BR_TE_001 Conditions (parsed) column", GL, GD),
        ]),
        ("STAGE \u2192 TARGET LIFECYCLE STEP MAPPING \u2014 Column 1 approach (first step per stage)", [
            ("L1", "Stage field",
             "Stage LIKE '%L1%' AND NOT LIKE '%SL%'",
             "Initial Request Information",
             "Rules file: Lifecycle_Step_Index \u2014 Tech Enabled L1 tab", GL, GD),
            ("L2", "Stage field",
             "Stage LIKE '%L2%' AND NOT LIKE '%SL%'",
             "Architecture Alignment",
             "Rules file: Lifecycle_Step_Index \u2014 Tech Enabled L2 tab", GL, GD),
            ("L3", "Stage field",
             "Stage LIKE '%L3%' AND NOT LIKE '%SL%'",
             "Demand Bundle Decomp and Conceptual Architecture",
             "Rules file: Lifecycle_Step_Index \u2014 Tech Enabled L3 tab", GL, GD),
            ("L4", "Stage field",
             "Stage LIKE '%L4%' AND NOT LIKE '%SL%'\nNEWLY DEFINED in rules file",
             "Evaluate Outcome Achievement",
             "Rules file: Lifecycle_Step_Index \u2014 Tech Enabled L4 tab", GL, GD),
            ("SL2/SL3/SL4", "Stage field",
             "Stage LIKE '%SL2%' OR '%SL3%' OR '%SL4%'",
             "PENDING \u2014 0 rows in Lifecycle_Step_Index for SL stages\n352 records in Review/Pending",
             "Rules file: Lifecycle_Step_Index \u2014 no SL entries defined", AL, AD),
        ]),
        ("DERIVED OUTPUT FIELDS \u2014 added to every record by classification", [
            ("D1", "All records", "Rule applied to record",
             "Output_Segment \u2014 classification code e.g. TE-NonDisc-BusinessContinuity",
             "Rules file: Business_Rules \u2014 Target Flow column", GL, GD),
            ("D2", "All records", "Rule applied to record",
             "Future_State_Flow \u2014 exact flow type from rules file",
             "Rules file: Business_Rules \u2014 Target Flow column", GL, GD),
            ("D3", "All records", "Stage field mapping",
             "Target_Lifecycle_Step \u2014 first lifecycle step for target stage",
             "Rules file: Lifecycle_Step_Index sheet", GL, GD),
            ("D4", "All records", "Rule applied to record",
             "Rule_ID_Applied \u2014 e.g. BR_TE_004, BR_PC_001",
             "Rules file: Business_Rules sheet \u2014 Rule ID column", GL, GD),
            ("D5", "Epic records only", "Stage field",
             "Kanban_Status: L3 \u2192 Solution Analysis | others \u2192 Intake/New",
             "Rules file: Business_Rules \u2014 Epic below-PPL rules", GL, GD),
            ("D6", "Epic records only", "Stage field",
             "EPG_Approval: L3 \u2192 Yes | others blank",
             "Rules file: Business_Rules \u2014 Epic below-PPL rules", GL, GD),
        ]),
    ]

    for sec_title, vr_rules in vr_sections:
        r = sec_row(ws, r, sec_title, 5)
        for items in vr_rules:
            rule, src, cond, result, ref, bg, tc = items
            sc(ws, r, 1, rule,   bold=True, bg=bg, color=tc, size=9, ha="center")
            sc(ws, r, 2, src,    bg=bg, size=9)
            sc(ws, r, 3, cond,   bg=bg, size=9)
            sc(ws, r, 4, result, bg=bg, size=9)
            sc(ws, r, 5, ref,    bg=bg, size=9, color=GRD, italic=True)
            ws.row_dimensions[r].height = 55
            r += 1

    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def build_sql_logic(wb, rules_path):
    ws = wb.create_sheet("SQL_Logic")
    r = title_block(ws, 1,
        "SQL Logic \u2014 Transformation Script",
        f"Classification logic converted to SQL | Rules source: {Path(rules_path).name} \u2192 Business_Rules sheet",
        cols=2)
    ws.column_dimensions['A'].width = 14
    ws.column_dimensions['B'].width = 115

    blocks = [
        ("HEADER", f"""-- ============================================================
-- Planview Migration \u2014 Transformation SQL
-- Rules source: {Path(rules_path).name}
--   Business_Rules sheet \u2014 classification conditions
--   Lifecycle_Step_Index sheet \u2014 stage to lifecycle step mapping
--   VALUES_DropDowns_Mappings_2026 \u2014 status field values
-- ============================================================
-- Key rules applied:
--   BR_STATUS_001  : Active only \u2014 pre-filter before classification
--   BR_TE_006      : Business Only \u2192 Business Demand Management
--   BR_TE_004      : Business Continuity \u2192 Non-Disc BC (fires first, covers L4/L5/SL)
--   BR_PC_001      : Purple Chip \u2192 Pilot Sandbox path
--   BR_TE_002      : Stop Work (L/XL + NRB < $10M)
--   BR_TE_001      : Strategic Investment (ESI active + L/XL + NRB \u2265 $10M)
--   BR_TE_003      : Discretionary Other (T-shirt \u2264 M or blank)
--   BR_TE_LCM_001  : LCM Epics \u2192 Run the Business
--   BR_TE_LE_001   : LE L/XL \u2192 Transformational Investment
--   BR_TE_LE_003   : LE L/XL + NRB proxy < $10M \u2192 Stop Work
--   BR_TE_LE_005   : LE \u2264 M \u2192 Discretionary Other
--   BR_BLANK_001   : Blank T-shirt \u2192 Discretionary Other
-- Stage mapping (Lifecycle_Step_Index \u2014 Tech Enabled, Column 1):
--   L1 \u2192 Initial Request Information
--   L2 \u2192 Architecture Alignment
--   L3 \u2192 Demand Bundle Decomp and Conceptual Architecture
--   L4 \u2192 Evaluate Outcome Achievement  [defined in rules file]
--   SL2/SL3/SL4 \u2192 PENDING (not defined in rules file)
-- ============================================================"""),

        ("STEP 1", """-- STEP 1: Status exclusion (BR_STATUS_001)
-- Status values from VALUES_DropDowns_Mappings_2026 sheet

-- Initiatives: Active only
IF OBJECT_ID('tempdb..#Init_Active') IS NOT NULL DROP TABLE #Init_Active;
SELECT * INTO #Init_Active
FROM [input_schema].[EA_Request_Initiatives]
WHERE [Lifecycle Status] = 'Active';

-- Epics: exclude terminal statuses
-- Note: Approved / Not Started / In Progress are valid active Epic statuses
IF OBJECT_ID('tempdb..#Epic_Active') IS NOT NULL DROP TABLE #Epic_Active;
SELECT * INTO #Epic_Active
FROM [input_schema].[EA_Request_Epics]
WHERE [Work Status] NOT IN ('Cancelled','Rejected','Completed/Closed');"""),

        ("STEP 2", """-- STEP 2: Initiative classification
-- Stage \u2192 Lifecycle Step mapping (Lifecycle_Step_Index \u2014 Tech Enabled track, Column 1)
-- L4 now defined: Evaluate Outcome Achievement
-- SL2/SL3/SL4/L5/SL5: PENDING (not defined in rules file)

WITH init_staged AS (
    SELECT *,
    CASE
        WHEN [Stage] LIKE '%L1%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Initial Request Information'
        WHEN [Stage] LIKE '%L2%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Architecture Alignment'
        WHEN [Stage] LIKE '%L3%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Demand Bundle Decomp and Conceptual Architecture'
        WHEN [Stage] LIKE '%L4%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Evaluate Outcome Achievement'
        WHEN [Stage] LIKE '%SL2%' THEN 'PENDING \u2014 SL2 not defined in rules file'
        WHEN [Stage] LIKE '%SL3%' THEN 'PENDING \u2014 SL3 not defined in rules file'
        WHEN [Stage] LIKE '%SL4%' THEN 'PENDING \u2014 SL4 not defined in rules file'
        WHEN [Stage] LIKE '%L5%'  THEN 'PENDING \u2014 L5 not defined in rules file'
        ELSE 'PENDING \u2014 Stage not recognised'
    END AS [Target_Lifecycle_Step],
    CASE
        WHEN [Stage] LIKE '%SL2%' OR [Stage] LIKE '%SL3%'
          OR [Stage] LIKE '%SL4%' OR [Stage] LIKE '%L5%'
        THEN 1 ELSE 0
    END AS [Is_Stage_Pending]
    FROM #Init_Active
),
init_classified AS (
    SELECT *,
    CASE
        -- BR_TE_006: Business Only (fires first)
        WHEN [Initiative Type] = 'Business Only Initiative'
            THEN 'TE-BusinessDemandMgmt'

        -- BR_TE_004: Business Continuity (fires first among BwT rules)
        -- Rules file: covers L1,L2,L3,L4,L5,SL2,SL3,SL4,SL5
        WHEN [Is this request vital to business continuity?] = 'Yes'
            THEN 'TE-NonDisc-BusinessContinuity'

        -- Pending stages: SL/L5 only (L4 now classified above)
        WHEN [Is_Stage_Pending] = 1
            THEN 'PENDING-Stage-Lifecycle-Undefined'

        -- BR_PC_001: Purple Chip \u2192 Pilot Sandbox
        WHEN [Purple Chip] = 'Purple Chip'
            THEN 'PC-StrategicProgram-PilotSandbox'

        -- BR_TE_002: Stop Work (L/XL + NRB < $10M)
        -- NRB field: L1 Net Recurring Benefits ($, annualized)-P&L/Hard
        -- [NRB field pending Finance confirmation \u2014 open item in rules file]
        WHEN [Initiative Type] = 'Business w/ Tech Initiative'
          AND [T-Shirt Size] IN ('4: L','5: XL')
          AND TRY_CAST(REPLACE(REPLACE([L1 Net Recurring Benefits ($, annualized)-P&L/Hard],',',''),'$','') AS DECIMAL(18,2)) < 10
            THEN 'TE-Disc-StopWork-HOLD'

        -- BR_TE_001: Strategic Investment (ESI active + L/XL + NRB >= $10M)
        -- ESI active: not Purple Chip, not FY25 expired, not blank/0-None
        -- Confirmed in rules file BR_TE_001 parsed conditions
        WHEN [Initiative Type] = 'Business w/ Tech Initiative'
          AND [T-Shirt Size] IN ('4: L','5: XL')
          AND TRY_CAST(REPLACE(REPLACE([L1 Net Recurring Benefits ($, annualized)-P&L/Hard],',',''),'$','') AS DECIMAL(18,2)) >= 10
          AND [Enterprise Strategic Initiative (ESI)] NOT IN ('','0-None')
          AND [Enterprise Strategic Initiative (ESI)] NOT LIKE '%FY25 ESI%'
          AND [Purple Chip] != 'Purple Chip'
            THEN 'TE-Disc-TransformationalInvestment'

        -- BR_TE_003 + BR_BLANK_001: Discretionary Other
        -- T-shirt <= M (M confirmed included in rules file) or blank
        -- Also: blank NRB on L/XL defaults to Disc Other
        WHEN [Initiative Type] = 'Business w/ Tech Initiative'
            THEN 'TE-Disc-Other'

        ELSE 'PENDING-Stage-Lifecycle-Undefined'
    END AS [Output_Segment]
    FROM init_staged
)
SELECT
    [Output_Segment],
    CASE [Output_Segment]
        WHEN 'TE-NonDisc-BusinessContinuity'       THEN 'Non-Discretionary \u2013 Business Continuity'
        WHEN 'TE-Disc-StopWork-HOLD'               THEN 'STOP WORK Discretionary \u2013 Transformational Investment'
        WHEN 'TE-Disc-TransformationalInvestment'  THEN 'Discretionary \u2013 Transformational Investment'
        WHEN 'TE-Disc-Other'                       THEN 'Discretionary \u2013 Other'
        WHEN 'TE-BusinessDemandMgmt'               THEN 'Business Demand Management'
        WHEN 'PC-StrategicProgram-PilotSandbox'    THEN 'Strategic Program (Business + Tech) \u2014 Pilot Sandbox'
        ELSE 'PENDING'
    END AS [Future_State_Flow],
    [Target_Lifecycle_Step],
    *
FROM init_classified;"""),

        ("STEP 3", """-- STEP 3: Epic classification
-- Pending stage check fires BEFORE work type rules
-- L4 Epics now classified: Evaluate Outcome Achievement (not pending)

WITH epic_staged AS (
    SELECT *,
    CASE
        WHEN [Stage] LIKE '%L2%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Architecture Alignment'
        WHEN [Stage] LIKE '%L3%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Demand Bundle Decomp and Conceptual Architecture'
        WHEN [Stage] LIKE '%L4%' AND [Stage] NOT LIKE '%SL%'
            THEN 'Evaluate Outcome Achievement'
        WHEN [Stage] LIKE '%SL3%' THEN 'PENDING \u2014 SL3 not defined in rules file'
        WHEN [Stage] LIKE '%SL4%' THEN 'PENDING \u2014 SL4 not defined in rules file'
        ELSE 'PENDING \u2014 Stage not recognised'
    END AS [Target_Lifecycle_Step],
    CASE
        WHEN [Stage] LIKE '%SL3%' OR [Stage] LIKE '%SL4%' THEN 1 ELSE 0
    END AS [Is_Stage_Pending]
    FROM #Epic_Active
),
epic_classified AS (
    SELECT *,
    CASE
        -- Pending stage check fires FIRST (before work type rules)
        WHEN [Is_Stage_Pending] = 1
            THEN 'PENDING-Stage-Lifecycle-Undefined'

        -- BR_TE_LCM_001: LCM direct map (no conditions)
        WHEN [Work Type] = 'Lifecycle Management Epic'
            THEN 'LCM-NonDisc-RunTheBusiness'

        -- BR_TE_LE_003: LE L/XL Stop Work (value range proxy for NRB)
        -- Exact NRB not available in Epic sheet
        WHEN [Work Type] = 'Local Enhancement Epic'
          AND [T-Shirt Size] IN ('4: L','5: XL')
          AND [Estimated Annualized Value Range] = '3: Medium = $1M < Value < $10M'
            THEN 'LE-Disc-StopWork-HOLD'

        -- BR_TE_LE_001: LE L/XL Transformational Investment
        WHEN [Work Type] = 'Local Enhancement Epic'
          AND [T-Shirt Size] IN ('4: L','5: XL')
            THEN 'LE-Disc-TransformationalInvestment'

        -- BR_TE_LE_005 + BR_BLANK_001: LE <= M or blank (M confirmed included)
        WHEN [Work Type] = 'Local Enhancement Epic'
            THEN 'LE-Disc-Other'

        ELSE 'PENDING-Stage-Lifecycle-Undefined'
    END AS [Output_Segment]
    FROM epic_staged
)
SELECT
    [Output_Segment],
    CASE [Output_Segment]
        WHEN 'LCM-NonDisc-RunTheBusiness'          THEN 'Non-Discretionary - Run the Business'
        WHEN 'LE-Disc-TransformationalInvestment'  THEN 'Discretionary \u2013 Transformational Investment'
        WHEN 'LE-Disc-StopWork-HOLD'               THEN 'STOP WORK Discretionary \u2013 Transformational Investment'
        WHEN 'LE-Disc-Other'                       THEN 'Discretionary \u2013 Other'
        ELSE 'PENDING'
    END AS [Future_State_Flow],
    [Target_Lifecycle_Step],
    *
FROM epic_classified;"""),

        ("STEP 4", """-- STEP 4: Split into output sets

-- INITIATIVES
-- Final Output (525 records)
SELECT * FROM init_classified WHERE [Output_Segment] IN
    ('TE-NonDisc-BusinessContinuity','TE-Disc-TransformationalInvestment',
     'TE-Disc-Other','TE-BusinessDemandMgmt');

-- Stop Work Hold (418 records: 331 Purple Chip + 87 Stop Work)
SELECT * FROM init_classified WHERE [Output_Segment] IN
    ('TE-Disc-StopWork-HOLD','PC-StrategicProgram-PilotSandbox');

-- Review / Pending (17 records: SL2=7, SL3=9, SL4=6)
SELECT * FROM init_classified WHERE [Output_Segment] = 'PENDING-Stage-Lifecycle-Undefined';

-- EPICS
-- Final Output (3,638 records)
SELECT * FROM epic_classified WHERE [Output_Segment] IN
    ('LCM-NonDisc-RunTheBusiness','LE-Disc-TransformationalInvestment','LE-Disc-Other');

-- Stop Work Hold (6 records: NRB Value Range Conflict)
SELECT * FROM epic_classified WHERE [Output_Segment] = 'LE-Disc-StopWork-HOLD';

-- Review / Pending (335 records: SL3=240, SL4=95)
SELECT * FROM epic_classified WHERE [Output_Segment] = 'PENDING-Stage-Lifecycle-Undefined';"""),
    ]

    for step, sql in blocks:
        sc(ws, r, 1, step, bold=True, bg=LBLUE, color=NAV, size=10, ha="center")
        sc(ws, r, 2, sql, bg=GRL, size=9, ha="left", va="top", italic=(step == "HEADER"))
        ws.row_dimensions[r].height = max(15 * sql.count('\n'), 80)
        r += 1


def build_data_sheet(wb, sheet_name, df, seg_col, seg_values, tc, bg, subtitle):
    ws = wb.create_sheet(sheet_name)
    count = int((df[seg_col].isin(seg_values)).sum())
    r = title_block(ws, 1,
        f"{sheet_name.replace('_',' ')} \u2014 {count:,} records",
        subtitle, cols=min(len(df.columns), 15))

    sub = df[df[seg_col].isin(seg_values)].reset_index(drop=True)
    if sub.empty:
        ws.cell(row=r, column=1, value="No records in this category")
        return

    derived = ['Output_Segment','Future_State_Flow','Target_Lifecycle_Step',
               'Rule_ID_Applied','Migration_Source']
    src_cols = [c for c in sub.columns if c not in derived][:18]
    show_cols = derived + src_cols
    show_cols = [c for c in show_cols if c in sub.columns][:20]

    widths = [min(max(len(c), int(sub[c].astype(str).str.len().max() or 10)) + 3, 45)
              for c in show_cols]
    r = hdr_row(ws, r, show_cols, widths)

    for _, row_data in sub.iterrows():
        for i, col in enumerate(show_cols, 1):
            v = str(row_data.get(col, '')).strip()
            if v == 'nan': v = ''
            cell_bg = bg if col in derived else "FFFFFF"
            cell_tc = tc if col in derived else "000000"
            sc(ws, r, i, v, bg=cell_bg, color=cell_tc, size=9)
        ws.row_dimensions[r].height = 20
        r += 1


def build_summary(wb, df_in, df_ep, run_ts, input_path, rules_path):
    ws = wb.create_sheet("Summary")
    r = title_block(ws, 1,
        "Summary \u2014 Record Counts and Open Items",
        f"Input: {Path(input_path).name}   |   Rules: {Path(rules_path).name}   |   Run: {run_ts}",
        cols=4)

    for i, w in enumerate([40, 12, 35, 20], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    def cnt(df, col, vals):
        return int((df[col].isin(vals)).sum()) if col in df.columns else 0

    S = 'Output_Segment'
    rows = [
        ("SEC", "INITIATIVES \u2014 960 total", "", ""),
        ("Business Continuity (BR_TE_004)",       cnt(df_in,S,[SEG['init_bc']]),         "TE-NonDisc-BusinessContinuity",      ""),
        ("Strategic Investment (BR_TE_001)",       cnt(df_in,S,[SEG['init_strat_inv']]),  "TE-Disc-TransformationalInvestment", ""),
        ("Discretionary Other (BR_TE_003)",        cnt(df_in,S,[SEG['init_disc_other']]), "TE-Disc-Other",                      ""),
        ("Business Only (BR_TE_006)",              cnt(df_in,S,[SEG['init_bo']]),         "TE-BusinessDemandMgmt",              ""),
        ("TOTAL FINAL",                            "=SUM(B5:B8)",                         "",                                   ""),
        ("Purple Chip HOLD (BR_PC_001)",           cnt(df_in,S,[SEG['init_pc']]),         "PC-StrategicProgram-PilotSandbox",   ""),
        ("Stop Work HOLD (BR_TE_002)",             cnt(df_in,S,[SEG['init_stopwork']]),   "TE-Disc-StopWork-HOLD",              ""),
        ("TOTAL HOLD",                             "=SUM(B11:B12)",                       "",                                   ""),
        ("Review / Pending (SL2/SL3/SL4)",        cnt(df_in,S,[SEG['init_pending']]),    "PENDING-Stage-Lifecycle-Undefined",  "SL2(7) + SL3(9) + SL4(6)"),
        ("Excluded (Status)",                      cnt(df_in,S,[SEG['init_excluded']]),   "EXCLUDED-Status",                    "Current file 100% Active"),
        ("TOTAL INITIATIVES",                      "",                                    "960",                                ""),
        ("GAP","","",""),
        ("SEC", "EPICS \u2014 3,979 total", "", ""),
        ("LCM Run the Business (BR_TE_LCM_001)",       cnt(df_ep,S,[SEG['lcm']]),         "LCM-NonDisc-RunTheBusiness",         ""),
        ("LE Transformational Investment (BR_TE_LE_001)",cnt(df_ep,S,[SEG['le_strat']]),  "LE-Disc-TransformationalInvestment", ""),
        ("LE Discretionary Other (BR_TE_LE_005)",    cnt(df_ep,S,[SEG['le_disc']]),       "LE-Disc-Other",                      "Includes 432 blank T-shirt"),
        ("TOTAL FINAL",                              "=SUM(B19:B21)",                     "",                                   ""),
        ("LE Stop Work HOLD (BR_TE_LE_003)",         cnt(df_ep,S,[SEG['le_stopwork']]),   "LE-Disc-StopWork-HOLD",              "NRB Value Range Conflict"),
        ("TOTAL HOLD",                               "=B23",                              "",                                   ""),
        ("Review / Pending (SL3/SL4)",               cnt(df_ep,S,[SEG['epic_pending']]),  "PENDING-Stage-Lifecycle-Undefined",  "SL3(240) + SL4(95)"),
        ("Excluded (Status)",                        cnt(df_ep,S,[SEG['epic_excluded']]), "EXCLUDED-Status",                    "Current file: none excluded"),
        ("TOTAL EPICS",                              "",                                  "3,979",                              ""),
        ("GAP","","",""),
        ("SEC","OPEN ITEMS \u2014 pending customer decisions before output can be finalised","",""),
        ("NRB field confirmation",   "OPEN",  "Which NRB field for $10M Stop Work threshold? Rules file BR_TE_002 notes ask 'What field are we using?'. Currently using L1 NRB Hard.", "Finance"),
        ("Stop Work meaning",        "OPEN",  "Are Stop Work records excluded from migration, or migrated and marked as cancelled in new system?",                                    "Business / Finance"),
        ("SL2/SL3/SL4 steps",        "OPEN",  "Target lifecycle step not defined in rules file for SL stages. 352 records (17 Init + 335 Epic) in Review/Pending.",                  "Customer / Planview Admin"),
        ("NRB = $0 on 37 records",   "OPEN",  "37 Stop Work Initiatives have NRB = $0. Genuine zero or unfilled field? Finance to confirm.",                                          "Finance"),
        ("On Hold migration",        "OPEN",  "Should On Hold Initiatives migrate (Active + On Hold) or Active only?",                                                                "Business"),
        ("PC LE Epic list",          "OPEN",  "Rules file BR_PC_005: no system flag exists. ESPM to provide list of LE Epic Work IDs assigned to PC VBs in Pilot Sandbox.",          "ESPM"),
        ("Output field names",       "OPEN",  "Rules file defines no field rename mapping. Source field names carried as-is. Customer to confirm target output field names.",          "Customer / Data Migration"),
    ]

    r = hdr_row(ws, r, ["Item","Count / Status","Output Segment / Detail","Notes"], [40,12,35,20])
    for row_data in rows:
        label, v1, detail, note = row_data
        if label == "GAP":
            ws.row_dimensions[r].height = 8; r += 1; continue
        if label == "SEC":
            r = sec_row(ws, r, v1, 4); continue
        is_total = "TOTAL" in label
        is_open  = str(v1) == "OPEN"
        bg_row = GL if is_total else (RL if is_open else "FFFFFF")
        tc_row = GD if is_total else (RD if is_open else "000000")
        sc(ws, r, 1, label,  bold=is_total, bg=bg_row, color=tc_row, size=9)
        sc(ws, r, 2, v1,     bold=is_total, bg=bg_row, color=tc_row, size=9, ha="center")
        sc(ws, r, 3, detail, bg=bg_row, size=9, color=GRD, italic=True)
        sc(ws, r, 4, note,   bg=bg_row, size=9, color=GRD)
        ws.row_dimensions[r].height = 32
        r += 1


# ── Config loader ──────────────────────────────────────────────
def load_config(config_path=None):
    if config_path is None:
        config_path = Path(__file__).parent / "planview_migration_prototype_config.json"
    config_path = Path(config_path)
    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}")
        sys.exit(1)
    try:
        with open(config_path, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"ERROR: Config file is not valid JSON: {e}")
        sys.exit(1)


# ── Main ───────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Planview Migration Prototype Builder")
    parser.add_argument("--config", default=None,
                        help="Path to JSON config file (default: planview_migration_prototype_config.json)")
    args = parser.parse_args()

    cfg        = load_config(args.config)
    input_path = cfg["input_file"]
    rules_path = cfg["rules_file"]
    output_path= cfg["output_file"]
    nrb_field  = cfg.get("nrb_field",
                         "L1 Net Recurring Benefits ($, annualized)-P&L/Hard")

    print(f"Input  : {input_path}")
    print(f"Rules  : {rules_path}")
    print(f"Output : {output_path}")

    # Read
    df_ep_raw = pd.read_excel(input_path, sheet_name='Local and LCM',
                               dtype=str, header=0).fillna('')
    df_in_raw = pd.read_excel(input_path, sheet_name='L1-L4 Planview Inits Data Pull',
                               dtype=str, header=0).fillna('')

    if 'Work ID #' in df_ep_raw.columns:
        df_ep_raw = df_ep_raw[df_ep_raw['Work ID #'].str.strip()!=''].reset_index(drop=True)
    if 'Strategy Seq. ID' in df_in_raw.columns:
        df_in_raw = df_in_raw[df_in_raw['Strategy Seq. ID'].str.strip()!=''].reset_index(drop=True)

    print(f"Initiatives : {len(df_in_raw):,}")
    print(f"Epics       : {len(df_ep_raw):,}")

    # Classify
    print("Classifying...")
    i_segs,i_flows,i_lcs,i_rules,i_srcs = [],[],[],[],[]
    for _,row in df_in_raw.iterrows():
        seg,flow,lc,rule,src = classify_init(row, nrb_field)
        i_segs.append(seg); i_flows.append(flow); i_lcs.append(lc)
        i_rules.append(rule); i_srcs.append(src)
    df_in = df_in_raw.copy()
    df_in['Output_Segment']        = i_segs
    df_in['Future_State_Flow']     = i_flows
    df_in['Target_Lifecycle_Step'] = i_lcs
    df_in['Rule_ID_Applied']       = i_rules
    df_in['Migration_Source']      = i_srcs

    e_segs,e_flows,e_lcs,e_rules,e_srcs = [],[],[],[],[]
    for _,row in df_ep_raw.iterrows():
        seg,flow,lc,rule,src = classify_epic(row)
        e_segs.append(seg); e_flows.append(flow); e_lcs.append(lc)
        e_rules.append(rule); e_srcs.append(src)
    df_ep = df_ep_raw.copy()
    df_ep['Output_Segment']        = e_segs
    df_ep['Future_State_Flow']     = e_flows
    df_ep['Target_Lifecycle_Step'] = e_lcs
    df_ep['Rule_ID_Applied']       = e_rules
    df_ep['Migration_Source']      = e_srcs

    run_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Build workbook
    print("Building prototype workbook...")
    wb = Workbook()
    wb.remove(wb.active)

    build_readme(wb, input_path, rules_path, run_ts, df_in, df_ep)
    build_source_attribution(wb, rules_path)
    build_business_rules(wb, rules_path)
    build_lifecycle_steps(wb, rules_path)
    build_scenario_rules(wb, rules_path)
    build_validation_rules(wb, rules_path)
    build_sql_logic(wb, rules_path)

    FINAL_I = [SEG['init_bc'],SEG['init_strat_inv'],SEG['init_disc_other'],SEG['init_bo']]
    HOLD_I  = [SEG['init_stopwork'],SEG['init_pc']]
    PEND_I  = [SEG['init_pending']]
    FINAL_E = [SEG['lcm'],SEG['le_strat'],SEG['le_disc']]
    HOLD_E  = [SEG['le_stopwork']]
    PEND_E  = [SEG['epic_pending']]

    build_data_sheet(wb, "Initiatives_Final",  df_in,'Output_Segment',FINAL_I,GD,GL,
        "Initiative records classified and ready to migrate | Business rules applied per rules file")
    build_data_sheet(wb, "Initiatives_Hold",   df_in,'Output_Segment',HOLD_I, RD,RL,
        "Initiatives on hold: 331 Purple Chip (Pilot Sandbox \u2014 ESPM owns) + 87 Stop Work (Finance/Triage sign-off required)")
    build_data_sheet(wb, "Initiatives_Review", df_in,'Output_Segment',PEND_I, AD,AL,
        "17 Initiatives: SL2(7)+SL3(9)+SL4(6) \u2014 target lifecycle step not yet defined in rules file for these stages")
    build_data_sheet(wb, "Epics_Final",        df_ep,'Output_Segment',FINAL_E,GD,GL,
        "Epic records classified and ready to migrate | LCM(743) + LE Transformational(127) + LE Disc Other(2,768)")
    build_data_sheet(wb, "Epics_Hold",         df_ep,'Output_Segment',HOLD_E, RD,RL,
        "6 LE Epics on hold: T-shirt L/XL + Value Range Medium ($1M\u2013$10M) proxy used. Confirm exact NRB with Finance.")
    build_data_sheet(wb, "Epics_Review",       df_ep,'Output_Segment',PEND_E, AD,AL,
        "335 Epics: SL3(240)+SL4(95) \u2014 target lifecycle step not yet defined in rules file for these stages")

    build_summary(wb, df_in, df_ep, run_ts, input_path, rules_path)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    print(f"\nPrototype workbook saved: {output_path}")
    print(f"Sheets ({len(wb.worksheets)}): {[ws.title for ws in wb.worksheets]}")


if __name__ == "__main__":
    main()
