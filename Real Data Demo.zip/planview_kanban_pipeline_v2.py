"""
============================================================
Planview Migration Pipeline — Kanban File Edition
============================================================
Input  : Portfolio_Kanban_Analysis_-_Work_ALL.xlsx
         7,591 Epic records (Local Enhancement / Biz w/Tech /
         Lifecycle Management Epics)

Rules  : BusinessRules_DataMigration_Detail_breakdown.xlsx
         + DRAFT_Business_Rules_for_Data_Migration__2_.xlsx

Steps:
  1. Read Kanban Excel sheet, save as temp CSV
  2. Connect to SQL Server
  3. BULK INSERT into staging table
  4. Run transformation SQL (BR_TE_LCM_005, BR_TE_LE_001/003,
     BR_TE_LE_002, BR_STATUS_001, BR_BLANK_001)
  5. Validate output
  6a. Save output Excel to local folder
  6b. Send via Outlook desktop

Output sheets:
  - Final_Output       : LCM + LE S/M/XS records ready to migrate
  - StopWork_Hold      : LE L/XL + BwT L/XL pending Finance sign-off
  - Review_Required    : BwT Epics where ESI Flag / NRB missing
  - Excluded_Records   : Status-based exclusions (BR_STATUS_001)

NOTE: ESI Flag, NRB, BC Flag, PC Flag, DT Flag are NOT present
in the Kanban source file. Rules requiring these flags
(BR_TE_001/002/003/004, BR_PC_001/002) are pre-written below
but commented out. Uncomment once ESPM provides these fields.

Usage:
  py planview_kanban_pipeline.py

One-time setup:
  pip install pandas pyodbc openpyxl
  Outlook must be open and logged in before running
============================================================
"""

import pandas as pd
import pyodbc
import sys
import os
import io
import tempfile
import logging
from datetime import datetime
from pathlib import Path

# ============================================================
# CONFIG — UPDATE THESE BEFORE RUNNING
# ============================================================

INPUT_FILE    = r"E:\Inputrealdata\Portfolio Kanban Analysis - Work ALL.xlsx"
INPUT_SHEET   = "Sheet 1"   # update if sheet tab name differs in your file

SQL_SERVER    = "DESKTOP-GLHDKO3"
SQL_DATABASE  = "PlanviewMigration"
STAGING_TABLE = "PV_Kanban_Staging"

TEMP_CSV      = r"C:\Demo\pv_kanban_temp.csv"

# ── OUTPUT FOLDER ─────────────────────────────────────────
OUTPUT_FOLDER = r"C:\Demo\Outputsrealdata"

# ── EMAIL CONFIG (Outlook Desktop) ───────────────────────
EMAIL_TO      = ["nilesh@invictadatacloud.com"]   # update with actual recipient(s)
EMAIL_CC      = []
EMAIL_SUBJECT = "Planview Migration — Kanban Epic Output"

# ── VALID OUTPUT SEGMENTS ─────────────────────────────────
VALID_SEGMENTS = {
    "LCM-NonDisc-RunTheBusiness",
    "LE-Disc-StrategicInvestment-HOLD",
    "LE-Disc-Other",
    "TE-BwT-StopWork-HOLD",
    "REVIEW-ESI-NRB-Missing",
    "Excluded-Status",
}

# ============================================================

SEPARATOR = "=" * 60

# ── Logging setup ────────────────────────────────────────────────────────
# Logs are written to BOTH the console and a timestamped .log file
# saved in OUTPUT_FOLDER. The logger is initialised in main() once
# OUTPUT_FOLDER is confirmed to exist.
_logger = None

def init_logger(ts):
    """Create timestamped log file in OUTPUT_FOLDER and wire up the logger."""
    global _logger
    log_dir = Path(OUTPUT_FOLDER)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"pipeline_run_{ts}.log"

    _logger = logging.getLogger("pipeline")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()   # avoid duplicate handlers on re-run

    # File handler — full detail to log file
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s  %(message)s",
                                       datefmt="%Y-%m-%d %H:%M:%S"))
    _logger.addHandler(fh)

    # Console handler — mirrors what was already printing
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(ch)

    return log_file


def log(msg, indent=0):
    line = "  " * indent + msg
    if _logger:
        _logger.info(line)
    else:
        print(line)


def log_step(num, msg):
    line = f"\n[{num}] {msg}"
    if _logger:
        _logger.info(line)
    else:
        print(line)


# ────────────────────────────────────────────────────────────
# STEP 1 — Read Excel and save as temp CSV
# ────────────────────────────────────────────────────────────
def read_and_export_csv():
    log_step("1/6", "Reading Kanban Excel and saving to temp CSV...")
    path = Path(INPUT_FILE)

    if not path.exists():
        log(f"ERROR: File not found: {path}", 1)
        log("Check the INPUT_FILE path in the CONFIG section.", 1)
        sys.exit(1)

    try:
        # Row 0 is the banner, row 1 is the actual column header row
        df = pd.read_excel(path, sheet_name=INPUT_SHEET, dtype=str, header=0)
    except Exception as e:
        log(f"ERROR reading sheet '{INPUT_SHEET}': {e}", 1)
        sys.exit(1)

    # Strip blank rows
    if "Work ID #" in df.columns:
        df = df[
            df["Work ID #"].notna() &
            (df["Work ID #"].str.strip() != "")
        ].reset_index(drop=True)

    df = df.fillna("")

    # Validate required columns
    required_cols = [
        "Work ID #",
        "Name",
        "Work Type",
        "Work Status",
        "T-Shirt Size",
        "Home Domain/Portfolio",
    ]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        log("ERROR: Required column(s) missing:", 1)
        for m in missing:
            log(f"  - {m}", 2)
        sys.exit(1)

    df.to_csv(TEMP_CSV, index=False, sep="|", encoding="utf-8-sig")

    log(f"Input    : {path.name}", 1)
    log(f"Sheet    : {INPUT_SHEET}", 1)
    log(f"Rows     : {len(df):,}", 1)
    log(f"Columns  : {len(df.columns)}", 1)
    log(f"Temp CSV : {TEMP_CSV}", 1)

    return df, path


# ────────────────────────────────────────────────────────────
# STEP 2 — Connect to SQL Server
# ────────────────────────────────────────────────────────────
def connect_sql():
    log_step("2/6", "Connecting to SQL Server...")
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SQL_SERVER};"
            f"DATABASE={SQL_DATABASE};"
            f"Trusted_Connection=yes;"
            f"Connection Timeout=30;"
        )
        conn.autocommit = True
        log(f"Server   : {SQL_SERVER}", 1)
        log(f"Database : {SQL_DATABASE}", 1)
        log("Status   : Connected", 1)
        return conn
    except pyodbc.Error as e:
        log("ERROR: Could not connect to SQL Server", 1)
        log(f"Detail : {e}", 1)
        sys.exit(1)


# ────────────────────────────────────────────────────────────
# STEP 3 — BULK INSERT into staging table
# ────────────────────────────────────────────────────────────
def bulk_insert(conn, df):
    log_step("3/6", f"Running SQL BULK INSERT — {len(df):,} rows...")
    cursor = conn.cursor()

    cursor.execute(f"""
        IF OBJECT_ID('{STAGING_TABLE}') IS NOT NULL
            DROP TABLE {STAGING_TABLE}
    """)

    col_defs = ",\n            ".join(
        [f"[{col}] nvarchar(500)" for col in df.columns]
    )
    cursor.execute(f"""
        CREATE TABLE {STAGING_TABLE} (
            {col_defs}
        )
    """)
    log(f"Table    : {STAGING_TABLE} created ({len(df.columns)} columns)", 1)

    cursor.execute(f"""
        BULK INSERT {STAGING_TABLE}
        FROM '{TEMP_CSV}'
        WITH (
            FIELDTERMINATOR = '|',
            ROWTERMINATOR   = '\\n',
            FIRSTROW        = 2,
            CODEPAGE        = '65001',
            TABLOCK
        )
    """)

    cursor.execute(f"SELECT COUNT(*) FROM {STAGING_TABLE}")
    db_count = cursor.fetchone()[0]
    log(f"Loaded   : {db_count:,} rows confirmed in SQL Server", 1)
    return cursor


# ────────────────────────────────────────────────────────────
# STEP 4 — Transformation SQL
#
# Rules applied:
#   BR_STATUS_001  — File 2 confirmed 4/8/26: status exclusion
#   BR_TE_LCM_005  — File 1: LCM Epics → Run the Business (direct map)
#   BR_TE_LE_001   — File 1 + File 3: LE L/XL → Strategic Investment (Finance HOLD)
#   BR_TE_LE_003   — File 1 + File 3: LE S/M/XS → Discretionary Other
#   BR_BLANK_001   — File 2 confirmed 4/8/26: blank T-shirt → Discretionary Other
#   BR_TE_LE_002   — File 1: BwT L/XL → Stop Work (NRB needed to confirm)
#
# Pending rules (ESI Flag / NRB / BC Flag not in source file):
#   BR_TE_001/002/003/004 — pre-written below, commented out
#   Uncomment once ESPM provides ESI Flag + NRB columns
# ────────────────────────────────────────────────────────────

TRANSFORM_SQL = f"""
WITH classified AS (
    SELECT
        [Work ID #]                AS [INITIATIVE_LEGACY_ID],
        [Name]                     AS [Initiative_Name],
        [Work Type]                AS [Demand_Type],
        [Work Status]              AS [Work_Status_Raw],
        [T-Shirt Size]             AS [T_Shirt_Size],
        [Home Domain/Portfolio]    AS [Portfolio],
        [Associated Initiative Seq ID] AS [Parent_Initiative_ID],
        [Associated Initiative]    AS [Parent_Initiative_Name],
        [AP Top Lane],
        [Schedule Start],
        [Schedule Finish],

        -- Work Status normalisation
        CASE [Work Status]
            WHEN 'Approved'         THEN 'Approved'
            WHEN 'Not Started'      THEN 'Not Started'
            WHEN 'In Progress'      THEN 'In Progress'
            WHEN 'On Hold'          THEN 'On Hold'
            WHEN 'Cancelled'        THEN 'Cancelled'
            WHEN 'Closed'           THEN 'Closed'
            WHEN 'Completed'        THEN 'Completed'
            WHEN 'Assumed Completed' THEN 'Assumed Completed'
            WHEN 'Rejected'         THEN 'Rejected'
            ELSE [Work Status]
        END AS [Work_Status],

        -- Migration Track — priority order matters
        CASE

            -- BR_STATUS_001 (File 2, confirmed 4/8/26)
            -- Exclude: Cancelled, Closed, Completed, Assumed Completed, Rejected
            WHEN [Work Status] IN
                 ('Cancelled','Closed','Completed','Assumed Completed','Rejected')
                THEN 'EXCLUDED-Status'

            -- BR_TE_LCM_005 (File 1 + File 3)
            -- LCM Epics → Non-Discretionary Run the Business
            -- Direct map — no T-shirt or NRB gate required
            WHEN [Work Type] = 'Lifecycle Management Epic'
                THEN 'Tech-Enabled -- LCM'

            -- BR_TE_LE_001 (File 1 + File 3)
            -- LE Epics with T-shirt L or XL → Strategic Investment
            -- Finance validation mandatory before migration
            -- NOTE: Real data T-shirt values include prefix: '4: L', '5: XL'
            WHEN [Work Type] = 'Local Enhancement Epic'
                 AND [T-Shirt Size] IN ('4: L','5: XL')
                THEN 'Tech-Enabled -- LE L/XL'

            -- BR_TE_LE_003 (File 1 + File 3)
            -- LE Epics with T-shirt S/M/XS → Discretionary Other
            WHEN [Work Type] = 'Local Enhancement Epic'
                 AND [T-Shirt Size] IN ('1: XS','2: S','3: M')
                THEN 'Tech-Enabled -- LE S/M/XS'

            -- BR_BLANK_001 (File 2, confirmed 4/8/26)
            -- LE Epics with blank T-shirt → Discretionary Other (default)
            WHEN [Work Type] = 'Local Enhancement Epic'
                 AND ([T-Shirt Size] IS NULL OR [T-Shirt Size] = '')
                THEN 'Tech-Enabled -- LE Blank'

            -- BR_TE_LE_002 (File 1)
            -- BwT Epics with T-shirt L or XL → Stop Work pending Finance
            -- NOTE: Cannot fully confirm without NRB — flagged as HOLD
            WHEN [Work Type] = 'Biz w/ Tech Epic'
                 AND [T-Shirt Size] IN ('4: L','5: XL')
                THEN 'Tech-Enabled -- BwT L/XL'

            -- BR_TE_001/003 (File 1): BwT S/M/XS or Blank → Review Required
            -- ESI Flag and NRB not in source file — cannot fully classify
            -- Add ESI_Flag + NRB_M columns from ESPM then uncomment below:
            --
            -- WHEN [Work Type] = 'Biz w/ Tech Epic'
            --      AND [ESI_Flag] = 'Y'
            --      AND [T-Shirt Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) >= 10
            --     THEN 'Tech-Enabled -- Strategic Investment'
            --
            -- WHEN [Work Type] = 'Biz w/ Tech Epic'
            --      AND [T-Shirt Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) < 10
            --     THEN 'Tech-Enabled -- Stop Work (Pending Finance)'
            --
            -- WHEN [Work Type] = 'Biz w/ Tech Epic'
            --      AND [ESI_Flag] = 'Y'
            --      AND [T-Shirt Size] IN ('1: XS','2: S','3: M')
            --     THEN 'Tech-Enabled -- Discretionary Other'
            --
            -- BR_TE_004 (File 1): Business Continuity direct map
            -- WHEN [BC_Flag] = 'Y'
            --     THEN 'Tech-Enabled -- Business Continuity'

            WHEN [Work Type] = 'Biz w/ Tech Epic'
                THEN 'REVIEW REQUIRED'

            ELSE 'REVIEW REQUIRED'
        END AS [Migration_Track]

    FROM {STAGING_TABLE}
),
final AS (
    SELECT
        [INITIATIVE_LEGACY_ID],
        [Initiative_Name],
        [Demand_Type],
        [Work_Status],
        [T_Shirt_Size],
        [Portfolio],
        [Parent_Initiative_ID],
        [Parent_Initiative_Name],
        [AP Top Lane],
        [Schedule Start],
        [Schedule Finish],

        -- Demand Sub-Type (Future State Flow)
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- LCM'
                THEN 'Non-Discretionary - Run the Business'
            WHEN 'Tech-Enabled -- LE L/XL'
                THEN 'Discretionary - Strategic Investment (Finance HOLD)'
            WHEN 'Tech-Enabled -- LE S/M/XS'
                THEN 'Discretionary - Other'
            WHEN 'Tech-Enabled -- LE Blank'
                THEN 'Discretionary - Other'
            WHEN 'Tech-Enabled -- BwT L/XL'
                THEN 'Discretionary - Strategic Inv. (Stop Work - Pending Finance)'
            WHEN 'EXCLUDED-Status'
                THEN 'N/A - Excluded'
            ELSE 'REVIEW REQUIRED - ESI Flag / NRB Missing'
        END AS [Demand_Sub_Type],

        -- Migration Source
        CASE [Migration_Track]
            WHEN 'EXCLUDED-Status' THEN 'N/A - Excluded'
            ELSE 'Current Prod -> New Prod'
        END AS [Migration_Source],

        [Migration_Track],

        -- Output Segment
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- LCM'      THEN 'LCM-NonDisc-RunTheBusiness'
            WHEN 'Tech-Enabled -- LE L/XL'  THEN 'LE-Disc-StrategicInvestment-HOLD'
            WHEN 'Tech-Enabled -- LE S/M/XS' THEN 'LE-Disc-Other'
            WHEN 'Tech-Enabled -- LE Blank'  THEN 'LE-Disc-Other'
            WHEN 'Tech-Enabled -- BwT L/XL'  THEN 'TE-BwT-StopWork-HOLD'
            WHEN 'EXCLUDED-Status'           THEN 'Excluded-Status'
            ELSE 'REVIEW-ESI-NRB-Missing'
        END AS [Output_Segment]

    FROM classified
)
SELECT * FROM final
ORDER BY [Migration_Track], [INITIATIVE_LEGACY_ID]
"""


def run_transform(conn):
    log_step("4/6", "Running transformation SQL...")

    all_df = pd.read_sql(TRANSFORM_SQL, conn)

    # Split into result sets
    final_df = all_df[
        ~all_df["Output_Segment"].isin(["Excluded-Status"]) &
        ~all_df["Output_Segment"].str.startswith("REVIEW", na=False) &
        ~all_df["Output_Segment"].str.contains("HOLD", na=False)
    ].reset_index(drop=True)

    stopwork_df = all_df[
        all_df["Output_Segment"].str.contains("HOLD", na=False)
    ].reset_index(drop=True)

    review_df = all_df[
        all_df["Output_Segment"].str.startswith("REVIEW", na=False)
    ].reset_index(drop=True)

    excluded_df = all_df[
        all_df["Output_Segment"] == "Excluded-Status"
    ].reset_index(drop=True)

    seg_counts = final_df["Output_Segment"].value_counts()

    log(f"Total rows processed            : {len(all_df):,}", 1)
    log(f"", 1)
    log(f"Final Output (ready)            : {len(final_df):,}", 1)
    log(f"  LCM-NonDisc-RunTheBusiness    : {seg_counts.get('LCM-NonDisc-RunTheBusiness', 0):,}", 2)
    log(f"  LE-Disc-StrategicInvest-HOLD  : {len(stopwork_df[stopwork_df['Output_Segment']=='LE-Disc-StrategicInvestment-HOLD']):,}  (in Stop Work)", 2)
    log(f"  LE-Disc-Other                 : {seg_counts.get('LE-Disc-Other', 0):,}", 2)
    log(f"", 1)
    log(f"Stop Work HOLD (Finance needed) : {len(stopwork_df):,}", 1)
    log(f"  LE-Disc-StrategicInvest-HOLD  : {len(stopwork_df[stopwork_df['Output_Segment']=='LE-Disc-StrategicInvestment-HOLD']):,}", 2)
    log(f"  TE-BwT-StopWork-HOLD          : {len(stopwork_df[stopwork_df['Output_Segment']=='TE-BwT-StopWork-HOLD']):,}", 2)
    log(f"", 1)
    log(f"Review Required (ESI/NRB missing): {len(review_df):,}  <- need ESPM flags", 1)
    log(f"Excluded (status-based)         : {len(excluded_df):,}  <- BR_STATUS_001", 1)

    return final_df, stopwork_df, review_df, excluded_df


# ────────────────────────────────────────────────────────────
# STEP 5 — Validate output
# ────────────────────────────────────────────────────────────
def validate(final_df, stopwork_df, review_df):
    log_step("5/6", "Validating output...")
    errors = []
    warnings = []

    if len(final_df) == 0 and len(stopwork_df) == 0:
        errors.append("Both Final Output and Stop Work Hold are empty")

    dupes = final_df.duplicated(subset=["INITIATIVE_LEGACY_ID"]).sum()
    if dupes > 0:
        errors.append(f"{dupes:,} duplicate INITIATIVE_LEGACY_ID(s) in Final Output")

    unexpected = set(final_df["Output_Segment"].unique()) - VALID_SEGMENTS
    if unexpected:
        errors.append(f"Unexpected Output_Segment values: {unexpected}")

    if len(stopwork_df) > 0:
        warnings.append(f"{len(stopwork_df):,} Stop Work records in HOLD — Finance/Triage sign-off needed")
    if len(review_df) > 0:
        warnings.append(f"{len(review_df):,} records need ESI Flag + NRB from ESPM to complete classification")

    if errors:
        log("VALIDATION FAILED:", 1)
        for e in errors:
            log(f"  - {e}", 1)
        sys.exit(1)
    else:
        log("All checks passed", 1)
        log(f"  Duplicate IDs   : OK (0 duplicates)", 1)
        log(f"  Segment values  : OK", 1)

    if warnings:
        log("Warnings (non-fatal):", 1)
        for w in warnings:
            log(f"  ! {w}", 1)


# ────────────────────────────────────────────────────────────
# STEP 6a — Build Excel in memory
# ────────────────────────────────────────────────────────────
def build_excel_bytes(final_df, stopwork_df, review_df, excluded_df):
    final_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "T_Shirt_Size", "Portfolio",
        "Parent_Initiative_ID", "Parent_Initiative_Name",
        "Demand_Sub_Type", "Migration_Source", "Migration_Track", "Output_Segment",
    ]
    hold_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "T_Shirt_Size", "Portfolio",
        "Demand_Sub_Type", "Output_Segment", "Migration_Track",
    ]
    review_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "T_Shirt_Size", "Portfolio", "Output_Segment",
    ]
    excluded_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Output_Segment",
    ]

    def safe_cols(df, cols):
        return [c for c in cols if c in df.columns]

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        final_df[safe_cols(final_df, final_cols)].to_excel(
            writer, sheet_name="Final_Output", index=False)
        stopwork_df[safe_cols(stopwork_df, hold_cols)].to_excel(
            writer, sheet_name="StopWork_Hold", index=False)
        review_df[safe_cols(review_df, review_cols)].to_excel(
            writer, sheet_name="Review_Required", index=False)
        excluded_df[safe_cols(excluded_df, excluded_cols)].to_excel(
            writer, sheet_name="Excluded_Records", index=False)

        for sheet_name in writer.sheets:
            ws = writer.sheets[sheet_name]
            for col in ws.columns:
                max_len = max((len(str(c.value)) for c in col if c.value), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

    return buffer.getvalue()


# ────────────────────────────────────────────────────────────
# STEP 6a — Save to local folder
# ────────────────────────────────────────────────────────────
def save_to_folder(excel_bytes, ts):
    out_name = f"Planview_Kanban_Output_{ts}.xlsx"
    folder   = Path(OUTPUT_FOLDER)
    folder.mkdir(parents=True, exist_ok=True)
    out_path = folder / out_name
    with open(out_path, "wb") as f:
        f.write(excel_bytes)
    log(f"File saved : {out_path}", 1)
    return out_path


# ────────────────────────────────────────────────────────────
# STEP 6b — Send via Outlook desktop
# ────────────────────────────────────────────────────────────
def send_email(excel_bytes, ts, final_df, stopwork_df, review_df, excluded_df):
    out_name   = f"Planview_Kanban_Output_{ts}.xlsx"
    saved_path = Path(OUTPUT_FOLDER) / out_name
    tmp_path   = None
    _delete_after = False

    body = (
        f"Hi team,\n\n"
        f"Please find attached the Planview Migration Pipeline output for the\n"
        f"Kanban file (Portfolio_Kanban_Analysis_-_Work_ALL.xlsx) — run {ts}.\n\n"
        f"The file contains four sheets:\n"
        f"  - Final_Output    : {len(final_df):,} records ready to migrate\n"
        f"  - StopWork_Hold   : {len(stopwork_df):,} records pending Finance / Triage sign-off\n"
        f"  - Review_Required : {len(review_df):,} records — ESI Flag / NRB missing (need ESPM data)\n"
        f"  - Excluded_Records: {len(excluded_df):,} records — status-based exclusion (BR_STATUS_001)\n\n"
        f"This is an automated email from the Planview Migration Pipeline v9.\n\n"
        f"Regards,\nMigration Pipeline\n"
    )

    try:
        import win32com.client

        if saved_path.exists():
            tmp_path = str(saved_path)
        else:
            with tempfile.NamedTemporaryFile(suffix=".xlsx", prefix="pv_kanban_", delete=False) as tmp:
                tmp.write(excel_bytes)
                tmp_path = tmp.name
            _delete_after = True

        outlook = win32com.client.Dispatch("Outlook.Application")
        mail    = outlook.CreateItem(0)

        # Add recipients using Recipients.Add — more reliable with corporate GAL
        # Resolves addresses against the FedEx Global Address List
        for addr in EMAIL_TO:
            recip = mail.Recipients.Add(addr)
            recip.Type = 1   # 1 = olTo
            if not recip.Resolve():
                log(f"WARNING: Could not resolve address: {addr}", 1)
                log("  Check the email address is correct and exists in the FedEx GAL.", 2)

        for addr in EMAIL_CC:
            recip = mail.Recipients.Add(addr)
            recip.Type = 2   # 2 = olCC
            recip.Resolve()

        mail.Subject = f"{EMAIL_SUBJECT} - {ts}"
        mail.Body    = body
        mail.Attachments.Add(tmp_path)
        mail.Send()

        log(f"Sent via   : Outlook desktop", 1)
        log(f"Sent to    : {'; '.join(EMAIL_TO)}", 1)
        log(f"Attachment : {out_name}", 1)

    except ImportError:
        log("ERROR: pywin32 is not installed. Run: pip install pywin32", 1)
        sys.exit(1)
    except Exception as e:
        log(f"ERROR: Could not send via Outlook: {e}", 1)
        log("- Make sure Outlook is open and logged in before running.", 2)
        sys.exit(1)
    finally:
        if tmp_path and _delete_after and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


# ────────────────────────────────────────────────────────────
# CLEANUP
# ────────────────────────────────────────────────────────────
def cleanup(cursor, conn):
    try:
        cursor.execute(f"DROP TABLE IF EXISTS {STAGING_TABLE}")
        log("Cleanup  : Staging table dropped", 1)
    except Exception:
        pass
    try:
        os.remove(TEMP_CSV)
        log("Cleanup  : Temp CSV deleted", 1)
    except Exception:
        pass
    conn.close()


# ────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────
def main():
    start = datetime.now()
    ts_run = start.strftime("%Y%m%d_%H%M%S")

    # Initialise logger — creates log file in OUTPUT_FOLDER
    log_file = init_logger(ts_run)

    log(SEPARATOR)
    log("  Planview Migration Pipeline v9 — Kanban Epic Edition")
    log(f"  Input  : Portfolio Kanban Analysis - Work ALL.xlsx  [Kanban_Input]")
    log(f"  Started: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"  Log    : {log_file}")
    log(SEPARATOR)
    log("  Rules: BusinessRules_DataMigration_Detail_breakdown.xlsx")
    log("         DRAFT_Business_Rules_for_Data_Migration__2_.xlsx")
    log(SEPARATOR)

    df, input_path = read_and_export_csv()
    conn           = connect_sql()
    cursor         = bulk_insert(conn, df)

    final_df, stopwork_df, review_df, excluded_df = run_transform(conn)

    validate(final_df, stopwork_df, review_df)

    ts          = ts_run   # reuse run timestamp for consistent file/log naming
    excel_bytes = build_excel_bytes(final_df, stopwork_df, review_df, excluded_df)

    log_step("6a/6", "Saving output Excel to local folder...")
    out_path = save_to_folder(excel_bytes, ts)

    log_step("6b/6", "Sending output Excel via Outlook desktop...")
    send_email(excel_bytes, ts, final_df, stopwork_df, review_df, excluded_df)

    cleanup(cursor, conn)

    elapsed = round((datetime.now() - start).total_seconds(), 1)
    log(f"\n{SEPARATOR}")
    log("  PIPELINE COMPLETE — KANBAN FILE")
    log(f"  Saved to      : {out_path}")
    log(f"  Log file      : {log_file}")
    log(f"  Email sent to : {', '.join(EMAIL_TO)}")
    log(f"  Records       : {len(final_df):,} ready | {len(stopwork_df):,} HOLD | {len(review_df):,} review | {len(excluded_df):,} excluded")
    log(f"  Runtime       : {elapsed}s")
    log(SEPARATOR)


if __name__ == "__main__":
    main()
