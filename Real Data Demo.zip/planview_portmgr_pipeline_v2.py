"""
============================================================
Planview Migration Pipeline — Kanban File Edition
============================================================
Input  : Portfolio_Manager_-_New_List.xlsx
         7,591 Epic records (Local Enhancement / Biz w/Tech /
         Lifecycle Management Epics)

Rules  : BusinessRules_DataMigration_Detail_breakdown.xlsx
         + DRAFT_Business_Rules_for_Data_Migration__2_.xlsx

Steps:
  1. Read Kanban Excel sheet, save as temp CSV
  2. Connect to SQL Server
  3. Load data into staging table via parameterised INSERT (no CSV file)
  4. Run transformation SQL (BR_TE_LCM_005, BR_TE_LE_001/003,
     BR_TE_LE_002, BR_STATUS_001, BR_BLANK_001)
  5. Validate output
  6a. Save output Excel to local folder
  6b. Send via Outlook desktop

Output sheets:
  - Final_Output       : LCM + LE S/M/XS records ready to migrate
  - StopWork_Hold      : LE L/XL + BwT L/XL pending Finance sign-off
  - Review_Required    : BwT Epics where ESI Flag / NRB missing
  - Excluded_Records   : Status-based exclusions (BR_STATUS_001)

NOTE: ESI Flag, NRB, BC Flag, PC Flag, DT Flag are NOT present
in the Kanban source file. Rules requiring these flags
(BR_TE_001/002/003/004, BR_PC_001/002) are pre-written below
but commented out. Uncomment once ESPM provides these fields.

Usage:
  py planview_kanban_pipeline.py

One-time setup:
  pip install pandas pyodbc openpyxl
  Outlook must be open and logged in before running
============================================================
"""

import pandas as pd
import pyodbc
import sys
import os
import io
import tempfile
import logging
from datetime import datetime
from pathlib import Path

# ============================================================
# CONFIG — UPDATE THESE BEFORE RUNNING
# ============================================================

INPUT_FILE    = r"E:\Inputrealdata\Portfolio Manager - New List (3).xlsx"
INPUT_SHEET   = "Sheet 1"   # update if sheet tab name differs in your file

SQL_SERVER    = "DESKTOP-GLHDKO3"
SQL_DATABASE  = "PlanviewMigration"
STAGING_TABLE = "PV_PortMgr_Staging"

TEMP_CSV      = r"C:\Demo\pv_kanban_temp.csv"

# ── OUTPUT FOLDER ─────────────────────────────────────────
OUTPUT_FOLDER = r"C:\Demo\Outputsrealdata"

# ── EMAIL CONFIG (Outlook Desktop) ───────────────────────
EMAIL_TO      = ["nilesh@invictadatacloud.com"]   # update with actual recipient(s)
EMAIL_CC      = []
EMAIL_SUBJECT = "Planview Migration — Portfolio Manager Initiative Output"

# ── VALID OUTPUT SEGMENTS ─────────────────────────────────
VALID_SEGMENTS = {
    "TE-BusinessDemandMgmt",
    "REVIEW-ESI-NRB-Missing",
    "Excluded-Status",
}

# ============================================================

SEPARATOR = "=" * 60

# ── Logging setup ────────────────────────────────────────────────────────
# Logs are written to BOTH the console and a timestamped .log file
# saved in OUTPUT_FOLDER. The logger is initialised in main() once
# OUTPUT_FOLDER is confirmed to exist.
_logger = None

def init_logger(ts):
    """Create timestamped log file in OUTPUT_FOLDER and wire up the logger."""
    global _logger
    log_dir = Path(OUTPUT_FOLDER)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"pipeline_run_{ts}.log"

    _logger = logging.getLogger("pipeline")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()   # avoid duplicate handlers on re-run

    # File handler — full detail to log file
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s  %(message)s",
                                       datefmt="%Y-%m-%d %H:%M:%S"))
    _logger.addHandler(fh)

    # Console handler — mirrors what was already printing
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(ch)

    return log_file


def log(msg, indent=0):
    line = "  " * indent + msg
    if _logger:
        _logger.info(line)
    else:
        print(line)


def log_step(num, msg):
    line = f"\n[{num}] {msg}"
    if _logger:
        _logger.info(line)
    else:
        print(line)


# ────────────────────────────────────────────────────────────
# STEP 1 — Read Excel and save as temp CSV
# ────────────────────────────────────────────────────────────
def read_excel_data():
    log_step("1/6", "Reading Portfolio Manager Excel...")
    path = Path(INPUT_FILE)

    if not path.exists():
        log(f"ERROR: File not found: {path}", 1)
        log("Check the INPUT_FILE path in the CONFIG section.", 1)
        sys.exit(1)

    try:
        # Row 0 is the banner, row 1 is the actual column header row
        df = pd.read_excel(path, sheet_name=INPUT_SHEET, dtype=str, header=0)
    except Exception as e:
        log(f"ERROR reading sheet '{INPUT_SHEET}': {e}", 1)
        sys.exit(1)

    # Strip blank rows
    if "Strategy Seq. ID" in df.columns:
        df = df[
            df["Strategy Seq. ID"].notna() &
            (df["Strategy Seq. ID"].str.strip() != "")
        ].reset_index(drop=True)

    df = df.fillna("")

    # Clean free-text columns before writing to pipe-delimited CSV.
    # Status Rationale and similar fields contain newlines, pipe characters,
    # and double quotes. Strip them all out.
    free_text_cols = [
        "Status Rationale", "Initiative Owner", "Health Status",
        "Lifecycle Model", "Name",
    ]
    for col in free_text_cols:
        if col in df.columns:
            df[col] = (
                df[col]
                .str.replace("\n", " ", regex=False)   # newlines -> space
                .str.replace("\r", " ", regex=False)   # carriage returns -> space
                .str.replace("|",   " ", regex=False)   # pipe -> space (field separator)
                .str.replace('"',   "'", regex=False)   # double quote -> single quote
                .str.strip()
            )

    # Validate required columns
    required_cols = [
        "Strategy Seq. ID",
        "Name",
        "Initiative Type",
        "Lifecycle Status",
        "Domain",
    ]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        log("ERROR: Required column(s) missing:", 1)
        for m in missing:
            log(f"  - {m}", 2)
        sys.exit(1)

    log(f"Input    : {path.name}", 1)
    log(f"Sheet    : {INPUT_SHEET}", 1)
    log(f"Rows     : {len(df):,}", 1)
    log(f"Columns  : {len(df.columns)}", 1)

    return df, path


# ────────────────────────────────────────────────────────────
# STEP 2 — Connect to SQL Server
# ────────────────────────────────────────────────────────────
def connect_sql():
    log_step("2/6", "Connecting to SQL Server...")
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SQL_SERVER};"
            f"DATABASE={SQL_DATABASE};"
            f"Trusted_Connection=yes;"
            f"Connection Timeout=30;"
        )
        conn.autocommit = True
        log(f"Server   : {SQL_SERVER}", 1)
        log(f"Database : {SQL_DATABASE}", 1)
        log("Status   : Connected", 1)
        return conn
    except pyodbc.Error as e:
        log("ERROR: Could not connect to SQL Server", 1)
        log(f"Detail : {e}", 1)
        sys.exit(1)


# ────────────────────────────────────────────────────────────
# STEP 3 — Load data directly into staging table via executemany
# ────────────────────────────────────────────────────────────
# Uses parameterised INSERT instead of CSV-based loading.
# This completely avoids CSV encoding issues caused by newlines,
# pipe characters, and special characters in free-text columns
# such as Status Rationale, Initiative Owner, and Name.
def bulk_insert(conn, df):
    log_step("3/6", f"Loading {len(df):,} rows into SQL staging table...")
    cursor = conn.cursor()

    # Drop and recreate staging table
    cursor.execute(f"""
        IF OBJECT_ID('{STAGING_TABLE}') IS NOT NULL
            DROP TABLE {STAGING_TABLE}
    """)

    # Use nvarchar(MAX) for free-text columns that can exceed 4000 chars
    long_cols = {"Status Rationale", "Initiative Owner"}
    col_defs = ",\n            ".join(
        [f"[{col}] nvarchar(MAX)" if col in long_cols
         else f"[{col}] nvarchar(500)"
         for col in df.columns]
    )
    cursor.execute(f"""
        CREATE TABLE {STAGING_TABLE} (
            {col_defs}
        )
    """)
    log(f"Table    : {STAGING_TABLE} created ({len(df.columns)} columns)", 1)

    # Build parameterised INSERT — no CSV file, no encoding issues
    col_names   = ", ".join([f"[{col}]" for col in df.columns])
    placeholders = ", ".join(["?" for _ in df.columns])
    insert_sql  = f"INSERT INTO {STAGING_TABLE} ({col_names}) VALUES ({placeholders})"

    # Replace NaN with None so SQL Server receives proper NULL values
    df_clean = df.where(df.notna(), None)

    # Clean all string columns — strip newlines, carriage returns, and pipes
    # that would cause issues in any downstream processing
    for col in df_clean.columns:
        if df_clean[col].dtype == object:
            df_clean[col] = (
                df_clean[col]
                .str.replace("\n", " ", regex=False)
                .str.replace("\r", " ", regex=False)
                .str.replace("|",   " ", regex=False)
                .str.replace('"',   "'", regex=False)
                .str.strip()
                if hasattr(df_clean[col], "str") else df_clean[col]
            )

    # Insert in batches of 500 rows for performance
    BATCH_SIZE = 500
    rows = [tuple(row) for row in df_clean.itertuples(index=False, name=None)]
    total = len(rows)
    loaded = 0

    conn.autocommit = False
    try:
        for i in range(0, total, BATCH_SIZE):
            batch = rows[i : i + BATCH_SIZE]
            cursor.executemany(insert_sql, batch)
            loaded += len(batch)
            log(f"  Inserted {loaded:,} / {total:,} rows...", 1)
        conn.commit()
    except Exception as e:
        conn.rollback()
        log(f"ERROR: Insert failed at row {loaded}: {e}", 1)
        raise
    finally:
        conn.autocommit = True

    cursor.execute(f"SELECT COUNT(*) FROM {STAGING_TABLE}")
    db_count = cursor.fetchone()[0]
    log(f"Loaded   : {db_count:,} rows confirmed in SQL Server", 1)
    return cursor


# ────────────────────────────────────────────────────────────
# STEP 4 — Transformation SQL
#
# Rules applied:
#   BR_STATUS_001  — File 2 confirmed 4/8/26: status exclusion
#   BR_TE_LCM_005  — File 1: LCM Epics → Run the Business (direct map)
#   BR_TE_LE_001   — File 1 + File 3: LE L/XL → Strategic Investment (Finance HOLD)
#   BR_TE_LE_003   — File 1 + File 3: LE S/M/XS → Discretionary Other
#   BR_BLANK_001   — File 2 confirmed 4/8/26: blank T-shirt → Discretionary Other
#   BR_TE_LE_002   — File 1: BwT L/XL → Stop Work (NRB needed to confirm)
#
# Pending rules (ESI Flag / NRB / BC Flag not in source file):
#   BR_TE_001/002/003/004 — pre-written below, commented out
#   Uncomment once ESPM provides ESI Flag + NRB columns
# ────────────────────────────────────────────────────────────

TRANSFORM_SQL = f"""
WITH classified AS (
    SELECT
        [Strategy Seq. ID]           AS [INITIATIVE_LEGACY_ID],
        [Name]                       AS [Initiative_Name],
        [Initiative Type]            AS [Demand_Type],
        [Lifecycle Status]           AS [Work_Status_Raw],
        [Stage],
        [Domain]                     AS [Portfolio],
        [Pod],
        [Work Actual/Schedule Start],
        [Work Actual/Schedule Finish],

        -- Work Status normalisation
        CASE [Lifecycle Status]
            WHEN 'Active'               THEN 'Active'
            WHEN 'Cancelled'            THEN 'Cancelled'
            WHEN 'Completed'            THEN 'Completed'
            WHEN 'On Hold'              THEN 'On Hold'
            WHEN 'Rejected'             THEN 'Rejected'
            WHEN 'Cancellation Request' THEN 'Cancellation Request'
            ELSE [Lifecycle Status]
        END AS [Work_Status],

        -- Migration Track
        CASE

            -- BR_STATUS_001 (File 2, confirmed 4/8/26)
            -- Exclude: Cancelled, Completed, On Hold, Rejected, Cancellation Request
            WHEN [Lifecycle Status] IN
                 ('Cancelled','Completed','On Hold','Rejected','Cancellation Request')
                THEN 'EXCLUDED-Status'

            -- BR_TE_006 (File 1 + File 3)
            -- Business Only Initiative → Business Demand Management
            -- NOTE: No T-shirt criterion applies (confirmed File 3 Definitions)
            WHEN [Initiative Type] = 'Business Only Initiative'
                THEN 'Tech-Enabled -- Business Only'

            -- BR_TE_001/002/003 (File 1)
            -- Business w/Tech Initiative → Review Required
            -- ESI Flag and NRB not in source file — cannot fully classify
            -- Once ESPM provides ESI Flag + NRB, uncomment rules below:
            --
            -- BR_TE_004: Business Continuity
            -- WHEN [BC_Flag] = 'Y' THEN 'Tech-Enabled -- Business Continuity'
            --
            -- BR_PC_001/002: PC Strategic Programs
            -- WHEN [PC_Flag] = 'Y' THEN 'PC Strategic Programs'
            --
            -- BR_ND_DT_001: Digital Transformation Exception
            -- WHEN [DT_Flag] = 'Y' THEN 'Non-Drive / DT Exception'
            --
            -- BR_TE_001: Strategic Investment (ESI=Y, L/XL, NRB >= $10M)
            -- WHEN [ESI_Flag]='Y' AND [T_Shirt_Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) >= 10
            --     THEN 'Tech-Enabled -- Strategic Investment'
            --
            -- BR_TE_002: Stop Work (L/XL, NRB < $10M)
            -- WHEN [T_Shirt_Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) < 10
            --     THEN 'Tech-Enabled -- Stop Work (Pending Finance)'
            --
            -- BR_TE_003: Discretionary Other (ESI=Y, S/M/XS)
            -- WHEN [ESI_Flag]='Y' AND [T_Shirt_Size] IN ('1: XS','2: S','3: M')
            --     THEN 'Tech-Enabled -- Discretionary Other'

            WHEN [Initiative Type] = 'Business w/ Tech Initiative'
                THEN 'REVIEW REQUIRED'

            ELSE 'REVIEW REQUIRED'
        END AS [Migration_Track]

    FROM {STAGING_TABLE}
),
final AS (
    SELECT
        [INITIATIVE_LEGACY_ID], [Initiative_Name], [Demand_Type],
        [Work_Status], [Stage], [Portfolio], [Pod],
        [Work Actual/Schedule Start], [Work Actual/Schedule Finish],

        -- Demand Sub-Type
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only'
                THEN 'Business Demand Management'
            WHEN 'EXCLUDED-Status'
                THEN 'N/A - Excluded'
            ELSE 'REVIEW REQUIRED - ESI Flag / NRB Missing'
        END AS [Demand_Sub_Type],

        -- Migration Source
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only' THEN 'Current Prod / ESPM (TBC)'
            WHEN 'EXCLUDED-Status'               THEN 'N/A - Excluded'
            ELSE 'Current Prod -> New Prod'
        END AS [Migration_Source],

        [Migration_Track],

        -- Output Segment
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only' THEN 'TE-BusinessDemandMgmt'
            WHEN 'EXCLUDED-Status'               THEN 'Excluded-Status'
            ELSE 'REVIEW-ESI-NRB-Missing'
        END AS [Output_Segment]

    FROM classified
)
SELECT * FROM final
ORDER BY [Migration_Track], [INITIATIVE_LEGACY_ID]
"""


def run_transform(conn):
    log_step("4/6", "Running transformation SQL...")

    all_df = pd.read_sql(TRANSFORM_SQL, conn)

    # Split into result sets
    final_df = all_df[
        all_df["Output_Segment"] == "TE-BusinessDemandMgmt"
    ].reset_index(drop=True)

    stopwork_df = all_df[
        all_df["Output_Segment"].str.contains("HOLD", na=False)
    ].reset_index(drop=True)

    review_df = all_df[
        all_df["Output_Segment"].str.startswith("REVIEW", na=False)
    ].reset_index(drop=True)

    excluded_df = all_df[
        all_df["Output_Segment"] == "Excluded-Status"
    ].reset_index(drop=True)

    seg_counts = final_df["Output_Segment"].value_counts()

    log(f"Total rows processed            : {len(all_df):,}", 1)
    log(f"", 1)
    log(f"Final Output (ready)              : {len(final_df):,}", 1)
    log(f"  TE-BusinessDemandMgmt           : {seg_counts.get('TE-BusinessDemandMgmt', 0):,}  <- Business Only direct map", 2)
    log(f"", 1)
    log(f"Review Required (ESI/NRB missing) : {len(review_df):,}  <- BwT need ESPM flags", 1)
    log(f"Excluded (status-based)           : {len(excluded_df):,}  <- BR_STATUS_001", 1)

    return final_df, stopwork_df, review_df, excluded_df


# ────────────────────────────────────────────────────────────
# STEP 5 — Validate output
# ────────────────────────────────────────────────────────────
def validate(final_df, stopwork_df, review_df):
    log_step("5/6", "Validating output...")
    errors = []
    warnings = []

    if len(final_df) == 0 and len(stopwork_df) == 0:
        errors.append("Both Final Output and Stop Work Hold are empty")

    dupes = final_df.duplicated(subset=["INITIATIVE_LEGACY_ID"]).sum()
    if dupes > 0:
        errors.append(f"{dupes:,} duplicate INITIATIVE_LEGACY_ID(s) in Final Output")

    unexpected = set(final_df["Output_Segment"].unique()) - VALID_SEGMENTS
    if unexpected:
        errors.append(f"Unexpected Output_Segment values: {unexpected}")

    if len(stopwork_df) > 0:
        warnings.append(f"{len(stopwork_df):,} Stop Work records in HOLD — Finance/Triage sign-off needed")
    if len(review_df) > 0:
        warnings.append(f"{len(review_df):,} records need ESI Flag + NRB from ESPM to complete classification")

    if errors:
        log("VALIDATION FAILED:", 1)
        for e in errors:
            log(f"  - {e}", 1)
        sys.exit(1)
    else:
        log("All checks passed", 1)
        log(f"  Duplicate IDs   : OK (0 duplicates)", 1)
        log(f"  Segment values  : OK", 1)

    if warnings:
        log("Warnings (non-fatal):", 1)
        for w in warnings:
            log(f"  ! {w}", 1)


# ────────────────────────────────────────────────────────────
# STEP 6a — Build Excel in memory
# ────────────────────────────────────────────────────────────
def build_excel_bytes(final_df, stopwork_df, review_df, excluded_df):
    final_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio", "Pod",
        "Demand_Sub_Type", "Migration_Source", "Migration_Track", "Output_Segment",
    ]
    hold_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio",
        "Demand_Sub_Type", "Output_Segment", "Migration_Track",
    ]
    review_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio", "Output_Segment",
    ]
    excluded_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Output_Segment",
    ]

    def safe_cols(df, cols):
        return [c for c in cols if c in df.columns]

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        final_df[safe_cols(final_df, final_cols)].to_excel(
            writer, sheet_name="Final_Output", index=False)
        stopwork_df[safe_cols(stopwork_df, hold_cols)].to_excel(
            writer, sheet_name="StopWork_Hold", index=False)
        review_df[safe_cols(review_df, review_cols)].to_excel(
            writer, sheet_name="Review_Required", index=False)
        excluded_df[safe_cols(excluded_df, excluded_cols)].to_excel(
            writer, sheet_name="Excluded_Records", index=False)

        for sheet_name in writer.sheets:
            ws = writer.sheets[sheet_name]
            for col in ws.columns:
                max_len = max((len(str(c.value)) for c in col if c.value), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

    return buffer.getvalue()


# ────────────────────────────────────────────────────────────
# STEP 6a — Save to local folder
# ────────────────────────────────────────────────────────────
def save_to_folder(excel_bytes, ts):
    out_name = f"Planview_PortMgr_Output_{ts}.xlsx"
    folder   = Path(OUTPUT_FOLDER)
    folder.mkdir(parents=True, exist_ok=True)
    out_path = folder / out_name
    with open(out_path, "wb") as f:
        f.write(excel_bytes)
    log(f"File saved : {out_path}", 1)
    return out_path


# ────────────────────────────────────────────────────────────
# STEP 6b — Send via Outlook desktop
# ────────────────────────────────────────────────────────────
def send_email(excel_bytes, ts, final_df, stopwork_df, review_df, excluded_df):
    out_name   = f"Planview_PortMgr_Output_{ts}.xlsx"
    saved_path = Path(OUTPUT_FOLDER) / out_name
    tmp_path   = None
    _delete_after = False

    body = (
        f"Hi team,\n\n"
        f"Please find attached the Planview Migration Pipeline output for the\n"
        f"Portfolio Manager file (Portfolio_Manager_-_New_List.xlsx) — run {ts}.\n\n"
        f"The file contains four sheets:\n"
        f"  - Final_Output    : {len(final_df):,} records ready to migrate\n"
        f"  - StopWork_Hold   : {len(stopwork_df):,} records pending Finance / Triage sign-off\n"
        f"  - Review_Required : {len(review_df):,} records — ESI Flag / NRB missing (need ESPM data)\n"
        f"  - Excluded_Records: {len(excluded_df):,} records — status-based exclusion (BR_STATUS_001)\n\n"
        f"This is an automated email from the Planview Migration Pipeline v9.\n\n"
        f"Regards,\nMigration Pipeline\n"
    )

    try:
        import win32com.client

        if saved_path.exists():
            tmp_path = str(saved_path)
        else:
            with tempfile.NamedTemporaryFile(suffix=".xlsx", prefix="pv_portmgr_", delete=False) as tmp:
                tmp.write(excel_bytes)
                tmp_path = tmp.name
            _delete_after = True

        outlook = win32com.client.Dispatch("Outlook.Application")
        mail    = outlook.CreateItem(0)

        # Add recipients using Recipients.Add — more reliable with corporate GAL
        # Resolves addresses against the FedEx Global Address List
        for addr in EMAIL_TO:
            recip = mail.Recipients.Add(addr)
            recip.Type = 1   # 1 = olTo
            if not recip.Resolve():
                log(f"WARNING: Could not resolve address: {addr}", 1)
                log("  Check the email address is correct and exists in the FedEx GAL.", 2)

        for addr in EMAIL_CC:
            recip = mail.Recipients.Add(addr)
            recip.Type = 2   # 2 = olCC
            recip.Resolve()

        mail.Subject = f"{EMAIL_SUBJECT} - {ts}"
        mail.Body    = body
        mail.Attachments.Add(tmp_path)
        mail.Send()

        log(f"Sent via   : Outlook desktop", 1)
        log(f"Sent to    : {'; '.join(EMAIL_TO)}", 1)
        log(f"Attachment : {out_name}", 1)

    except ImportError:
        log("ERROR: pywin32 is not installed. Run: pip install pywin32", 1)
        sys.exit(1)
    except Exception as e:
        log(f"ERROR: Could not send via Outlook: {e}", 1)
        log("- Make sure Outlook is open and logged in before running.", 2)
        sys.exit(1)
    finally:
        if tmp_path and _delete_after and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


# ────────────────────────────────────────────────────────────
# CLEANUP
# ────────────────────────────────────────────────────────────
def cleanup(cursor, conn):
    try:
        cursor.execute(f"DROP TABLE IF EXISTS {STAGING_TABLE}")
        log("Cleanup  : Staging table dropped", 1)
    except Exception:
        pass
    # No temp CSV to delete — data loaded directly via parameterised INSERT
    conn.close()


# ────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────
def main():
    start = datetime.now()
    ts_run = start.strftime("%Y%m%d_%H%M%S")

    # Initialise logger — creates log file in OUTPUT_FOLDER
    log_file = init_logger(ts_run)

    log(SEPARATOR)
    log("  Planview Migration Pipeline v9 — Portfolio Manager Edition")
    log(f"  Input  : Portfolio Manager - New List (3).xlsx  [PortMgr_Input]")
    log(f"  Started: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"  Log    : {log_file}")
    log(SEPARATOR)
    log("  Rules: BusinessRules_DataMigration_Detail_breakdown.xlsx")
    log("         DRAFT_Business_Rules_for_Data_Migration__2_.xlsx")
    log(SEPARATOR)

    df, input_path = read_excel_data()
    conn           = connect_sql()
    cursor         = bulk_insert(conn, df)

    final_df, stopwork_df, review_df, excluded_df = run_transform(conn)

    validate(final_df, stopwork_df, review_df)

    ts          = ts_run   # reuse run timestamp for consistent file/log naming
    excel_bytes = build_excel_bytes(final_df, stopwork_df, review_df, excluded_df)

    log_step("6a/6", "Saving output Excel to local folder...")
    out_path = save_to_folder(excel_bytes, ts)

    log_step("6b/6", "Sending output Excel via Outlook desktop...")
    send_email(excel_bytes, ts, final_df, stopwork_df, review_df, excluded_df)

    cleanup(cursor, conn)

    elapsed = round((datetime.now() - start).total_seconds(), 1)
    log(f"\n{SEPARATOR}")
    log("  PIPELINE COMPLETE — PORTFOLIO MANAGER FILE")
    log(f"  Saved to      : {out_path}")
    log(f"  Log file      : {log_file}")
    log(f"  Email sent to : {', '.join(EMAIL_TO)}")
    log(f"  Records       : {len(final_df):,} ready | {len(stopwork_df):,} HOLD | {len(review_df):,} review | {len(excluded_df):,} excluded")
    log(f"  Runtime       : {elapsed}s")
    log(SEPARATOR)


if __name__ == "__main__":
    main()
