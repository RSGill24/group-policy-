"""
============================================================
Planview Migration Pipeline — portmgr File Edition
============================================================
Usage:
  py planview_portmgr_pipeline_v4.py
============================================================
"""

import pandas as pd
import pyodbc
import sys
import os
import io
import tempfile
import logging
import json
import argparse
from datetime import datetime
from pathlib import Path

# ============================================================
# CONFIG — all settings loaded from JSON config file at runtime
# ============================================================

# Globals — populated by load_config() at startup
INPUT_FILE    = ""
INPUT_SHEET   = ""
SQL_SERVER    = ""
SQL_DATABASE  = ""
OUTPUT_FOLDER = ""
EMAIL_ENABLED = False
EMAIL_TO      = []
EMAIL_CC      = []
EMAIL_SUBJECT = ""

VALID_SEGMENTS = {
    "TE-BusinessDemandMgmt",
    "REVIEW-ESI-NRB-Missing",
    "Excluded-Status",
}

# ============================================================



def load_config(config_path=None):
    """Load all settings from JSON config file into global variables.
    Default config file: planview_portmgr_config.json (same folder as script).
    Override with:  py planview_kanban_pipeline_v5.py --config path/to/config.json
    """
    global INPUT_FILE, INPUT_SHEET, SQL_SERVER, SQL_DATABASE
    global OUTPUT_FOLDER, EMAIL_ENABLED, EMAIL_TO, EMAIL_CC, EMAIL_SUBJECT

    if config_path is None:
        config_path = Path(__file__).parent / "planview_portmgr_config.json"

    config_path = Path(config_path)
    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}")
        print(f"  Create planview_portmgr_config.json in the same folder as this script.")
        sys.exit(1)

    try:
        with open(config_path, encoding="utf-8") as f:
            cfg = json.load(f)
    except json.JSONDecodeError as e:
        print(f"ERROR: Config file is not valid JSON: {e}")
        sys.exit(1)

    INPUT_FILE    = cfg["input"]["file"]
    INPUT_SHEET   = cfg["input"]["sheet"]
    SQL_SERVER    = cfg["sql"]["server"]
    SQL_DATABASE  = cfg["sql"]["database"]
    OUTPUT_FOLDER = cfg["output"]["folder"]
    EMAIL_ENABLED = cfg.get("email", {}).get("enabled", False)
    EMAIL_TO      = cfg.get("email", {}).get("to",      [])
    EMAIL_CC      = cfg.get("email", {}).get("cc",      [])
    EMAIL_SUBJECT = cfg.get("email", {}).get("subject", "Planview Migration — Portfolio Manager Initiative Output")

    print(f"Config loaded : {config_path}")
    print(f"  Input file  : {INPUT_FILE}")
    print(f"  Input sheet : {INPUT_SHEET}")
    print(f"  SQL Server  : {SQL_SERVER} / {SQL_DATABASE}")
    print(f"  Output      : {OUTPUT_FOLDER}")
    print(f"  Email       : {'ENABLED' if EMAIL_ENABLED else 'DISABLED'}")

SEPARATOR = "=" * 60

# ── Logging setup ────────────────────────────────────────────────────────
# Logs are written to BOTH the console and a timestamped .log file
# saved in OUTPUT_FOLDER. The logger is initialised in main() once
# OUTPUT_FOLDER is confirmed to exist.
_logger = None

def init_logger(ts):
    """Create timestamped log file in OUTPUT_FOLDER and wire up the logger."""
    global _logger
    log_dir = Path(OUTPUT_FOLDER)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"pipeline_run_{ts}.log"

    _logger = logging.getLogger("pipeline")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()   # avoid duplicate handlers on re-run

    # File handler — full detail to log file
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s  %(message)s",
                                       datefmt="%Y-%m-%d %H:%M:%S"))
    _logger.addHandler(fh)

    # Console handler — mirrors what was already printing
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(ch)

    return log_file


def log(msg, indent=0):
    line = "  " * indent + msg
    if _logger:
        _logger.info(line)
    else:
        print(line)


def log_step(num, msg):
    line = f"\n[{num}] {msg}"
    if _logger:
        _logger.info(line)
    else:
        print(line)


# ────────────────────────────────────────────────────────────
# STEP 1 — Read Excel and save as temp CSV
# ────────────────────────────────────────────────────────────
def read_excel_data():
    log_step("1/6", "Reading Portfolio Manager Excel...")
    path = Path(INPUT_FILE)

    if not path.exists():
        log(f"ERROR: File not found: {path}", 1)
        log("Check the INPUT_FILE path in the CONFIG section.", 1)
        sys.exit(1)

    try:
        # Row 0 is the banner, row 1 is the actual column header row
        df = pd.read_excel(path, sheet_name=INPUT_SHEET, dtype=str, header=0)
    except Exception as e:
        log(f"ERROR reading sheet '{INPUT_SHEET}': {e}", 1)
        sys.exit(1)

    # Strip blank rows
    if "Strategy Seq. ID" in df.columns:
        df = df[
            df["Strategy Seq. ID"].notna() &
            (df["Strategy Seq. ID"].str.strip() != "")
        ].reset_index(drop=True)

    df = df.fillna("")

    # Clean free-text columns before writing to pipe-delimited CSV.
    # Status Rationale and similar fields contain newlines, pipe characters,
    # and double quotes. Strip them all out.
    free_text_cols = [
        "Status Rationale", "Initiative Owner", "Health Status",
        "Lifecycle Model", "Name",
    ]
    for col in free_text_cols:
        if col in df.columns:
            df[col] = (
                df[col]
                .str.replace("\n", " ", regex=False)   # newlines -> space
                .str.replace("\r", " ", regex=False)   # carriage returns -> space
                .str.replace("|",   " ", regex=False)   # pipe -> space (field separator)
                .str.replace('"',   "'", regex=False)   # double quote -> single quote
                .str.strip()
            )

    # Validate required columns
    required_cols = [
        "Strategy Seq. ID",
        "Name",
        "Initiative Type",
        "Lifecycle Status",
        "Domain",
    ]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        log("ERROR: Required column(s) missing:", 1)
        for m in missing:
            log(f"  - {m}", 2)
        sys.exit(1)

    log(f"Input    : {path.name}", 1)
    log(f"Sheet    : {INPUT_SHEET}", 1)
    log(f"Rows     : {len(df):,}", 1)
    log(f"Columns  : {len(df.columns)}", 1)

    return df, path


# ────────────────────────────────────────────────────────────
# STEP 2 — Connect to SQL Server
# ────────────────────────────────────────────────────────────
def connect_sql():
    log_step("2/6", "Connecting to SQL Server...")
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SQL_SERVER};"
            f"DATABASE={SQL_DATABASE};"
            f"Trusted_Connection=yes;"
            f"Connection Timeout=30;"
        )
        conn.autocommit = True
        log(f"Server   : {SQL_SERVER}", 1)
        log(f"Database : {SQL_DATABASE}", 1)
        log("Status   : Connected", 1)
        return conn
    except pyodbc.Error as e:
        log("ERROR: Could not connect to SQL Server", 1)
        log(f"Detail : {e}", 1)
        sys.exit(1)


# ────────────────────────────────────────────────────────────
# STEP 3 — Create permanent input schema + table, load all rows
# ────────────────────────────────────────────────────────────
# Schema : input_{timestamp}
# Table  : {input_file_name}  (hyphens/spaces stripped)
# Every run creates a new schema — nothing ever dropped or overwritten
def create_input_schema_and_load(conn, df, input_path, ts):
    log_step("3/6", f"Creating permanent input schema and loading {len(df):,} rows...")
    cursor = conn.cursor()

    # Derive clean table name from input file name
    # Strip extension, replace spaces/hyphens/dots with underscore
    import re
    raw_name     = input_path.stem   # filename without extension
    table_name   = re.sub(r'[^A-Za-z0-9_]', '_', raw_name).strip('_')
    schema_name  = f"input_{ts}"

    # Create schema (ignore if already exists)
    cursor.execute(f"""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '{schema_name}')
            EXEC('CREATE SCHEMA [{schema_name}]')
    """)
    log(f"Schema   : [{schema_name}] created", 1)

    # Drop table if somehow exists (same ts collision)
    cursor.execute(f"""
        IF OBJECT_ID('[{schema_name}].[{table_name}]') IS NOT NULL
            DROP TABLE [{schema_name}].[{table_name}]
    """)

    # Build CREATE TABLE — long free-text columns get nvarchar(MAX)
    long_cols = {"Status Rationale", "Initiative Owner"}
    col_defs  = ",\n            ".join(
        [f"[{col}] nvarchar(MAX)" if col in long_cols
         else f"[{col}] nvarchar(500)"
         for col in df.columns]
    )
    cursor.execute(f"""
        CREATE TABLE [{schema_name}].[{table_name}] (
            [Run_ID]        nvarchar(50)  DEFAULT '{ts}',
            [Load_Timestamp] datetime     DEFAULT GETDATE(),
            {col_defs}
        )
    """)
    log(f"Table    : [{schema_name}].[{table_name}] created ({len(df.columns)} columns)", 1)

    # Parameterised INSERT — no CSV, no encoding issues
    col_names    = ", ".join([f"[{col}]" for col in df.columns])
    placeholders = ", ".join(["?" for _ in df.columns])
    insert_sql   = (
        f"INSERT INTO [{schema_name}].[{table_name}] "
        f"([Run_ID], [Load_Timestamp], {col_names}) "
        f"VALUES ('{ts}', GETDATE(), {placeholders})"
    )

    # Clean free-text columns
    df_clean = df.where(df.notna(), None)
    for col in df_clean.columns:
        if df_clean[col].dtype == object:
            df_clean[col] = (
                df_clean[col]
                .str.replace("\n", " ", regex=False)
                .str.replace("\r", " ", regex=False)
                .str.replace("|",   " ", regex=False)
                .str.replace('"',   "'", regex=False)
                .str.strip()
                if hasattr(df_clean[col], "str") else df_clean[col]
            )

    # Insert in batches of 500
    BATCH_SIZE = 500
    rows   = [tuple(row) for row in df_clean.itertuples(index=False, name=None)]
    total  = len(rows)
    loaded = 0

    conn.autocommit = False
    try:
        for i in range(0, total, BATCH_SIZE):
            batch = rows[i : i + BATCH_SIZE]
            cursor.executemany(insert_sql, batch)
            loaded += len(batch)
            log(f"  Inserted {loaded:,} / {total:,} rows...", 1)
        conn.commit()
    except Exception as e:
        conn.rollback()
        log(f"ERROR: Insert failed at row {loaded}: {e}", 1)
        raise
    finally:
        conn.autocommit = True

    cursor.execute(f"SELECT COUNT(*) FROM [{schema_name}].[{table_name}]")
    db_count = cursor.fetchone()[0]
    log(f"Loaded   : {db_count:,} rows confirmed", 1)
    log(f"Location : [{schema_name}].[{table_name}]", 1)

    return cursor, schema_name, table_name

# ────────────────────────────────────────────────────────────
# STEP 4 — Transformation SQL
# ────────────────────────────────────────────────────────────

TRANSFORM_SQL = """
WITH classified AS (
    SELECT
        [Strategy Seq. ID]           AS [INITIATIVE_LEGACY_ID],
        [Name]                       AS [Initiative_Name],
        [Initiative Type]            AS [Demand_Type],
        [Lifecycle Status]           AS [Work_Status_Raw],
        [Stage],
        [Domain]                     AS [Portfolio],
        [Pod],
        [Work Actual/Schedule Start],
        [Work Actual/Schedule Finish],

        -- Work Status normalisation
        CASE [Lifecycle Status]
            WHEN 'Active'               THEN 'Active'
            WHEN 'Cancelled'            THEN 'Cancelled'
            WHEN 'Completed'            THEN 'Completed'
            WHEN 'On Hold'              THEN 'On Hold'
            WHEN 'Rejected'             THEN 'Rejected'
            WHEN 'Cancellation Request' THEN 'Cancellation Request'
            ELSE [Lifecycle Status]
        END AS [Work_Status],

        -- Migration Track
        CASE

            -- BR_STATUS_001 
            -- Exclude: Cancelled, Completed, On Hold, Rejected, Cancellation Request
            WHEN [Lifecycle Status] IN
                 ('Cancelled','Completed','On Hold','Rejected','Cancellation Request')
                THEN 'EXCLUDED-Status'

            -- BR_TE_006 
            -- Business Only Initiative → Business Demand Management
            -- NOTE: No T-shirt criterion applies (confirmed File 3 Definitions)
            WHEN [Initiative Type] = 'Business Only Initiative'
                THEN 'Tech-Enabled -- Business Only'

            -- BR_TE_001/002/003 
            -- Business w/Tech Initiative → Review Required
            -- ESI Flag and NRB not in source file — cannot fully classify
            -- Once ESPM provides ESI Flag + NRB, uncomment rules below:
            --
            -- BR_TE_004: Business Continuity
            -- WHEN [BC_Flag] = 'Y' THEN 'Tech-Enabled -- Business Continuity'
            --
            -- BR_PC_001/002: PC Strategic Programs
            -- WHEN [PC_Flag] = 'Y' THEN 'PC Strategic Programs'
            --
            -- BR_ND_DT_001: Digital Transformation Exception
            -- WHEN [DT_Flag] = 'Y' THEN 'Non-Drive / DT Exception'
            --
            -- BR_TE_001: Strategic Investment (ESI=Y, L/XL, NRB >= $10M)
            -- WHEN [ESI_Flag]='Y' AND [T_Shirt_Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) >= 10
            --     THEN 'Tech-Enabled -- Strategic Investment'
            --
            -- BR_TE_002: Stop Work (L/XL, NRB < $10M)
            -- WHEN [T_Shirt_Size] IN ('4: L','5: XL')
            --      AND TRY_CAST([NRB_M] AS DECIMAL(12,2)) < 10
            --     THEN 'Tech-Enabled -- Stop Work (Pending Finance)'
            --
            -- BR_TE_003: Discretionary Other (ESI=Y, S/M/XS)
            -- WHEN [ESI_Flag]='Y' AND [T_Shirt_Size] IN ('1: XS','2: S','3: M')
            --     THEN 'Tech-Enabled -- Discretionary Other'

            WHEN [Initiative Type] = 'Business w/ Tech Initiative'
                THEN 'REVIEW REQUIRED'

            ELSE 'REVIEW REQUIRED'
        END AS [Migration_Track]

    FROM [{input_schema}].[{input_table}]
),
final AS (
    SELECT
        [INITIATIVE_LEGACY_ID], [Initiative_Name], [Demand_Type],
        [Work_Status], [Stage], [Portfolio], [Pod],
        [Work Actual/Schedule Start], [Work Actual/Schedule Finish],

        -- Demand Sub-Type
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only'
                THEN 'Business Demand Management'
            WHEN 'EXCLUDED-Status'
                THEN 'N/A - Excluded'
            ELSE 'REVIEW REQUIRED - ESI Flag / NRB Missing'
        END AS [Demand_Sub_Type],

        -- Migration Source
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only' THEN 'Current Prod / ESPM (TBC)'
            WHEN 'EXCLUDED-Status'               THEN 'N/A - Excluded'
            ELSE 'Current Prod -> New Prod'
        END AS [Migration_Source],

        [Migration_Track],

        -- Output Segment
        CASE [Migration_Track]
            WHEN 'Tech-Enabled -- Business Only' THEN 'TE-BusinessDemandMgmt'
            WHEN 'EXCLUDED-Status'               THEN 'Excluded-Status'
            ELSE 'REVIEW-ESI-NRB-Missing'
        END AS [Output_Segment]

    FROM classified
)
SELECT * FROM final
ORDER BY [Migration_Track], [INITIATIVE_LEGACY_ID]
"""


def run_transform(conn, input_schema, input_table):
    log_step("4/6", "Running transformation SQL...")

    sql = TRANSFORM_SQL.format(
        input_schema=input_schema,
        input_table=input_table
    )
    all_df = pd.read_sql(sql, conn)

    # Split into result sets
    final_df = all_df[
        all_df["Output_Segment"] == "TE-BusinessDemandMgmt"
    ].reset_index(drop=True)

    stopwork_df = all_df[
        all_df["Output_Segment"].str.contains("HOLD", na=False)
    ].reset_index(drop=True)

    review_df = all_df[
        all_df["Output_Segment"].str.startswith("REVIEW", na=False)
    ].reset_index(drop=True)

    excluded_df = all_df[
        all_df["Output_Segment"] == "Excluded-Status"
    ].reset_index(drop=True)

    seg_counts = final_df["Output_Segment"].value_counts()

    log(f"Total rows processed            : {len(all_df):,}", 1)
    log(f"", 1)
    log(f"Final Output (ready)              : {len(final_df):,}", 1)
    log(f"  TE-BusinessDemandMgmt           : {seg_counts.get('TE-BusinessDemandMgmt', 0):,}  <- Business Only direct map", 2)
    log(f"", 1)
    log(f"Review Required (ESI/NRB missing) : {len(review_df):,}  <- BwT need ESPM flags", 1)
    log(f"Excluded (status-based)           : {len(excluded_df):,}  <- BR_STATUS_001", 1)

    return final_df, stopwork_df, review_df, excluded_df


# ────────────────────────────────────────────────────────────
# STEP 5 — Validate output
# ────────────────────────────────────────────────────────────
def validate(final_df, stopwork_df, review_df):
    log_step("5/6", "Validating output...")
    errors = []
    warnings = []

    if len(final_df) == 0 and len(stopwork_df) == 0:
        errors.append("Both Final Output and Stop Work Hold are empty")

    dupes = final_df.duplicated(subset=["INITIATIVE_LEGACY_ID"]).sum()
    if dupes > 0:
        errors.append(f"{dupes:,} duplicate INITIATIVE_LEGACY_ID(s) in Final Output")

    unexpected = set(final_df["Output_Segment"].unique()) - VALID_SEGMENTS
    if unexpected:
        errors.append(f"Unexpected Output_Segment values: {unexpected}")

    if len(stopwork_df) > 0:
        warnings.append(f"{len(stopwork_df):,} Stop Work records in HOLD — Finance/Triage sign-off needed")
    if len(review_df) > 0:
        warnings.append(f"{len(review_df):,} records need ESI Flag + NRB from ESPM to complete classification")

    if errors:
        log("VALIDATION FAILED:", 1)
        for e in errors:
            log(f"  - {e}", 1)
        sys.exit(1)
    else:
        log("All checks passed", 1)
        log(f"  Duplicate IDs   : OK (0 duplicates)", 1)
        log(f"  Segment values  : OK", 1)

    if warnings:
        log("Warnings (non-fatal):", 1)
        for w in warnings:
            log(f"  ! {w}", 1)


# ────────────────────────────────────────────────────────────
# STEP 5b — Create permanent output schema + tables in SQL Server
# ────────────────────────────────────────────────────────────
def create_output_schema_and_save(conn, final_df, stopwork_df,
                                   review_df, excluded_df,
                                   input_table, ts):
    """Create output_{ts} schema and save all four result sets as
    permanent tables named after the input file."""
    import re
    schema_name = f"output_{ts}"
    cursor = conn.cursor()

    # Create output schema
    cursor.execute(f"""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '{schema_name}')
            EXEC('CREATE SCHEMA [{schema_name}]')
    """)
    log(f"Schema   : [{schema_name}] created", 1)

    def save_df_to_sql(df, table_suffix):
        tbl = f"{input_table}_{table_suffix}"
        cursor.execute(f"""
            IF OBJECT_ID('[{schema_name}].[{tbl}]') IS NOT NULL
                DROP TABLE [{schema_name}].[{tbl}]
        """)
        if df.empty:
            log(f"  [{schema_name}].[{tbl}] — 0 rows (skipped)", 1)
            return
        col_defs = ", ".join([f"[{c}] nvarchar(MAX)" for c in df.columns])
        cursor.execute(f"""
            CREATE TABLE [{schema_name}].[{tbl}] (
                [Run_ID]          nvarchar(50) DEFAULT '{ts}',
                [Save_Timestamp]  datetime     DEFAULT GETDATE(),
                {col_defs}
            )
        """)
        col_names    = ", ".join([f"[{c}]" for c in df.columns])
        placeholders = ", ".join(["?" for _ in df.columns])
        insert_sql   = (
            f"INSERT INTO [{schema_name}].[{tbl}] "
            f"([Run_ID],[Save_Timestamp],{col_names}) "
            f"VALUES ('{ts}',GETDATE(),{placeholders})"
        )
        df_clean = df.where(df.notna(), None)
        rows = [tuple(r) for r in df_clean.itertuples(index=False, name=None)]
        conn.autocommit = False
        try:
            for i in range(0, len(rows), 500):
                cursor.executemany(insert_sql, rows[i:i+500])
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise
        finally:
            conn.autocommit = True
        log(f"  [{schema_name}].[{tbl}] — {len(df):,} rows saved", 1)

    save_df_to_sql(final_df,    "Final_Output")
    save_df_to_sql(stopwork_df, "StopWork_Hold")
    save_df_to_sql(review_df,   "Review_Required")
    save_df_to_sql(excluded_df, "Excluded_Records")


# ────────────────────────────────────────────────────────────
# RUN HISTORY — log every pipeline run
# ────────────────────────────────────────────────────────────
def log_run_history(conn, ts, input_path, input_schema, input_table,
                    output_schema, final_df, stopwork_df,
                    review_df, excluded_df, out_path, elapsed, status):
    """Create run_history schema + Pipeline_Runs table if needed,
    then insert one row for this run."""
    cursor = conn.cursor()

    cursor.execute("""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'run_history')
            EXEC('CREATE SCHEMA [run_history]')
    """)
    cursor.execute("""
        IF OBJECT_ID('run_history.Pipeline_Runs') IS NULL
        CREATE TABLE run_history.Pipeline_Runs (
            Run_ID              nvarchar(50)  PRIMARY KEY,
            Run_Timestamp       datetime      DEFAULT GETDATE(),
            Pipeline_Name       nvarchar(200),
            Input_File          nvarchar(500),
            Input_Schema        nvarchar(200),
            Input_Table         nvarchar(200),
            Output_Schema       nvarchar(200),
            Input_Row_Count     int,
            Final_Output_Count  int,
            StopWork_Count      int,
            Review_Count        int,
            Excluded_Count      int,
            Output_File_Path    nvarchar(500),
            Runtime_Seconds     decimal(10,1),
            Run_Status          nvarchar(50)
        )
    """)

    cursor.execute("""
        INSERT INTO run_history.Pipeline_Runs (
            Run_ID, Pipeline_Name, Input_File,
            Input_Schema, Input_Table, Output_Schema,
            Input_Row_Count, Final_Output_Count, StopWork_Count,
            Review_Count, Excluded_Count, Output_File_Path,
            Runtime_Seconds, Run_Status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        ts,
        'Portfolio Manager Pipeline',
        str(input_path),
        input_schema,
        input_table,
        output_schema,
        len(final_df) + len(stopwork_df) + len(review_df) + len(excluded_df),
        len(final_df),
        len(stopwork_df),
        len(review_df),
        len(excluded_df),
        str(out_path),
        elapsed,
        status
    ))
    conn.commit()
    log(f"Run logged : run_history.Pipeline_Runs — Run_ID: {ts}", 1)


# ────────────────────────────────────────────────────────────
# STEP 6a — Build Excel in memory
# ────────────────────────────────────────────────────────────
def build_excel_bytes(final_df, stopwork_df, review_df, excluded_df):
    final_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio", "Pod",
        "Demand_Sub_Type", "Migration_Source", "Migration_Track", "Output_Segment",
    ]
    hold_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio",
        "Demand_Sub_Type", "Output_Segment", "Migration_Track",
    ]
    review_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Portfolio", "Output_Segment",
    ]
    excluded_cols = [
        "INITIATIVE_LEGACY_ID", "Initiative_Name", "Demand_Type",
        "Work_Status", "Stage", "Output_Segment",
    ]

    def safe_cols(df, cols):
        return [c for c in cols if c in df.columns]

    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        final_df[safe_cols(final_df, final_cols)].to_excel(
            writer, sheet_name="Final_Output", index=False)
        stopwork_df[safe_cols(stopwork_df, hold_cols)].to_excel(
            writer, sheet_name="StopWork_Hold", index=False)
        review_df[safe_cols(review_df, review_cols)].to_excel(
            writer, sheet_name="Review_Required", index=False)
        excluded_df[safe_cols(excluded_df, excluded_cols)].to_excel(
            writer, sheet_name="Excluded_Records", index=False)

        for sheet_name in writer.sheets:
            ws = writer.sheets[sheet_name]
            for col in ws.columns:
                max_len = max((len(str(c.value)) for c in col if c.value), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

    return buffer.getvalue()


# ────────────────────────────────────────────────────────────
# STEP 6a — Save to local folder
# ────────────────────────────────────────────────────────────
def save_to_folder(excel_bytes, ts, input_path):
    """Output file named after the input file + timestamp."""
    stem     = input_path.stem   # filename without extension
    out_name = f"{stem}_Output_{ts}.xlsx"
    folder   = Path(OUTPUT_FOLDER)
    folder.mkdir(parents=True, exist_ok=True)
    out_path = folder / out_name
    with open(out_path, "wb") as f:
        f.write(excel_bytes)
    log(f"File saved : {out_path}", 1)
    return out_path


# ────────────────────────────────────────────────────────────
# STEP 6b — Send via Outlook desktop
# ────────────────────────────────────────────────────────────
#
# def send_email(excel_bytes, ts, input_path, final_df, stopwork_df, review_df, excluded_df):
#     stem       = input_path.stem
#     out_name   = f"{stem}_Output_{ts}.xlsx"
#     saved_path = Path(OUTPUT_FOLDER) / out_name
#     tmp_path   = None
#     _delete_after = False
#
#     body = (
#         f"Hi team,\n\n"
#         f"Please find attached the Planview Migration Pipeline output for the\n"
#         f"Portfolio Manager file ({input_path.name}) — run {ts}.\n\n"
#         f"The file contains four sheets:\n"
#         f"  - Final_Output    : {len(final_df):,} records ready to migrate\n"
#         f"  - StopWork_Hold   : {len(stopwork_df):,} records pending Finance / Triage sign-off\n"
#         f"  - Review_Required : {len(review_df):,} records — ESI Flag / NRB missing\n"
#         f"  - Excluded_Records: {len(excluded_df):,} records — status-based exclusion (BR_STATUS_001)\n\n"
#         f"This is an automated email from the Planview Migration Pipeline.\n\n"
#         f"Regards,\nMigration Pipeline\n"
#     )
#
#     try:
#         import win32com.client
#
#         if saved_path.exists():
#             tmp_path = str(saved_path)
#         else:
#             with tempfile.NamedTemporaryFile(suffix=".xlsx", prefix="pv_portmgr_", delete=False) as tmp:
#                 tmp.write(excel_bytes)
#                 tmp_path = tmp.name
#             _delete_after = True
#
#         outlook = win32com.client.Dispatch("Outlook.Application")
#         mail    = outlook.CreateItem(0)
#
#         for addr in EMAIL_TO:
#             recip = mail.Recipients.Add(addr)
#             recip.Type = 1
#             if not recip.Resolve():
#                 log(f"WARNING: Could not resolve address: {addr}", 1)
#
#         for addr in EMAIL_CC:
#             recip = mail.Recipients.Add(addr)
#             recip.Type = 2
#             recip.Resolve()
#
#         mail.Subject = f"{EMAIL_SUBJECT} - {ts}"
#         mail.Body    = body
#         mail.Attachments.Add(tmp_path)
#         mail.Send()
#
#         log(f"Sent via   : Outlook desktop", 1)
#         log(f"Sent to    : {'; '.join(EMAIL_TO)}", 1)
#         log(f"Attachment : {out_name}", 1)
#
#     except ImportError:
#         log("ERROR: pywin32 is not installed. Run: pip install pywin32", 1)
#         sys.exit(1)
#     except Exception as e:
#         log(f"ERROR: Could not send via Outlook: {e}", 1)
#         log("- Make sure Outlook is open and logged in before running.", 2)
#         sys.exit(1)
#     finally:
#         if tmp_path and _delete_after and os.path.exists(tmp_path):
#             try:
#                 os.remove(tmp_path)
#             except Exception:
#                 pass
#
#
# ────────────────────────────────────────────────────────────
# CLEANUP
# ────────────────────────────────────────────────────────────
def cleanup(conn):
    """Close the SQL connection. Schemas and tables are permanent — nothing dropped."""
    conn.close()
    log("Cleanup  : SQL connection closed", 1)


# ────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None,
                        help="Path to JSON config file")
    args = parser.parse_args()
    load_config(args.config)

    start = datetime.now()
    ts_run = start.strftime("%Y%m%d_%H%M%S")

    # Initialise logger — creates log file in OUTPUT_FOLDER
    log_file = init_logger(ts_run)

    log(SEPARATOR)
    log("  Planview Migration Pipeline — Portfolio Manager Edition")
    log(f"  Input  : Portfolio Manager - New List (3).xlsx  [PortMgr_Input]")
    log(f"  Started: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"  Log    : {log_file}")
    log(SEPARATOR)
  
    df, input_path = read_excel_data()
    conn           = connect_sql()

    # Step 3 — Create permanent input schema + table
    cursor, input_schema, input_table = create_input_schema_and_load(
        conn, df, input_path, ts_run
    )

    # Step 4 — Run transformation SQL against the permanent input table
    final_df, stopwork_df, review_df, excluded_df = run_transform(
        conn, input_schema, input_table
    )

    validate(final_df, stopwork_df, review_df)

    ts = ts_run

    # Step 5a — Save output to permanent SQL Server schema + tables
    log_step("5a/6", "Saving output to SQL Server permanent tables...")
    output_schema = f"output_{ts}"
    create_output_schema_and_save(
        conn, final_df, stopwork_df, review_df, excluded_df,
        input_table, ts
    )

    # Step 5b — Log this run to run_history
    log_step("5b/6", "Logging run to run_history.Pipeline_Runs...")
    elapsed_so_far = round((datetime.now() - start).total_seconds(), 1)

    excel_bytes = build_excel_bytes(final_df, stopwork_df, review_df, excluded_df)

    log_step("6a/6", "Saving output Excel to local folder...")
    out_path = save_to_folder(excel_bytes, ts, input_path)

    #log_step("6b/6", "Sending output Excel via Outlook desktop...")
    #send_email(excel_bytes, ts, input_path, final_df, stopwork_df, review_df, excluded_df)

    elapsed = round((datetime.now() - start).total_seconds(), 1)

    log_run_history(
        conn, ts, input_path, input_schema, input_table,
        output_schema, final_df, stopwork_df,
        review_df, excluded_df, out_path, elapsed, "Completed"
    )

    cleanup(conn)

    log(f"\n{SEPARATOR}")
    log("  PIPELINE COMPLETE — PORTFOLIO MANAGER FILE")
    log(f"  Input schema  : [{input_schema}].[{input_table}]")
    log(f"  Output schema : [{output_schema}].*")
    log(f"  Saved to      : {out_path}")
    log(f"  Log file      : {log_file}")
    log("  Email        : Skipped — Outlook not available on VM")
    log(f"  Records       : {len(final_df):,} ready | {len(stopwork_df):,} HOLD | {len(review_df):,} review | {len(excluded_df):,} excluded")
    log(f"  Runtime       : {elapsed}s")
    log(SEPARATOR)


if __name__ == "__main__":
    main()
