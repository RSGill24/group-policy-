"""
============================================================
ConsolidatedTransformLogic.py
============================================================
Usage:
  py ConsolidatedTransformLogic.py
  
Requirements:
  pip install pandas pyodbc openpyxl
============================================================
"""

import sys
import json
import argparse
import struct
import logging
from datetime import datetime
from pathlib import Path

import pandas as pd
import pyodbc
import logging
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

# ── Globals populated by load_config() ───────────────────────────────────────
INPUT_FILE    = ""
INPUT_SHEETS  = {}
SQL_SERVER    = ""
SQL_DATABASE  = ""
OUTPUT_FOLDER = ""
EMAIL_ENABLED = False
EMAIL_TO      = []
EMAIL_CC      = []
EMAIL_SUBJECT = ""

STORED_PROC   = "dbo.Consolidated_Transform_Logic"
SEPARATOR     = "=" * 62

# ── Colour constants for Index_ID column ─────────────────────────────────────
HEADER_FILL = PatternFill("solid", start_color="FFFF00")   # yellow
DATA_FILL   = PatternFill("solid", start_color="FFFFE0")   # light yellow
HEADER_FONT = Font(bold=True)

# ── Logging: tees every message to console AND a timestamped .log file ──────
# init_logger() is called in main() once OUTPUT_FOLDER is known.
_logger = None


def init_logger(ts):
    """Create Planview_Index_Run_<ts>.log in OUTPUT_FOLDER."""
    global _logger
    log_dir = Path(OUTPUT_FOLDER)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"Planview_Index_Run_{ts}.log"

    _logger = logging.getLogger("planview_index")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()          # prevent duplicate handlers on re-run

    # File handler — full detail with timestamps
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "%(asctime)s  %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    _logger.addHandler(fh)

    # Console handler — mirrors what was already printing
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(ch)

    return log_file


def log(msg, indent=0):
    line = "  " * indent + str(msg)
    if _logger:
        _logger.info(line)
    else:
        print(line)


def log_step(num, msg):
    line = f"\n[{num}] {msg}"
    if _logger:
        _logger.info(line)
    else:
        print(line)


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
def load_config(config_path=None):
    global INPUT_FILE, INPUT_SHEETS, SQL_SERVER, SQL_DATABASE
    global OUTPUT_FOLDER, EMAIL_ENABLED, EMAIL_TO, EMAIL_CC, EMAIL_SUBJECT

    if config_path is None:
        config_path = Path(__file__).parent / "ConsolidatedTransformLogic_config.json"

    config_path = Path(config_path)
    if not config_path.exists():
        log(f"ERROR: Config file not found: {config_path}")
        log(f"  Create planview_index_config.json in the same folder as this script.")
        sys.exit(1)

    try:
        with open(config_path, encoding="utf-8") as f:
            cfg = json.load(f)
    except json.JSONDecodeError as e:
        log(f"ERROR: Config file is not valid JSON: {e}")
        sys.exit(1)

    INPUT_FILE    = cfg["input"]["file"]
    INPUT_SHEETS  = cfg["input"]["sheets"]      # dict: {table_name: sheet_name}
    SQL_SERVER    = cfg["sql"]["server"]
    SQL_DATABASE  = cfg["sql"]["database"]
    OUTPUT_FOLDER = cfg["output"]["folder"]
    EMAIL_ENABLED = cfg.get("email", {}).get("enabled", False)
    EMAIL_TO      = cfg.get("email", {}).get("to",      [])
    EMAIL_CC      = cfg.get("email", {}).get("cc",      [])
    EMAIL_SUBJECT = cfg.get("email", {}).get("subject", "Planview Migration — Index ID Output")

    log(f"  Config       : {config_path}")
    log(f"  Input file   : {INPUT_FILE}")
    log(f"  SQL Server   : {SQL_SERVER} / {SQL_DATABASE}")
    log(f"  Output folder: {OUTPUT_FOLDER}")


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Read input Excel
#
# Header strategy:
#   Row 1 (index 0) — system field codes        (skipped)
#   Row 2 (index 1) — partial human names       (fallback)
#   Row 3 (index 2) — primary human names       (preferred)
#
#   For each column, use row 3 value if non-blank, else fall back to row 2.
#   This handles col 0 ("Work ($Plan) ID") which is blank in row 3 across
#   all three sheets.
# ─────────────────────────────────────────────────────────────────────────────
def read_input():
    log_step("1/6", "Reading input file...")
    path = Path(INPUT_FILE)
    if not path.exists():
        log(f"  ERROR: File not found: {path}")
        sys.exit(1)

    frames = {}
    for table_name, sheet_name in INPUT_SHEETS.items():
        try:
            # Read first 3 rows to build the merged header
            raw = pd.read_excel(path, sheet_name=sheet_name,
                                header=None, nrows=3, dtype=str)
            row2 = [str(v).strip() if str(v).strip() not in ('', 'nan') else None
                    for v in raw.iloc[1]]
            row3 = [str(v).strip() if str(v).strip() not in ('', 'nan') else None
                    for v in raw.iloc[2]]

            # Prefer row 3; fall back to row 2; use positional name as last resort
            merged_cols = []
            for i, (r3, r2) in enumerate(zip(row3, row2)):
                name = r3 or r2 or f"Col_{i}"
                merged_cols.append(name)

            # Now read the actual data (skip first 3 rows)
            df = pd.read_excel(
                path,
                sheet_name=sheet_name,
                header=None,
                skiprows=3,
                dtype=str
            )

            # Trim to the number of header columns (drops any trailing empty cols)
            df = df.iloc[:, :len(merged_cols)]
            df.columns = merged_cols

            # Handle duplicate column names by appending a suffix
            seen = {}
            deduped = []
            for col in df.columns:
                if col in seen:
                    seen[col] += 1
                    deduped.append(f"{col}_{seen[col]}")
                else:
                    seen[col] = 0
                    deduped.append(col)
            df.columns = deduped

            # Drop fully empty rows
            df.dropna(how="all", inplace=True)

            # Remove Work ($Plan) ID — system internal column not needed in output
            work_plan_col = "Work ($Plan) ID"
            if work_plan_col in df.columns:
                df.drop(columns=[work_plan_col], inplace=True)
                log(f"  {table_name:<15} dropped column: '{work_plan_col}'")

            frames[table_name] = df
            log(f"  {table_name:<15} sheet='{sheet_name}'  rows={len(df):,}  cols={len(df.columns)}")

        except Exception as e:
            log(f"  ERROR reading sheet '{sheet_name}': {e}")
            sys.exit(1)

    return frames


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Connect to SQL Server (Windows Auth)
# ─────────────────────────────────────────────────────────────────────────────
def connect_sql():
    log_step("2/6", "Connecting to SQL Server...")
    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={SQL_SERVER};"
        f"DATABASE={SQL_DATABASE};"
        f"Trusted_Connection=yes;"
    )
    try:
        conn = pyodbc.connect(conn_str, autocommit=False)
        log(f"  Connected     : {SQL_SERVER} / {SQL_DATABASE}")
        return conn
    except Exception as e:
        log(f"  ERROR connecting to SQL Server: {e}")
        sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Create input schema and load raw tables
# ─────────────────────────────────────────────────────────────────────────────
def create_input_schema(conn, run_ts, frames):
    log_step("3/6", "Loading raw data into SQL Server (input schema)...")
    cursor = conn.cursor()
    input_schema = f"input_{run_ts}"

    # Create schema
    cursor.execute(f"""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '{input_schema}')
            EXEC('CREATE SCHEMA [{input_schema}]')
    """)
    conn.commit()

    # Sanitise column names once — smart/curly quotes break SQL [...] identifiers
    def sanitise_col(name):
        return (str(name)
            .replace('\u2018', "'").replace('\u2019', "'")   # curly single quotes
            .replace('\u201c', '"').replace('\u201d', '"')   # curly double quotes
            .replace(']', ')')                                  # ] breaks [...] names
        )

    for table_name, df in frames.items():
        full_table = f"[{input_schema}].[{table_name}]"

        # Apply sanitisation to column names
        df.columns = [sanitise_col(c) for c in df.columns]

        # Drop if exists (clean re-run)
        cursor.execute(f"""
            IF OBJECT_ID('{input_schema}.{table_name}', 'U') IS NOT NULL
                DROP TABLE {full_table}
        """)
        conn.commit()

        # Build CREATE TABLE — all NVARCHAR(MAX) columns
        col_defs = ",\n    ".join(
            f"[{col}] NVARCHAR(MAX)" for col in df.columns
        )
        cursor.execute(f"CREATE TABLE {full_table} (\n    {col_defs}\n)")
        conn.commit()

        # Verify column count matches between DataFrame and SQL table
        cursor.execute(f"SELECT COUNT(*) FROM sys.columns WHERE object_id = OBJECT_ID('{input_schema}.{table_name}')")
        sql_col_count = cursor.fetchone()[0]
        df_col_count  = len(df.columns)
        log(f"  {table_name:<15} df_cols={df_col_count}  sql_cols={sql_col_count}")
        if df_col_count != sql_col_count:
            log(f"  ERROR: Column count mismatch — df has {df_col_count}, SQL table has {sql_col_count}")
            log(f"  DataFrame columns: {list(df.columns)}")
            sys.exit(1)

        # Build insert rows — Replace NaN with None for SQL NULL
        rows = [
            tuple(None if pd.isna(v) else str(v) for v in row)
            for row in df.itertuples(index=False, name=None)
        ]

        # Verify first row tuple length matches
        if rows:
            first_len = len(rows[0])
            if first_len != sql_col_count:
                log(f"  ERROR: First row has {first_len} values but table has {sql_col_count} columns")
                sys.exit(1)

        # Insert — fast_executemany OFF to avoid 510-char NVARCHAR truncation
        cursor.fast_executemany = False
        placeholders = ", ".join(["?"] * sql_col_count)
        insert_sql = f"INSERT INTO {full_table} VALUES ({placeholders})"
        cursor.executemany(insert_sql, rows)
        conn.commit()
        log(f"  {table_name:<15} → {full_table}  ({len(rows):,} rows inserted)")

    return input_schema


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Call stored procedure
# ─────────────────────────────────────────────────────────────────────────────
def call_stored_procedure(conn, run_ts):
    log_step("4/6", "Calling stored procedure {STORED_PROC}...")
    cursor = conn.cursor()

    try:
        cursor.execute(f"EXEC {STORED_PROC} @run_ts = ?", run_ts)
    except Exception as e:
        log(f"  ERROR executing stored procedure: {e}")
        log(f"  Make sure usp_Planview_Index_ID.sql has been run in SSMS first.")
        sys.exit(1)

    results = {}
    table_order = list(INPUT_SHEETS.keys())  # Initiatives, Epics, Value_Bundles

    for i, table_name in enumerate(table_order):
        if cursor.description:
            cols = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            results[table_name] = pd.DataFrame.from_records(rows, columns=cols)
            log(f"  {table_name:<15} → {len(results[table_name]):,} rows returned")
        else:
            log(f"  WARNING: No result set returned for {table_name}")
            results[table_name] = pd.DataFrame()

        if i < len(table_order) - 1:
            cursor.nextset()

    conn.commit()
    return results


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Write output schema
# ─────────────────────────────────────────────────────────────────────────────
def write_output_schema(conn, run_ts, results):
    log_step("5/6", "Writing output schema...")
    cursor = conn.cursor()
    output_schema = f"output_{run_ts}"

    # Schema already created by SP — just confirm tables exist
    for table_name, df in results.items():
        full_table = f"[{output_schema}].[{table_name}]"
        log(f"  {table_name:<15} → {full_table}  ({len(df):,} rows)")

    return output_schema


# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Save Excel output with Index_ID colour coded
# ─────────────────────────────────────────────────────────────────────────────
def write_excel(results, run_ts):
    log_step("6/6", "Writing Excel output...")

    out_folder = Path(OUTPUT_FOLDER)
    out_folder.mkdir(parents=True, exist_ok=True)
    out_file = out_folder / f"Planview_Index_Output_{run_ts}.xlsx"

    # Sequence ID column name per table
    seq_col_map = {
        "Initiatives":   "Strategy Seq ID",
        "Epics":         "Sequence ID",
        "Value_Bundles": "Sequence ID",
    }

    with pd.ExcelWriter(out_file, engine="openpyxl") as writer:
        for table_name, df in results.items():
            df.to_excel(writer, sheet_name=table_name, index=False)

    # Re-open with openpyxl to apply colour formatting on Index_ID column
    wb = load_workbook(out_file)

    for table_name, df in results.items():
        ws = wb[table_name]
        cols = list(df.columns)

        # Colour all generated columns
        generated_cols = {
            "Index_ID":                                    (HEADER_FILL,
                                                            DATA_FILL,
                                                            18),
            "Flow Type - Step 1":                          (PatternFill("solid", start_color="FFC000"),
                                                            PatternFill("solid", start_color="FFEEBA"),
                                                            28),
            "Estimated Annualized Value Range_Step 1":     (PatternFill("solid", start_color="92D050"),
                                                            PatternFill("solid", start_color="E2EFDA"),
                                                            32),
            "Estimated Annualized Value Range_Step 2":     (PatternFill("solid", start_color="92D050"),
                                                            PatternFill("solid", start_color="E2EFDA"),
                                                            32),
            "Estimated Annualized Value Range_Step 3":     (PatternFill("solid", start_color="92D050"),
                                                            PatternFill("solid", start_color="E2EFDA"),
                                                            32),
            "Estimated Value Range_Consolidated":          (PatternFill("solid", start_color="00B0F0"),
                                                            PatternFill("solid", start_color="DDEEFF"),
                                                            32),
            "Flow Type":                                   (PatternFill("solid", start_color="7030A0"),
                                                            PatternFill("solid", start_color="EAD1F5"),
                                                            28),
        }

        for col_name, (hdr_fill, dat_fill, col_width) in generated_cols.items():
            if col_name not in cols:
                continue
            col_num = cols.index(col_name) + 1
            header_cell = ws.cell(row=1, column=col_num)
            header_cell.fill = hdr_fill
            header_cell.font = HEADER_FONT
            for row_num in range(2, ws.max_row + 1):
                ws.cell(row=row_num, column=col_num).fill = dat_fill
            ws.column_dimensions[ws.cell(row=1, column=col_num).column_letter].width = col_width
            log(f"  {table_name:<15} → colour applied to [{col_name}] (col {col_num})")

        if "Index_ID" not in cols:
            log(f"  WARNING: Index_ID not found in {table_name}")

    wb.save(out_file)
    log(f"\n  Output file  : {out_file}")
    return out_file



# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 — Log run to run_history.Pipeline_Runs
# ─────────────────────────────────────────────────────────────────────────────
def log_run(conn, run_ts, frames, results, out_file, elapsed, status):
    log_step("7/7", "Logging run to run_history.Pipeline_Runs...")
    cursor = conn.cursor()

    # Ensure run_history schema exists
    cursor.execute("""
        IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'run_history')
            EXEC('CREATE SCHEMA [run_history]')
    """)
    conn.commit()

    # Ensure Pipeline_Runs table exists
    cursor.execute("""
        IF OBJECT_ID('run_history.Pipeline_Runs', 'U') IS NULL
            CREATE TABLE run_history.Pipeline_Runs (
                Run_ID              NVARCHAR(50)    PRIMARY KEY,
                Run_Timestamp       DATETIME        DEFAULT GETDATE(),
                Pipeline_Name       NVARCHAR(200),
                Input_File          NVARCHAR(500),
                Input_Schema        NVARCHAR(200),
                Output_Schema       NVARCHAR(200),
                Initiatives_In      INT,
                Epics_In            INT,
                ValueBundles_In     INT,
                Initiatives_Out     INT,
                Epics_Out           INT,
                ValueBundles_Out    INT,
                Output_File_Path    NVARCHAR(500),
                Runtime_Seconds     DECIMAL(10,1),
                Run_Status          NVARCHAR(50)
            )
    """)
    conn.commit()

    # Guard: add any columns that may be missing if the table was created
    # by an earlier pipeline version — safe to run on every execution
    for col, col_type in [
        ("Initiatives_In",   "INT"),
        ("Epics_In",         "INT"),
        ("ValueBundles_In",  "INT"),
        ("Initiatives_Out",  "INT"),
        ("Epics_Out",        "INT"),
        ("ValueBundles_Out", "INT"),
        ("Input_Schema",     "NVARCHAR(200)"),
        ("Output_Schema",    "NVARCHAR(200)"),
        ("Runtime_Seconds",  "DECIMAL(10,1)"),
        ("Run_Status",       "NVARCHAR(50)"),
        ("Output_File_Path", "NVARCHAR(500)"),
    ]:
        cursor.execute(f"""
            IF NOT EXISTS (
                SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = 'run_history'
                  AND TABLE_NAME   = 'Pipeline_Runs'
                  AND COLUMN_NAME  = '{col}'
            )
            ALTER TABLE run_history.Pipeline_Runs ADD [{col}] {col_type}
        """)
    conn.commit()

    cursor.execute("""
        INSERT INTO run_history.Pipeline_Runs (
            Run_ID, Pipeline_Name, Input_File,
            Input_Schema, Output_Schema,
            Initiatives_In, Epics_In, ValueBundles_In,
            Initiatives_Out, Epics_Out, ValueBundles_Out,
            Output_File_Path, Runtime_Seconds, Run_Status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        run_ts,
        'Planview Index ID Pipeline — Orders 0.1 / 0.2a / 0.2b',
        INPUT_FILE,
        f'input_{run_ts}',
        f'output_{run_ts}',
        len(frames.get('Initiatives',   [])),
        len(frames.get('Epics',         [])),
        len(frames.get('Value_Bundles', [])),
        len(results.get('Initiatives',   [])),
        len(results.get('Epics',         [])),
        len(results.get('Value_Bundles', [])),
        str(out_file),
        round(elapsed, 1),
        status
    ))
    conn.commit()
    log(f"  Run logged    : Run_ID={run_ts}  Status={status}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Planview Index ID Pipeline")
    parser.add_argument("--config", default=None, help="Path to config JSON file")
    args = parser.parse_args()

    run_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    start  = datetime.now()

    log(SEPARATOR)
    log("  ConsolidatedTransformLogic")
    log(f"  Run timestamp : {run_ts}")
    log(SEPARATOR)

    load_config(args.config)
    log_file = init_logger(run_ts)

    frames        = {}
    results       = {}
    out_file      = None
    conn          = None

    try:
        frames        = read_input()
        conn          = connect_sql()
        input_schema  = create_input_schema(conn, run_ts, frames)
        results       = call_stored_procedure(conn, run_ts)
        output_schema = write_output_schema(conn, run_ts, results)
        out_file      = write_excel(results, run_ts)

        elapsed = (datetime.now() - start).total_seconds()
        log_run(conn, run_ts, frames, results, out_file, elapsed, "SUCCESS")
        conn.close()

        log(f"\n{SEPARATOR}")
        log(f"  PIPELINE COMPLETE")
        log(f"  Input schema  : input_{run_ts}")
        log(f"  Output schema : output_{run_ts}")
        log(f"  Excel output  : {out_file}")
        log(f"  Log file      : {log_file}")
        log(f"  Runtime       : {round(elapsed, 1)}s")
        log(SEPARATOR)

        # Row count summary
        log("")
        log(f"  {'Table':<20} {'Input':>8}  {'Output':>8}")
        log(f"  {'-'*38}")
        for t in ['Initiatives', 'Epics', 'Value_Bundles']:
            log(f"  {t:<20} {len(frames.get(t,[])):>8,}  {len(results.get(t,[])):>8,}")

    except Exception as e:
        elapsed = (datetime.now() - start).total_seconds()
        log(f"\n  PIPELINE FAILED: {e}")
        if conn:
            try:
                log_run(conn, run_ts, frames, results, out_file, elapsed, f"FAILED: {str(e)[:200]}")
                conn.close()
            except Exception:
                pass
        sys.exit(1)


if __name__ == "__main__":
    main()
