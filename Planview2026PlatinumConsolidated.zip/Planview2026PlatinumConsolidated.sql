CREATE OR ALTER PROCEDURE dbo.Planview2026PlatinumConsolidated
    @input_schema           NVARCHAR(200),
    @stem                   NVARCHAR(500),
    @ts                     NVARCHAR(50),
    @bc_blank_equals_no     BIT           = 1,
    @nrb_blank_equals_disc_other BIT      = 1,
    @nrb_field              NVARCHAR(500) = N'L1 Net Recurring Benefits ($, annualized)-P&L/Hard',
    @nrb_threshold_m        DECIMAL(18,4) = 10,
    @allowed_statuses       NVARCHAR(500) = N'Active',
    @fy25_expired_esi       NVARCHAR(MAX) = N'Network Optimization (FY25 ESI)|Digital Intelligence (FY25 ESI)|Europe - Operations (FY25 ESI)|Digital Experience (FY25 ESI)'
AS
BEGIN
    SET NOCOUNT ON;

    -- ── 0. Working tables ─────────────────────────────────────
    IF OBJECT_ID('tempdb..#AllowedStatuses') IS NOT NULL DROP TABLE #AllowedStatuses;
    CREATE TABLE #AllowedStatuses (StatusVal NVARCHAR(200));

    INSERT INTO #AllowedStatuses (StatusVal)
    SELECT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(@allowed_statuses, ',');

    -- Split @fy25_expired_esi into a temp table IS NOT NULL DROP TABLE #ExpiredESI;
    CREATE TABLE #ExpiredESI (ESIVal NVARCHAR(500));

    INSERT INTO #ExpiredESI (ESIVal)
    SELECT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(@fy25_expired_esi, '|');

    -- Staging table: classification rule columns only
    IF OBJECT_ID('tempdb..#RawInits') IS NOT NULL DROP TABLE #RawInits;
    CREATE TABLE #RawInits (
        [_row_id]                                       INT IDENTITY(1,1),
        [Run_ID]                                        NVARCHAR(MAX),
        [Load_Timestamp]                                NVARCHAR(MAX),
        [Strategy Seq. ID]                              NVARCHAR(MAX),
        [Initiative Type]                               NVARCHAR(MAX),
        [T-Shirt Size]                                  NVARCHAR(MAX),
        [Stage]                                         NVARCHAR(MAX),
        [Enterprise Strategic Initiative (ESI)]         NVARCHAR(MAX),
        [Purple Chip]                                   NVARCHAR(MAX),
        [Is this request vital to business continuity?] NVARCHAR(MAX),
        [Lifecycle Status]                              NVARCHAR(MAX),
        [NRB_Value]                                     NVARCHAR(MAX)
    );

    -- Staging table: Epics
    IF OBJECT_ID('tempdb..#RawEpics') IS NOT NULL DROP TABLE #RawEpics;
    CREATE TABLE #RawEpics (
        [_row_id]                           INT IDENTITY(1,1),
        [Run_ID]                            NVARCHAR(MAX),
        [Load_Timestamp]                    NVARCHAR(MAX),
        [Work ID #]                         NVARCHAR(MAX),
        [Work Type]                         NVARCHAR(MAX),
        [Work Status]                       NVARCHAR(MAX),
        [T-Shirt Size]                      NVARCHAR(MAX),
        [Stage]                             NVARCHAR(MAX),
        [Estimated Annualized Value Range]  NVARCHAR(MAX)
    );

    -- ── 1. Load classification columns from input schema tables ─
    DECLARE @sql NVARCHAR(MAX);

    -- Initiatives: NRB column name is config-driven, loaded via dynamic SQL
    SET @sql = N'
        INSERT INTO #RawInits (
            [Run_ID], [Load_Timestamp],
            [Strategy Seq. ID], [Initiative Type], [T-Shirt Size], [Stage],
            [Enterprise Strategic Initiative (ESI)], [Purple Chip],
            [Is this request vital to business continuity?],
            [Lifecycle Status], [NRB_Value]
        )
        SELECT
            [Run_ID], [Load_Timestamp],
            [Strategy Seq. ID], [Initiative Type], [T-Shirt Size], [Stage],
            [Enterprise Strategic Initiative (ESI)], [Purple Chip],
            [Is this request vital to business continuity?],
            [Lifecycle Status],
            ' + QUOTENAME(@nrb_field) + N'
        FROM [' + @input_schema + N'].[' + @stem + N'_Initiatives]
    ';
    EXEC sp_executesql @sql;

    -- Epics
    SET @sql = N'
        INSERT INTO #RawEpics (
            [Run_ID], [Load_Timestamp],
            [Work ID #], [Work Type], [Work Status], [T-Shirt Size],
            [Stage], [Estimated Annualized Value Range]
        )
        SELECT
            [Run_ID], [Load_Timestamp],
            [Work ID #], [Work Type], [Work Status], [T-Shirt Size],
            [Stage], [Estimated Annualized Value Range]
        FROM [' + @input_schema + N'].[' + @stem + N'_Epics]
    ';
    EXEC sp_executesql @sql;

    -- ── 2. CLASSIFY INITIATIVES ───────────────────────────────
    --    Priority order:
    --      1. BR_STATUS_001 — Status exclusion
    --      2. BR_TE_006     — Business Only
    --      3. BR_TE_004     — Business Continuity (fires before pending check)
    --      4. Pending stage (SL2/SL3/SL4/L5/SL5)
    --      5. BR_PC_001     — Purple Chip
    --      6. Guard: non-BwT unknown type
    --      7. BR_TE_002     — Stop Work (L/XL + NRB < threshold)
    --      8. BR_TE_001     — Strategic Investment (L/XL + active ESI + NRB >= threshold)
    --      9. BR_TE_003     — Discretionary Other (S/M/XS or blank)
    --     10. Fallback PENDING
    -- ─────────────────────────────────────────────────────────

    IF OBJECT_ID('tempdb..#ClassifiedInits') IS NOT NULL DROP TABLE #ClassifiedInits;

    SELECT
        i.*,

        -- NRB as numeric (NULL when blank/unparseable)
        TRY_CAST(
            REPLACE(REPLACE(LTRIM(RTRIM(i.[NRB_Value])), ',', ''), '$', '')
            AS DECIMAL(18,4)
        ) AS _nrb_num,

        UPPER(LTRIM(RTRIM(i.[Stage]))) AS _stage_up,

        -- T-Shirt size buckets
        CASE WHEN LTRIM(RTRIM(i.[T-Shirt Size])) IN ('4: L', '5: XL') THEN 1 ELSE 0 END AS _is_lxl,
        CASE WHEN LTRIM(RTRIM(i.[T-Shirt Size])) IN ('1: XS', '2: S', '3: M') THEN 1 ELSE 0 END AS _is_sm,

        -- Status in allowed list
        CASE WHEN EXISTS (
            SELECT 1 FROM #AllowedStatuses WHERE StatusVal = LTRIM(RTRIM(i.[Lifecycle Status]))
        ) THEN 1 ELSE 0 END AS _status_allowed,

        -- BC = Yes
        CASE WHEN LTRIM(RTRIM(i.[Is this request vital to business continuity?])) = 'Yes' THEN 1 ELSE 0 END AS _bc_yes,

        -- ESI active: not blank, not '0-None', not expired, not Purple Chip
        CASE WHEN
            LTRIM(RTRIM(i.[Enterprise Strategic Initiative (ESI)])) <> ''
            AND LTRIM(RTRIM(i.[Enterprise Strategic Initiative (ESI)])) <> '0-None'
            AND NOT EXISTS (
                SELECT 1 FROM #ExpiredESI
                WHERE ESIVal = LTRIM(RTRIM(i.[Enterprise Strategic Initiative (ESI)]))
            )
            AND LTRIM(RTRIM(i.[Purple Chip])) <> 'Purple Chip'
        THEN 1 ELSE 0 END AS _esi_active,

        -- Pending stage: SL2/SL3/SL4/SL5/L5 — L4 is defined
        CASE WHEN
            UPPER(LTRIM(RTRIM(i.[Stage]))) LIKE '%SL2%'
            OR UPPER(LTRIM(RTRIM(i.[Stage]))) LIKE '%SL3%'
            OR UPPER(LTRIM(RTRIM(i.[Stage]))) LIKE '%SL4%'
            OR UPPER(LTRIM(RTRIM(i.[Stage]))) LIKE '%SL5%'
            OR (UPPER(LTRIM(RTRIM(i.[Stage]))) LIKE '%L5%'
                AND UPPER(LTRIM(RTRIM(i.[Stage]))) NOT LIKE '%SL5%')
            OR (
                -- No recognised L/SL stage pattern
                UPPER(LTRIM(RTRIM(i.[Stage]))) NOT LIKE '%L1%'
                AND UPPER(LTRIM(RTRIM(i.[Stage]))) NOT LIKE '%L2%'
                AND UPPER(LTRIM(RTRIM(i.[Stage]))) NOT LIKE '%L3%'
                AND UPPER(LTRIM(RTRIM(i.[Stage]))) NOT LIKE '%L4%'
            )
        THEN 1 ELSE 0 END AS _pending_stage

    INTO #ClassifiedInits
    FROM #RawInits i;

    -- Add classification columns
    ALTER TABLE #ClassifiedInits ADD
        [Output_Segment]        NVARCHAR(200),
        [Migration_Track]       NVARCHAR(500),
        [Demand_Sub_Type]       NVARCHAR(500),
        [Target_Lifecycle_Step] NVARCHAR(500),
        [Record_Type]           NVARCHAR(50);

    -- Target_Lifecycle_Step
    UPDATE #ClassifiedInits SET [Target_Lifecycle_Step] =
        CASE
            WHEN _stage_up LIKE '%L1%' AND _stage_up NOT LIKE '%SL%'  THEN 'Initial Request Information'
            WHEN _stage_up LIKE '%L2%' AND _stage_up NOT LIKE '%SL%'  THEN 'Architecture Alignment'
            WHEN _stage_up LIKE '%L3%' AND _stage_up NOT LIKE '%SL%'  THEN 'Demand Bundle Decomp and Conceptual Architecture'
            WHEN _stage_up LIKE '%L4%' AND _stage_up NOT LIKE '%SL%'  THEN 'Evaluate Outcome Achievement'
            WHEN _stage_up LIKE '%SL2%'                               THEN 'PENDING — SL2 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL3%'                               THEN 'PENDING — SL3 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL4%'                               THEN 'PENDING — SL4 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL5%'                               THEN 'PENDING — SL5 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%L5%'                                THEN 'PENDING — L5 lifecycle step not yet defined in business rules'
            ELSE                                                            'PENDING — Stage not recognised'
        END;

    -- ── Classification waterfall ──────────────────────────────

    -- Priority 1: BR_STATUS_001 — Status exclusion
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'EXCLUDED-Status',
        [Migration_Track] = 'BR_STATUS_001 — Excluded: ' + LTRIM(RTRIM([Lifecycle Status])),
        [Demand_Sub_Type] = 'NOT MIGRATED — Status excluded',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _status_allowed = 0
      AND LTRIM(RTRIM([Lifecycle Status])) <> '';   -- blank status falls through to other rules

    -- Priority 2: BR_TE_006 — Business Only Initiative
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-BusinessDemandMgmt',
        [Migration_Track] = 'BR_TE_006 — Business Only',
        [Demand_Sub_Type] = 'Business Demand Management',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND LTRIM(RTRIM([Initiative Type])) = 'Business Only Initiative';

    -- Priority 3: BR_TE_004 — Business Continuity (fires BEFORE pending stage check)
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-NonDisc-BusinessContinuity',
        [Migration_Track] = 'BR_TE_004 — Business Continuity',
        [Demand_Sub_Type] = 'Non-Discretionary - Business Continuity',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _bc_yes = 1;

    -- Priority 4: Pending stage (SL2/SL3/SL4/L5/SL5 not yet defined)
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'PENDING-Stage-Lifecycle-Undefined',
        [Migration_Track] = 'PENDING — Stage lifecycle step undefined',
        [Demand_Sub_Type] = 'PENDING — Awaiting SL/L5 lifecycle step definition',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _pending_stage = 1;

    -- Priority 5: BR_PC_001 — Purple Chip → Pilot Sandbox
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'PC-StrategicProgram-PilotSandbox',
        [Migration_Track] = 'BR_PC_001 — Purple Chip (Pilot Sandbox)',
        [Demand_Sub_Type] = 'Strategic Program VB — Pilot Sandbox path',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND LTRIM(RTRIM([Purple Chip])) = 'Purple Chip';

    -- Priority 6: Guard — non-BwT, non-BO, unknown Initiative Type
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'PENDING-Stage-Lifecycle-Undefined',
        [Migration_Track] = 'REVIEW — Unknown Initiative Type',
        [Demand_Sub_Type] = 'REVIEW REQUIRED — Unknown type',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND LTRIM(RTRIM([Initiative Type])) <> 'Business w/ Tech Initiative';

    -- ── BwT Initiatives only ──────────────────────────────────

    -- Priority 7a: BR_TE_002 — L/XL + NRB < threshold → Stop Work
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-Disc-StopWork-HOLD',
        [Migration_Track] = 'BR_TE_002 — Stop Work (NRB < $' + CAST(@nrb_threshold_m AS NVARCHAR) + 'M)',
        [Demand_Sub_Type] = 'Discretionary - Stop Work (Pending Finance/Triage)',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _is_lxl = 1
      AND _nrb_num IS NOT NULL
      AND _nrb_num < @nrb_threshold_m;

    -- Priority 7b: BR_TE_001 — L/XL + NRB >= threshold + active ESI → Strategic Investment
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-Disc-TransformationalInvestment',
        [Migration_Track] = 'BR_TE_001 — Strategic Investment (ESI + L/XL + NRB >= $' + CAST(@nrb_threshold_m AS NVARCHAR) + 'M)',
        [Demand_Sub_Type] = 'Discretionary - Transformational Investment',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _is_lxl = 1
      AND _nrb_num IS NOT NULL
      AND _nrb_num >= @nrb_threshold_m
      AND _esi_active = 1;

    -- Priority 7c: BR_TE_002 fallback — L/XL + NRB >= threshold but ESI NOT active → Stop Work
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-Disc-StopWork-HOLD',
        [Migration_Track] = 'BR_TE_002 — Stop Work (L/XL, no active ESI)',
        [Demand_Sub_Type] = 'Discretionary - Stop Work (Pending Finance/Triage)',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _is_lxl = 1
      AND _nrb_num IS NOT NULL
      AND _nrb_num >= @nrb_threshold_m
      AND _esi_active = 0;

    -- Priority 7d: L/XL + NRB blank → Disc Other or PENDING per config
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = CASE @nrb_blank_equals_disc_other
                                WHEN 1 THEN 'TE-Disc-Other'
                                ELSE        'PENDING-Stage-Lifecycle-Undefined'
                            END,
        [Migration_Track] = CASE @nrb_blank_equals_disc_other
                                WHEN 1 THEN 'BR_TE_003 — Disc Other (blank NRB assumed)'
                                ELSE        'REVIEW — NRB missing for L/XL record'
                            END,
        [Demand_Sub_Type] = CASE @nrb_blank_equals_disc_other
                                WHEN 1 THEN 'Discretionary - Other (NRB blank — assumed default)'
                                ELSE        'REVIEW REQUIRED — NRB missing'
                            END,
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND _is_lxl = 1
      AND _nrb_num IS NULL;

    -- Priority 8: BR_TE_003 — S/M/XS or blank T-shirt → Discretionary Other
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'TE-Disc-Other',
        [Migration_Track] = 'BR_TE_003 — Discretionary Other',
        [Demand_Sub_Type] = 'Discretionary - Other',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL
      AND (_is_sm = 1 OR LTRIM(RTRIM([T-Shirt Size])) = '');

    -- Priority 9: Fallback — nothing matched
    UPDATE #ClassifiedInits SET
        [Output_Segment]  = 'PENDING-Stage-Lifecycle-Undefined',
        [Migration_Track] = 'REVIEW — No rule matched',
        [Demand_Sub_Type] = 'REVIEW REQUIRED',
        [Record_Type]     = 'Initiative'
    WHERE [Output_Segment] IS NULL;

    -- ── 3. CLASSIFY EPICS ─────────────────────────────────────
    --    Priority order:
    --      1. BR_STATUS_001 — Work Status exclusion
    --      2. Pending stage (SL2/SL3/SL4/L5/SL5)
    --      3. BR_TE_LCM_001 — Lifecycle Management Epic
    --      4. BR_TE_LE_003  — LE L/XL + value range Medium → Stop Work
    --      5. BR_TE_LE_001  — LE L/XL + High/Unknown → Strategic Investment
    --      6. BR_TE_LE_005  — LE S/M/XS → Disc Other
    --      7. BR_BLANK_001  — LE blank T-shirt → Disc Other
    --      8. Fallback PENDING
    -- ─────────────────────────────────────────────────────────

    IF OBJECT_ID('tempdb..#ClassifiedEpics') IS NOT NULL DROP TABLE #ClassifiedEpics;

    SELECT
        e.*,
        UPPER(LTRIM(RTRIM(e.[Stage])))        AS _stage_up,
        LTRIM(RTRIM(e.[Work Type]))           AS _work_type,
        LTRIM(RTRIM(e.[Work Status]))         AS _work_status,
        LTRIM(RTRIM(e.[T-Shirt Size]))        AS _t_shirt,
        LTRIM(RTRIM(e.[Estimated Annualized Value Range])) AS _val_range,

        CASE WHEN LTRIM(RTRIM(e.[T-Shirt Size])) IN ('4: L','5: XL') THEN 1 ELSE 0 END AS _is_lxl,
        CASE WHEN LTRIM(RTRIM(e.[T-Shirt Size])) IN ('1: XS','2: S','3: M') THEN 1 ELSE 0 END AS _is_sm,

        -- Pending stage: L2/L3/L4 defined; SL2/SL3/SL4/L5/SL5 pending
        -- Epics start at L2 (no L1 Epics per rules)
        CASE WHEN
            UPPER(LTRIM(RTRIM(e.[Stage]))) LIKE '%SL2%'
            OR UPPER(LTRIM(RTRIM(e.[Stage]))) LIKE '%SL3%'
            OR UPPER(LTRIM(RTRIM(e.[Stage]))) LIKE '%SL4%'
            OR UPPER(LTRIM(RTRIM(e.[Stage]))) LIKE '%SL5%'
            OR (UPPER(LTRIM(RTRIM(e.[Stage]))) LIKE '%L5%'
                AND UPPER(LTRIM(RTRIM(e.[Stage]))) NOT LIKE '%SL5%')
            OR (
                UPPER(LTRIM(RTRIM(e.[Stage]))) NOT LIKE '%L2%'
                AND UPPER(LTRIM(RTRIM(e.[Stage]))) NOT LIKE '%L3%'
                AND UPPER(LTRIM(RTRIM(e.[Stage]))) NOT LIKE '%L4%'
            )
        THEN 1 ELSE 0 END AS _pending_stage

    INTO #ClassifiedEpics
    FROM #RawEpics e;

    -- Add classification + derived output columns
    ALTER TABLE #ClassifiedEpics ADD
        [Output_Segment]        NVARCHAR(200),
        [Migration_Track]       NVARCHAR(500),
        [Demand_Sub_Type]       NVARCHAR(500),
        [Target_Lifecycle_Step] NVARCHAR(500),
        [Epic_Number]           INT,
        [Execution_Type]        NVARCHAR(200),
        [Kanban_Status]         NVARCHAR(200),
        [EPG_Approval]          NVARCHAR(10),
        [Record_Type]           NVARCHAR(50);

    -- Epic_Number — sequential per rules (row order preserved via _row_id)
    UPDATE #ClassifiedEpics SET [Epic_Number] = _row_id;

    -- Target_Lifecycle_Step
    UPDATE #ClassifiedEpics SET [Target_Lifecycle_Step] =
        CASE
            WHEN _stage_up LIKE '%L2%' AND _stage_up NOT LIKE '%SL%' THEN 'Architecture Alignment'
            WHEN _stage_up LIKE '%L3%' AND _stage_up NOT LIKE '%SL%' THEN 'Demand Bundle Decomp and Conceptual Architecture'
            WHEN _stage_up LIKE '%L4%' AND _stage_up NOT LIKE '%SL%' THEN 'Evaluate Outcome Achievement'
            WHEN _stage_up LIKE '%SL2%'                              THEN 'PENDING — SL2 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL3%'                              THEN 'PENDING — SL3 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL4%'                              THEN 'PENDING — SL4 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%SL5%'                              THEN 'PENDING — SL5 lifecycle step not yet defined in business rules'
            WHEN _stage_up LIKE '%L5%'                               THEN 'PENDING — L5 lifecycle step not yet defined in business rules'
            ELSE                                                           'PENDING — Stage not recognised'
        END;

    -- Kanban_Status — Solution Analysis for L3, Intake/New otherwise
    UPDATE #ClassifiedEpics SET [Kanban_Status] =
        CASE WHEN _stage_up LIKE '%L3%' THEN 'Solution Analysis' ELSE 'Intake/New' END;

    -- EPG_Approval — Yes for L3 Epics
    UPDATE #ClassifiedEpics SET [EPG_Approval] =
        CASE WHEN _stage_up LIKE '%L3%' AND _stage_up NOT LIKE '%SL%' THEN 'Yes' ELSE '' END;

    UPDATE #ClassifiedEpics SET [Execution_Type] = 'Demand Bundle Epic at PPL+2';

    UPDATE #ClassifiedEpics SET [Record_Type] = 'Epic';

    -- ── Classification waterfall ──────────────────────────────

    -- Priority 1: BR_STATUS_001 — Work Status exclusion
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'EXCLUDED-Status',
        [Migration_Track] = 'BR_STATUS_001 — Excluded: ' + _work_status,
        [Demand_Sub_Type] = 'NOT MIGRATED — Status excluded'
    WHERE [Output_Segment] IS NULL
      AND _work_status IN ('Cancelled', 'Rejected', 'Completed/Closed');

    -- Priority 2: Pending stage
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'PENDING-Stage-Lifecycle-Undefined',
        [Migration_Track] = 'PENDING — Stage lifecycle step undefined',
        [Demand_Sub_Type] = 'PENDING — Awaiting SL/L5 lifecycle step definition'
    WHERE [Output_Segment] IS NULL
      AND _pending_stage = 1;

    -- Priority 3: BR_TE_LCM_001 — Lifecycle Management Epic
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'LCM-NonDisc-RunTheBusiness',
        [Migration_Track] = 'BR_TE_LCM_001 — LCM Run the Business',
        [Demand_Sub_Type] = 'Non-Discretionary - Run the Business'
    WHERE [Output_Segment] IS NULL
      AND _work_type = 'Lifecycle Management Epic';

    -- Priority 4: BR_TE_LE_003 — LE + L/XL + Medium value range → Stop Work
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'LE-Disc-StopWork-HOLD',
        [Migration_Track] = 'BR_TE_LE_003 — Stop Work (L/XL, value range Medium <$10M proxy)',
        [Demand_Sub_Type] = 'Discretionary - Stop Work (Pending Finance/Triage)'
    WHERE [Output_Segment] IS NULL
      AND _work_type = 'Local Enhancement Epic'
      AND _is_lxl = 1
      AND _val_range = '3: Medium = $1M < Value < $10M';

    -- Priority 5: BR_TE_LE_001 — LE + L/XL + High or unknown value → Strategic Investment
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'LE-Disc-TransformationalInvestment',
        [Migration_Track] = 'BR_TE_LE_001 — LE L/XL Transformational Investment',
        [Demand_Sub_Type] = 'Discretionary - Transformational Investment'
    WHERE [Output_Segment] IS NULL
      AND _work_type = 'Local Enhancement Epic'
      AND _is_lxl = 1;

    -- Priority 6: BR_TE_LE_005 — LE + S/M/XS → Disc Other
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'LE-Disc-Other',
        [Migration_Track] = 'BR_TE_LE_005 — LE S/M/XS Disc Other',
        [Demand_Sub_Type] = 'Discretionary - Other'
    WHERE [Output_Segment] IS NULL
      AND _work_type = 'Local Enhancement Epic'
      AND _is_sm = 1;

    -- Priority 7: BR_BLANK_001 — LE + blank T-shirt → Disc Other
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'LE-Disc-Other',
        [Migration_Track] = 'BR_BLANK_001 — LE blank T-shirt Disc Other',
        [Demand_Sub_Type] = 'Discretionary - Other (blank T-shirt default)'
    WHERE [Output_Segment] IS NULL
      AND _work_type = 'Local Enhancement Epic'
      AND _t_shirt = '';

    -- Priority 8: Fallback
    UPDATE #ClassifiedEpics SET
        [Output_Segment]  = 'PENDING-Stage-Lifecycle-Undefined',
        [Migration_Track] = 'REVIEW — No rule matched',
        [Demand_Sub_Type] = 'REVIEW REQUIRED'
    WHERE [Output_Segment] IS NULL;

    -- ── 4. Return Result Set 1 — Classified Initiatives ──────
    -- Build explicit src column list excluding Run_ID and Load_Timestamp
    DECLARE @init_cols NVARCHAR(MAX) = N'';
    SELECT @init_cols = @init_cols + N'src.' + QUOTENAME(c.name) + N', '
    FROM sys.columns c
    INNER JOIN sys.objects o ON c.object_id = o.object_id
    INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
    WHERE s.name  = @input_schema
      AND o.name  = @stem + N'_Initiatives'
      AND c.name NOT IN ('Run_ID', 'Load_Timestamp')
    ORDER BY c.column_id;
    -- Trim trailing ", "
    SET @init_cols = LEFT(@init_cols, LEN(@init_cols) - 1);

    SET @sql = N'
        SELECT
            ' + @init_cols + N',
            c.[Output_Segment],
            c.[Migration_Track],
            c.[Demand_Sub_Type],
            c.[Target_Lifecycle_Step],
            c.[Record_Type]
        FROM [' + @input_schema + N'].[' + @stem + N'_Initiatives] src
        INNER JOIN #ClassifiedInits c
            ON LTRIM(RTRIM(src.[Strategy Seq. ID])) = LTRIM(RTRIM(c.[Strategy Seq. ID]))
           AND LTRIM(RTRIM(src.[Stage]))             = LTRIM(RTRIM(c.[Stage]))
        ORDER BY c.[_row_id]
    ';
    EXEC sp_executesql @sql;

    -- ── 5. Return Result Set 2 — Classified Epics ────────────
    -- Build explicit src column list excluding Run_ID and Load_Timestamp
    DECLARE @epic_cols NVARCHAR(MAX) = N'';
    SELECT @epic_cols = @epic_cols + N'src.' + QUOTENAME(c.name) + N', '
    FROM sys.columns c
    INNER JOIN sys.objects o ON c.object_id = o.object_id
    INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
    WHERE s.name  = @input_schema
      AND o.name  = @stem + N'_Epics'
      AND c.name NOT IN ('Run_ID', 'Load_Timestamp')
    ORDER BY c.column_id;
    SET @epic_cols = LEFT(@epic_cols, LEN(@epic_cols) - 1);

    SET @sql = N'
        SELECT
            ' + @epic_cols + N',
            c.[Output_Segment],
            c.[Migration_Track],
            c.[Demand_Sub_Type],
            c.[Target_Lifecycle_Step],
            c.[Epic_Number],
            c.[Execution_Type],
            c.[Kanban_Status],
            c.[EPG_Approval],
            c.[Record_Type]
        FROM [' + @input_schema + N'].[' + @stem + N'_Epics] src
        INNER JOIN #ClassifiedEpics c
            ON LTRIM(RTRIM(src.[Work ID #])) = LTRIM(RTRIM(c.[Work ID #]))
           AND LTRIM(RTRIM(src.[Stage]))      = LTRIM(RTRIM(c.[Stage]))
        ORDER BY c.[_row_id]
    ';
    EXEC sp_executesql @sql;

    -- ── Cleanup ───────────────────────────────────────────────
    DROP TABLE IF EXISTS #AllowedStatuses;
    DROP TABLE IF EXISTS #ExpiredESI;
    DROP TABLE IF EXISTS #RawInits;
    DROP TABLE IF EXISTS #RawEpics;
    DROP TABLE IF EXISTS #ClassifiedInits;
    DROP TABLE IF EXISTS #ClassifiedEpics;

END;
GO

-- ── Verify SP created successfully ───────────────────────────
SELECT
    OBJECT_NAME(object_id)  AS StoredProcedure,
    create_date,
    modify_date
FROM sys.objects
WHERE type = 'P'
  AND name = 'Planview2026PlatinumConsolidated';
GO
